# Mock E-Commerce Website

This is a **mock e-commerce website** designed to be the **target** for the Synthetic Traffic Generator (STG). It simulates a real production website with landing pages, product pages, and checkout flow.

## Purpose

- **Testing Target**: STG agents visit this website and interact with it
- **Event Tracking**: Pages send analytics events (simulating real production tracking)
- **Completely Decoupled**: You can modify pages without touching STG code
- **Realistic Flow**: Instagram ad → Product page → Checkout → Success

## Pages

### 1. Landing Page (`/` or `/landing`)
- Instagram ad-style design
- Hero section with CTA
- Features, testimonials, trust badges
- Mimics a paid ad landing page

### 2. Product Page (`/product/wireless-headphones`)
- Product images and details
- Reviews and ratings
- Add to cart functionality
- Call-to-action buttons

### 3. Checkout Page (`/checkout`)
- Contact information form
- Shipping address form
- Payment information (credit card)
- Order summary

### 4. Success Page (`/success`)
- Order confirmation
- Order number
- Thank you message

## Event Tracking

All pages automatically track events via JavaScript:

```javascript
trackEvent('event_type', { data })
```

**Tracked Events:**
- `page_view` - Page loads
- `click` - Button/link clicks
- `form_field_focus` - Form interactions
- `add_to_cart` - Product added to cart
- `checkout_initiated` - Checkout started
- `purchase_completed` - Order placed
- `purchase_success` - Success page viewed

Events are sent to `/api/track` endpoint and can be forwarded to:
- STG backend webhooks
- External analytics systems
- Custom tracking endpoints

## How It Works with STG

### 1. **Start Services**
```bash
docker compose up -d
```

The mock website runs on **http://localhost:3000**

### 2. **Create Scenario in STG**
```json
{
  "name": "E-Commerce Shopper",
  "persona_prompt": "You are shopping for headphones...",
  "target_urls": {
    "start": "http://mock-website:3000/landing"
  }
}
```

Note: Use `mock-website:3000` (internal Docker network name)

### 3. **Generate Traffic**
STG workers will:
1. Launch headless browsers
2. Navigate to `http://mock-website:3000/landing`
3. LLM decides actions based on page content
4. Click buttons, fill forms, navigate pages
5. Complete checkout flow

### 4. **Track Events**
Mock website sends events to STG backend via webhook (optional):
```env
STG_WEBHOOK_URL=http://webserver:8000/api/webhook-receiver
```

## Customization

### Change Page Content

Edit HTML templates in `/mock-website/templates/`:
- `landing.html` - Landing page
- `product.html` - Product page
- `checkout.html` - Checkout page
- `success.html` - Success page

### Add New Products

Edit `app.py` and add to the `products` dictionary:

```python
products = {
    'new-product-id': {
        'name': 'Product Name',
        'price': 99.99,
        'description': '...',
        # ...
    }
}
```

### Modify Tracking

Edit the `trackEvent()` function in `base.html` to change how events are sent.

### Add Custom Pages

1. Create template in `/templates/`
2. Add route in `app.py`:

```python
@app.route('/new-page')
def new_page():
    return render_template('new-page.html')
```

## Local Development

Run locally without Docker:

```bash
cd mock-website
pip install -r requirements.txt
python app.py
```

Access at `http://localhost:3000`

## Environment Variables

| Variable | Default | Description |
|----------|---------|-------------|
| `SECRET_KEY` | auto-generated | Flask session secret |
| `STG_BACKEND_URL` | `http://webserver:8000` | STG backend URL |
| `STG_API_KEY` | `dev-api-key` | API key for STG |
| `STG_WEBHOOK_URL` | (optional) | Webhook URL for event forwarding |

## Architecture

```
┌─────────────────────────────────┐
│  Mock Website (Flask)           │
│  - Serves HTML pages            │
│  - JavaScript tracking          │
│  - Session management           │
└────────┬────────────────────────┘
         │
         │ User visits pages
         ▼
┌─────────────────────────────────┐
│  STG Worker (Playwright)        │
│  - Headless browser             │
│  - LLM-driven actions           │
└────────┬────────────────────────┘
         │
         │ Events sent via JS
         ▼
┌─────────────────────────────────┐
│  Mock Website /api/track        │
│  - Receives events              │
│  - Forwards to STG/webhooks     │
└─────────────────────────────────┘
```

## No Data Generation Code Here!

This website is **completely separate** from the STG data generation logic. It's just a target for testing. You can:

- ✅ Modify HTML/CSS freely
- ✅ Add new pages
- ✅ Change product data
- ✅ Update forms
- ✅ Customize tracking

**Without touching any of the STG worker/agent code!**

The STG agent just visits URLs and interacts based on what it sees on the page - just like a real user.
