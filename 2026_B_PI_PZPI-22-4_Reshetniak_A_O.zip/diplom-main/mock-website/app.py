"""Mock e-commerce website that sends events to STG collector.

The JS tracker on each page manages identity client-side (cookies),
exactly like production analytics SDKs (Snowplow sp.js, GA analytics.js).
The server never generates or injects visitor/session IDs.
"""

import os
from flask import Flask, render_template, request, jsonify, session
import uuid

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'mock-website-secret-key')

# Collector URL — the JS tracker sends events here (now part of webserver)
COLLECTOR_URL = os.environ.get('COLLECTOR_URL', 'http://webserver:8000')

# STG backend URL (kept for backward compat / admin API calls)
STG_BACKEND = os.environ.get('STG_BACKEND_URL', 'http://webserver:8000')
STG_API_KEY = os.environ.get('STG_API_KEY', 'dev-api-key')


@app.route('/')
@app.route('/landing')
def landing():
    """Instagram-style ad landing page."""
    return render_template('landing.html', collector_url=COLLECTOR_URL)


@app.route('/product/<product_id>')
def product(product_id):
    """Product detail page."""
    # Mock product data
    products = {
        'wireless-headphones': {
            'name': 'Premium Wireless Headphones',
            'price': 149.99,
            'original_price': 199.99,
            'image': '/static/images/headphones.jpg',
            'description': 'Experience crystal-clear sound with active noise cancellation',
            'features': [
                '40-hour battery life',
                'Active noise cancellation',
                'Premium leather cushions',
                'Bluetooth 5.0',
            ],
            'rating': 4.8,
            'reviews': 2847,
        },
        'smart-watch': {
            'name': 'Fitness Smart Watch',
            'price': 199.99,
            'original_price': 299.99,
            'image': '/static/images/watch.jpg',
            'description': 'Track your health and fitness with style',
            'features': [
                'Heart rate monitoring',
                '7-day battery life',
                'Waterproof design',
                'GPS tracking',
            ],
            'rating': 4.6,
            'reviews': 1523,
        },
    }

    product_data = products.get(product_id, products['wireless-headphones'])

    return render_template('product.html',
                         product=product_data,
                         product_id=product_id,
                         collector_url=COLLECTOR_URL)


@app.route('/cart')
def cart():
    """Shopping cart page."""
    cart_items = session.get('cart', [])

    return render_template('cart.html',
                         cart_items=cart_items,
                         collector_url=COLLECTOR_URL)


@app.route('/checkout')
def checkout():
    """Checkout/payment page."""
    cart_items = session.get('cart', [])
    total = sum(item.get('price', 0) for item in cart_items)

    return render_template('checkout.html',
                         cart_items=cart_items,
                         total=total,
                         collector_url=COLLECTOR_URL)


@app.route('/api/cart/add', methods=['POST'])
def add_to_cart():
    """Add item to cart."""
    data = request.json

    if 'cart' not in session:
        session['cart'] = []

    # Check if item already in cart — increment quantity instead of duplicating
    for item in session['cart']:
        if item.get('product_id') == data.get('product_id'):
            item['quantity'] = item.get('quantity', 1) + 1
            session.modified = True
            return jsonify({'success': True, 'cart_size': len(session['cart'])})

    session['cart'].append({
        'product_id': data.get('product_id'),
        'name': data.get('name'),
        'price': data.get('price'),
        'quantity': 1,
    })
    session.modified = True

    return jsonify({'success': True, 'cart_size': len(session['cart'])})


@app.route('/api/cart/remove', methods=['POST'])
def remove_from_cart():
    """Remove item from cart."""
    data = request.json
    product_id = data.get('product_id')
    cart = session.get('cart', [])
    session['cart'] = [item for item in cart if item.get('product_id') != product_id]
    session.modified = True
    return jsonify({'success': True, 'cart_size': len(session['cart'])})


@app.route('/api/track', methods=['POST'])
def track():
    """
    Local tracking endpoint — kept for backward compatibility.

    The JS tracker sends events to the collector (primary).
    This endpoint is a no-op stub.
    """
    return jsonify({'ok': True})


@app.route('/success')
def success():
    """Order success page."""
    # Clear cart
    session['cart'] = []
    session.modified = True

    return render_template('success.html', collector_url=COLLECTOR_URL)


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000, debug=True)
