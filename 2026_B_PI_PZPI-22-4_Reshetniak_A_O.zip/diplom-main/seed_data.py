"""Seed database with example scenarios."""

import asyncio
import sys
from sqlalchemy import select
from shared.database import AsyncSessionLocal
from shared.models import Scenario


async def seed_scenarios():
    """Create example scenarios."""
    db = AsyncSessionLocal()

    scenarios = [
        {
            "name": "Impatient Mobile Shopper",
            "description": "Quick-scanning mobile user from social media ad",
            "persona_prompt": """
                You are an impatient online shopper browsing on your phone. 
                You came from a social media ad that caught your eye. 
                You quickly scan pages — if something doesn't grab your attention in a few seconds, you leave. 
                You rarely scroll past the first screen. 
                You might impulsively click "Buy Now" if the price looks right, but you'll abandon checkout if the form asks for too much information. 
                You never read terms and conditions. You type fast and make typos.
            """,
            "target_urls": {"start": "http://mock-website:3000/landing"},
            "funnel_config": {
                "max_actions": 20,
                "max_time_seconds": 120,
                "action_delay_min": 0.5,
                "action_delay_max": 3.0,
                "purchase_intent_min": 0.2,
                "purchase_intent_max": 0.6,
                "patience_min": 0.05,
                "patience_max": 0.3,
            },
        },
        {
            "name": "Careful Research Buyer",
            "description": "Methodical shopper who reads everything thoroughly",
            "persona_prompt": """
                You are a methodical shopper who always does thorough research before buying. 
                You read every product description completely. 
                You scroll through the entire page looking for reviews, specifications, and pricing details. 
                You compare options before deciding. 
                You're very likely to complete a purchase if the product meets your criteria, and you fill out forms carefully and completely. 
                You might go back to previous pages to re-check information.
            """,
            "target_urls": {"start": "http://mock-website:3000/landing"},
            "funnel_config": {
                "max_actions": 40,
                "max_time_seconds": 300,
                "action_delay_min": 2.0,
                "action_delay_max": 6.0,
                "purchase_intent_min": 0.6,
                "purchase_intent_max": 0.95,
                "patience_min": 0.5,
                "patience_max": 0.9,
            },
        },
        {
            "name": "Window Shopper",
            "description": "Casual browser with no real intent to buy",
            "persona_prompt": """
                You are casually browsing with no real intention to buy. 
                You clicked on an ad out of curiosity. 
                You browse around, look at a few products, maybe scroll through some images, but never add anything to cart. 
                You spend moderate time on pages — you're not in a rush, but you're not deeply engaged either. 
                After looking at 3-5 pages, you leave.
            """,
            "target_urls": {"start": "http://mock-website:3000/landing"},
            "funnel_config": {
                "max_actions": 15,
                "max_time_seconds": 90,
                "action_delay_min": 1.0,
                "action_delay_max": 4.0,
                "purchase_intent_min": 0.0,
                "purchase_intent_max": 0.15,
                "patience_min": 0.2,
                "patience_max": 0.5,
            },
        },
        {
            "name": "Deal Hunter",
            "description": "Price-focused shopper looking for best deals",
            "persona_prompt": """
                You are obsessed with finding the best deal. 
                You immediately look for price information, discount badges, and sale indicators. 
                If you don't see a good price quickly, you leave. 
                If you find a deal, you rush to checkout before it expires. 
                You skip reading descriptions and go straight to price and "Add to Cart". 
                You're frustrated by long checkout processes.
            """,
            "target_urls": {"start": "http://mock-website:3000/landing"},
            "funnel_config": {
                "max_actions": 25,
                "max_time_seconds": 150,
                "action_delay_min": 0.3,
                "action_delay_max": 2.0,
                "purchase_intent_min": 0.5,
                "purchase_intent_max": 0.85,
                "patience_min": 0.1,
                "patience_max": 0.4,
            },
        },
        {
            "name": "Guaranteed Buyer (Test)",
            "description": "Test scenario: always completes purchase. Use to verify checkout flow works end-to-end.",
            "persona_prompt": """
                You are a determined buyer who came to this website specifically to make a purchase.
                You navigate efficiently: landing → product → add to cart → checkout → complete purchase.
                When you see a form, you MUST fill out EVERY empty field using your identity data, then click the submit button.
                Fill fields one by one from top to bottom. Never skip a field. Never leave without buying.
                After filling all fields, ALWAYS click the "Complete Purchase" button.
                You do not hesitate, you do not browse — you buy.
            """,
            "target_urls": {"start": "http://mock-website:3000/landing"},
            "funnel_config": {
                "max_actions": 35,
                "max_time_seconds": 200,
                "action_delay_min": 0.3,
                "action_delay_max": 1.0,
                "purchase_intent_min": 0.95,
                "purchase_intent_max": 1.0,
                "patience_min": 0.8,
                "patience_max": 1.0,
            },
        },
    ]

    created_count = 0

    for scenario_data in scenarios:
        # Check if scenario already exists
        result = await db.execute(
            select(Scenario).where(Scenario.name == scenario_data["name"])
        )
        existing = result.scalar_one_or_none()

        if not existing:
            scenario = Scenario(**scenario_data)
            db.add(scenario)
            created_count += 1
            print(f"✓ Created scenario: {scenario_data['name']}")
        else:
            # Update existing scenario with new config
            for key, value in scenario_data.items():
                if key != "name":
                    setattr(existing, key, value)
            print(f"↻ Updated scenario: {scenario_data['name']}")

    await db.commit()
    await db.close()

    print(f"\n✓ Seeding complete. Created {created_count} new scenarios.")


if __name__ == "__main__":
    asyncio.run(seed_scenarios())
