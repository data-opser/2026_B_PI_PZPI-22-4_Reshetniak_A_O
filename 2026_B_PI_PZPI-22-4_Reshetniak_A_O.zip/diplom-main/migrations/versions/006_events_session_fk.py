"""Restore FK link events -> sessions via simulation_session_id.

For simulated traffic the worker pre-sets the _stg_id cookie to the
session UUID, so the collector receives events with visitor_id equal to
that UUID as a string. This migration adds a typed UUID FK column to
events and backfills it for existing rows.

Revision ID: 006
Revises: 005
Create Date: 2026-06-08
"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "006"
down_revision = "005"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.add_column(
        "events",
        sa.Column(
            "simulation_session_id",
            postgresql.UUID(as_uuid=True),
            nullable=True,
        ),
    )
    op.create_foreign_key(
        "events_simulation_session_id_fkey",
        "events",
        "sessions",
        ["simulation_session_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.create_index(
        "idx_events_simulation_session",
        "events",
        ["simulation_session_id"],
    )

    # Backfill: link events whose visitor_id is a UUID that matches a session.
    op.execute(
        """
        UPDATE events e
        SET simulation_session_id = s.id
        FROM sessions s
        WHERE e.simulation_session_id IS NULL
          AND e.visitor_id ~ '^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$'
          AND s.id = e.visitor_id::uuid
        """
    )


def downgrade() -> None:
    op.drop_index("idx_events_simulation_session", table_name="events")
    op.drop_constraint("events_simulation_session_id_fkey", "events", type_="foreignkey")
    op.drop_column("events", "simulation_session_id")
