"""Initial schema

Revision ID: 001
Revises:
Create Date: 2025-02-12

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    # Create scenarios table
    op.create_table(
        'scenarios',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('description', sa.Text(), nullable=True),
        sa.Column('persona_prompt', sa.Text(), nullable=False),
        sa.Column('target_urls', postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column('funnel_config', postgresql.JSONB(astext_type=sa.Text()), server_default='{}', nullable=False),
        sa.Column('device_pool', postgresql.JSONB(astext_type=sa.Text()), server_default='[]', nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('name')
    )

    # Create generation_jobs table
    op.create_table(
        'generation_jobs',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('scenario_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('total_sessions', sa.Integer(), nullable=False),
        sa.Column('completed_sessions', sa.Integer(), server_default='0', nullable=False),
        sa.Column('failed_sessions', sa.Integer(), server_default='0', nullable=False),
        sa.Column('status', sa.String(length=20), server_default="'pending'", nullable=False),
        sa.Column('config_override', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.Column('schedule_cron', sa.String(length=100), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.CheckConstraint('total_sessions > 0', name='check_total_sessions_positive'),
        sa.CheckConstraint("status IN ('pending', 'running', 'completed', 'cancelled', 'failed')", name='check_job_status'),
        sa.ForeignKeyConstraint(['scenario_id'], ['scenarios.id'], ),
        sa.PrimaryKeyConstraint('id')
    )

    # Create sessions table
    op.create_table(
        'sessions',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('job_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('scenario_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('status', sa.String(length=20), server_default="'pending'", nullable=False),
        sa.Column('user_profile', postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column('result', sa.String(length=50), nullable=True),
        sa.Column('total_actions', sa.Integer(), server_default='0', nullable=False),
        sa.Column('total_events', sa.Integer(), server_default='0', nullable=False),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('started_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('finished_at', sa.DateTime(timezone=True), nullable=True),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.CheckConstraint("status IN ('pending', 'running', 'completed', 'failed', 'timeout')", name='check_session_status'),
        sa.ForeignKeyConstraint(['job_id'], ['generation_jobs.id'], ),
        sa.ForeignKeyConstraint(['scenario_id'], ['scenarios.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_sessions_job_status', 'sessions', ['job_id', 'status'])
    op.create_index('idx_sessions_scenario', 'sessions', ['scenario_id'])

    # Create events table
    op.create_table(
        'events',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('session_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('event_type', sa.String(length=50), nullable=False),
        sa.Column('page_url', sa.Text(), nullable=False),
        sa.Column('page_title', sa.String(length=500), nullable=True),
        sa.Column('element_selector', sa.Text(), nullable=True),
        sa.Column('element_text', sa.String(length=500), nullable=True),
        sa.Column('element_role', sa.String(length=50), nullable=True),
        sa.Column('event_data', postgresql.JSONB(astext_type=sa.Text()), server_default='{}', nullable=False),
        sa.Column('sequence_number', sa.Integer(), nullable=False),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['session_id'], ['sessions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_events_event_type', 'events', ['event_type'])
    op.create_index('idx_events_session_id', 'events', ['session_id'])
    op.create_index('idx_events_session_seq', 'events', ['session_id', 'sequence_number'])
    op.create_index('idx_events_timestamp', 'events', ['timestamp'])

    # Create agent_decisions table
    op.create_table(
        'agent_decisions',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('session_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('step_number', sa.Integer(), nullable=False),
        sa.Column('page_url', sa.Text(), nullable=False),
        sa.Column('page_state_summary', sa.Text(), nullable=False),
        sa.Column('llm_raw_response', sa.Text(), nullable=False),
        sa.Column('llm_thought', sa.Text(), nullable=True),
        sa.Column('action_taken', postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column('llm_model', sa.String(length=100), nullable=False),
        sa.Column('response_time_ms', sa.Integer(), nullable=False),
        sa.Column('parse_success', sa.Boolean(), nullable=False),
        sa.Column('retry_count', sa.Integer(), server_default='0', nullable=False),
        sa.Column('timestamp', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['session_id'], ['sessions.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_decisions_session', 'agent_decisions', ['session_id', 'step_number'])

    # Create webhook_endpoints table
    op.create_table(
        'webhook_endpoints',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('name', sa.String(length=255), nullable=False),
        sa.Column('url', sa.Text(), nullable=False),
        sa.Column('secret', sa.String(length=255), nullable=True),
        sa.Column('headers', postgresql.JSONB(astext_type=sa.Text()), server_default='{}', nullable=False),
        sa.Column('event_filter', postgresql.ARRAY(sa.String()), server_default='{}', nullable=False),
        sa.Column('is_active', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.PrimaryKeyConstraint('id')
    )

    # Create webhook_logs table
    op.create_table(
        'webhook_logs',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        sa.Column('endpoint_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('event_id', postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column('attempt', sa.Integer(), server_default='1', nullable=False),
        sa.Column('status_code', sa.Integer(), nullable=True),
        sa.Column('request_body', postgresql.JSONB(astext_type=sa.Text()), nullable=False),
        sa.Column('response_body', sa.Text(), nullable=True),
        sa.Column('error_message', sa.Text(), nullable=True),
        sa.Column('success', sa.Boolean(), nullable=False),
        sa.Column('duration_ms', sa.Integer(), nullable=True),
        sa.Column('sent_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['endpoint_id'], ['webhook_endpoints.id'], ),
        sa.ForeignKeyConstraint(['event_id'], ['events.id'], ),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(
        'idx_webhook_logs_retry',
        'webhook_logs',
        ['endpoint_id', 'success', 'attempt'],
        postgresql_where=sa.text('success = false')
    )


def downgrade() -> None:
    op.drop_table('webhook_logs')
    op.drop_table('webhook_endpoints')
    op.drop_table('agent_decisions')
    op.drop_table('events')
    op.drop_table('sessions')
    op.drop_table('generation_jobs')
    op.drop_table('scenarios')
