"""Combined: scenario_filter, users/api_tokens, job user_id, seed users, webhook user_id

Merges former revisions 002–006 into one (fresh installs).

If your database was already at revision 006 with the old chain, after upgrading
code run: ``alembic stamp 002`` (schema must already match this migration).

Revision ID: 003
Revises: 002
Create Date: 2025-03-18

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy import text
from sqlalchemy.dialects import postgresql

revision = "003"
down_revision = "002"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # --- was 002: scenario_filter on webhooks ---
    op.add_column(
        "webhook_endpoints",
        sa.Column(
            "scenario_filter",
            postgresql.ARRAY(postgresql.UUID(as_uuid=True)),
            server_default="{}",
            nullable=False,
        ),
    )

    # --- was 003: users, api_tokens, generation_jobs.user_id ---
    op.create_table(
        "users",
        sa.Column("id", postgresql.UUID(as_uuid=True), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=False),
        sa.Column("password", sa.String(length=255), nullable=False),
        sa.Column("role", sa.Text(), server_default=sa.text("'user'"), nullable=False),
        sa.Column("is_active", sa.Boolean(), server_default=sa.text("true"), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.PrimaryKeyConstraint("id"),
    )

    op.create_table(
        "api_tokens",
        sa.Column("id", postgresql.UUID(as_uuid=True), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("token_hash", sa.String(length=255), nullable=False),
        sa.Column("name", sa.String(length=255), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["user_id"], ["users.id"], ondelete="CASCADE"),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("token_hash", name="uq_api_tokens_token_hash"),
    )
    op.create_index("idx_api_tokens_user_id", "api_tokens", ["user_id"])

    op.add_column(
        "generation_jobs",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=True),
    )
    op.create_foreign_key(
        "fk_generation_jobs_user_id_users",
        "generation_jobs",
        "users",
        ["user_id"],
        ["id"],
        ondelete="SET NULL",
    )
    op.create_index("idx_generation_jobs_user_id", "generation_jobs", ["user_id"])

    # --- was 004 + 005: seed admin (admin/admin) and user (user/user) ---
    conn = op.get_bind()

    result = conn.execute(text("SELECT id FROM users WHERE name = 'admin' LIMIT 1"))
    if result.fetchone() is None:
        import bcrypt

        password_hash = bcrypt.hashpw(b"admin", bcrypt.gensalt()).decode()
        conn.execute(
            text("""
                INSERT INTO users (id, name, password, role, is_active, created_at, updated_at)
                VALUES (gen_random_uuid(), 'admin', :password, 'admin', true, now(), now())
            """),
            {"password": password_hash},
        )
    else:
        conn.execute(text("UPDATE users SET role = 'admin' WHERE name = 'admin'"))

    result = conn.execute(text("SELECT id FROM users WHERE name = 'user' LIMIT 1"))
    if result.fetchone() is None:
        import bcrypt

        password_hash = bcrypt.hashpw(b"user", bcrypt.gensalt()).decode()
        conn.execute(
            text("""
                INSERT INTO users (id, name, password, role, is_active, created_at, updated_at)
                VALUES (gen_random_uuid(), 'user', :password, 'user', true, now(), now())
            """),
            {"password": password_hash},
        )

    # --- was 006: webhook_endpoints.user_id ---
    op.add_column(
        "webhook_endpoints",
        sa.Column("user_id", postgresql.UUID(as_uuid=True), nullable=True),
    )
    conn.execute(
        text("""
            UPDATE webhook_endpoints
            SET user_id = (SELECT id FROM users ORDER BY created_at LIMIT 1)
            WHERE user_id IS NULL
        """)
    )
    op.alter_column(
        "webhook_endpoints",
        "user_id",
        existing_type=postgresql.UUID(as_uuid=True),
        nullable=False,
    )
    op.create_foreign_key(
        "fk_webhook_endpoints_user_id_users",
        "webhook_endpoints",
        "users",
        ["user_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.create_index("idx_webhook_endpoints_user_id", "webhook_endpoints", ["user_id"])


def downgrade() -> None:
    op.drop_index("idx_webhook_endpoints_user_id", table_name="webhook_endpoints")
    op.drop_constraint("fk_webhook_endpoints_user_id_users", "webhook_endpoints", type_="foreignkey")
    op.drop_column("webhook_endpoints", "user_id")

    op.drop_index("idx_generation_jobs_user_id", table_name="generation_jobs")
    op.drop_constraint("fk_generation_jobs_user_id_users", "generation_jobs", type_="foreignkey")
    op.drop_column("generation_jobs", "user_id")

    op.drop_index("idx_api_tokens_user_id", table_name="api_tokens")
    op.drop_table("api_tokens")
    op.drop_table("users")

    op.drop_column("webhook_endpoints", "scenario_filter")
