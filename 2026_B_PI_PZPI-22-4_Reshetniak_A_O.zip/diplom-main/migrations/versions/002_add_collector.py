"""Add collector: tracker_events table + event_source on events

Revision ID: 002
Revises: 001
Create Date: 2026-03-18

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = '002'
down_revision = '001'
branch_labels = None
depends_on = None


def upgrade() -> None:
    # ── New table: tracker_events (collector canonical output) ─────────────
    op.create_table(
        'tracker_events',
        sa.Column('id', postgresql.UUID(as_uuid=True), server_default=sa.text('gen_random_uuid()'), nullable=False),
        # Event identification
        sa.Column('event_type', sa.String(length=50), nullable=False),
        sa.Column('schema_version', sa.String(length=20), server_default='1.0', nullable=False),
        sa.Column('app_id', sa.String(length=100), server_default='mock-website', nullable=False),
        # Visitor / session
        sa.Column('visitor_id', sa.String(length=100), nullable=False),
        sa.Column('session_id', sa.String(length=100), nullable=True),
        # Page context
        sa.Column('page_url', sa.Text(), nullable=False),
        sa.Column('page_title', sa.String(length=500), nullable=True),
        sa.Column('page_referrer', sa.Text(), nullable=True),
        # Custom data
        sa.Column('event_data', postgresql.JSONB(astext_type=sa.Text()), server_default='{}', nullable=False),
        # UA enrichment
        sa.Column('useragent', sa.Text(), nullable=True),
        sa.Column('browser_family', sa.String(length=100), nullable=True),
        sa.Column('browser_version', sa.String(length=50), nullable=True),
        sa.Column('os_family', sa.String(length=100), nullable=True),
        sa.Column('os_version', sa.String(length=50), nullable=True),
        sa.Column('device_type', sa.String(length=20), nullable=True),
        # Funnel
        sa.Column('funnel_stage', sa.String(length=30), nullable=True),
        # Timestamps
        sa.Column('collector_tstamp', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('dvce_sent_tstamp', sa.DateTime(timezone=True), nullable=True),
        # Metadata
        sa.Column('collector_version', sa.String(length=20), server_default='1.0.0', nullable=False),
        sa.Column('ip_address', sa.String(length=45), nullable=True),
        # Validation
        sa.Column('is_valid', sa.Boolean(), server_default='true', nullable=False),
        sa.Column('validation_errors', postgresql.JSONB(astext_type=sa.Text()), nullable=True),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index('idx_tracker_events_visitor', 'tracker_events', ['visitor_id'])
    op.create_index('idx_tracker_events_event_type', 'tracker_events', ['event_type'])
    op.create_index('idx_tracker_events_collector_tstamp', 'tracker_events', ['collector_tstamp'])
    op.create_index('idx_tracker_events_funnel', 'tracker_events', ['funnel_stage'])
    op.create_index('idx_tracker_events_session', 'tracker_events', ['session_id'])
    op.create_index('idx_tracker_events_app', 'tracker_events', ['app_id'])

    # ── Add event_source to existing events table (agent audit stream) ────
    op.add_column(
        'events',
        sa.Column('event_source', sa.String(length=20), server_default='agent', nullable=False),
    )
    op.create_index('idx_events_source', 'events', ['event_source'])


def downgrade() -> None:
    op.drop_index('idx_events_source', table_name='events')
    op.drop_column('events', 'event_source')
    op.drop_table('tracker_events')
