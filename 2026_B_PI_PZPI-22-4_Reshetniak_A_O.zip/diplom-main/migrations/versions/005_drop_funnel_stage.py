"""Drop funnel_stage column from events — funnel logic belongs in analytics, not in raw data.

Revision ID: 005
Revises: 004
"""

from alembic import op

revision = "005"
down_revision = "004"
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.drop_index("idx_events_funnel", table_name="events")
    op.drop_column("events", "funnel_stage")


def downgrade() -> None:
    import sqlalchemy as sa

    op.add_column("events", sa.Column("funnel_stage", sa.String(30), nullable=True))
    op.create_index("idx_events_funnel", "events", ["funnel_stage"])
