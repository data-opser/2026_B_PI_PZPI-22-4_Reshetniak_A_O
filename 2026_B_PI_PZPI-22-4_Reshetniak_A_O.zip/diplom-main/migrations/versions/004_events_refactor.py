"""Drop old events table, rename tracker_events -> events, update webhook_logs FK.

Revision ID: 004
Revises: 003
Create Date: 2026-03-25

"""
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision = "004"
down_revision = "003"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # 1. Drop FK on webhook_logs.event_id -> old events table
    op.drop_constraint("webhook_logs_event_id_fkey", "webhook_logs", type_="foreignkey")

    # 2. Truncate webhook_logs (old event UUIDs won't exist in renamed table)
    op.execute("TRUNCATE TABLE webhook_logs")

    # 3. Drop old events table entirely
    op.drop_index("idx_events_session_id", table_name="events")
    op.drop_index("idx_events_event_type", table_name="events")
    op.drop_index("idx_events_timestamp", table_name="events")
    op.drop_index("idx_events_session_seq", table_name="events")
    op.drop_index("idx_events_source", table_name="events")
    op.drop_table("events")

    # 4. Rename tracker_events -> events
    op.rename_table("tracker_events", "events")

    # 5. Rename indexes
    op.execute("ALTER INDEX idx_tracker_events_visitor RENAME TO idx_events_visitor")
    op.execute("ALTER INDEX idx_tracker_events_event_type RENAME TO idx_events_event_type")
    op.execute("ALTER INDEX idx_tracker_events_collector_tstamp RENAME TO idx_events_collector_tstamp")
    op.execute("ALTER INDEX idx_tracker_events_funnel RENAME TO idx_events_funnel")
    op.execute("ALTER INDEX idx_tracker_events_session RENAME TO idx_events_session")
    op.execute("ALTER INDEX idx_tracker_events_app RENAME TO idx_events_app")

    # 6. Re-create FK on webhook_logs.event_id -> new events table
    op.create_foreign_key(
        "webhook_logs_event_id_fkey",
        "webhook_logs",
        "events",
        ["event_id"],
        ["id"],
    )


def downgrade() -> None:
    # Reverse: rename events back to tracker_events, recreate old events table
    op.drop_constraint("webhook_logs_event_id_fkey", "webhook_logs", type_="foreignkey")

    op.rename_table("events", "tracker_events")

    op.execute("ALTER INDEX idx_events_visitor RENAME TO idx_tracker_events_visitor")
    op.execute("ALTER INDEX idx_events_event_type RENAME TO idx_tracker_events_event_type")
    op.execute("ALTER INDEX idx_events_collector_tstamp RENAME TO idx_tracker_events_collector_tstamp")
    op.execute("ALTER INDEX idx_events_funnel RENAME TO idx_tracker_events_funnel")
    op.execute("ALTER INDEX idx_events_session RENAME TO idx_tracker_events_session")
    op.execute("ALTER INDEX idx_events_app RENAME TO idx_tracker_events_app")

    # Recreate old events table
    op.create_table(
        "events",
        sa.Column("id", postgresql.UUID(as_uuid=True), server_default=sa.text("gen_random_uuid()"), nullable=False),
        sa.Column("session_id", postgresql.UUID(as_uuid=True), nullable=False),
        sa.Column("event_type", sa.String(length=50), nullable=False),
        sa.Column("page_url", sa.Text(), nullable=False),
        sa.Column("page_title", sa.String(length=500), nullable=True),
        sa.Column("element_selector", sa.Text(), nullable=True),
        sa.Column("element_text", sa.String(length=500), nullable=True),
        sa.Column("element_role", sa.String(length=50), nullable=True),
        sa.Column("event_data", postgresql.JSONB(), server_default="{}", nullable=False),
        sa.Column("event_source", sa.String(length=20), server_default="agent", nullable=False),
        sa.Column("sequence_number", sa.Integer(), nullable=False),
        sa.Column("timestamp", sa.DateTime(timezone=True), server_default=sa.text("now()"), nullable=False),
        sa.ForeignKeyConstraint(["session_id"], ["sessions.id"]),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index("idx_events_session_id", "events", ["session_id"])
    op.create_index("idx_events_event_type", "events", ["event_type"])
    op.create_index("idx_events_timestamp", "events", ["timestamp"])
    op.create_index("idx_events_session_seq", "events", ["session_id", "sequence_number"])
    op.create_index("idx_events_source", "events", ["event_source"])

    op.create_foreign_key(
        "webhook_logs_event_id_fkey",
        "webhook_logs",
        "events",
        ["event_id"],
        ["id"],
    )
