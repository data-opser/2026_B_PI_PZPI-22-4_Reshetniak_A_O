#!/usr/bin/env python3
"""
Примеры запросов к API Synthetic Traffic Generator с API-токеном (stg_...).

  export STG_API_TOKEN='stg_...'
  export STG_API_BASE='http://localhost:8000/api/v1'   # по желанию

  python scripts/stg_api_fetch.py              # по умолчанию: /auth/me
  python scripts/stg_api_fetch.py me
  python scripts/stg_api_fetch.py events --limit 50
  python scripts/stg_api_fetch.py events --event-type click --limit 20

Зависимости: только стандартная библиотека Python 3.
"""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request


def get_token() -> str:
    return os.environ.get("STG_API_TOKEN", "").strip()


def fetch_json(url: str, token: str) -> tuple[str, str]:
    """GET url with Bearer token; returns (content_type, body text)."""
    req = urllib.request.Request(
        url,
        headers={
            "Authorization": f"Bearer {token}",
            "Accept": "application/json",
        },
        method="GET",
    )
    with urllib.request.urlopen(req, timeout=60) as resp:
        body = resp.read().decode()
        ctype = resp.headers.get("Content-Type", "")
    return ctype, body


def print_response(ctype: str, body: str) -> None:
    if "application/json" in ctype:
        try:
            print(json.dumps(json.loads(body), indent=2, ensure_ascii=False))
        except json.JSONDecodeError:
            print(body)
    else:
        print(body)


def cmd_me(base: str, token: str) -> int:
    url = f"{base}/auth/me"
    try:
        ctype, body = fetch_json(url, token)
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.reason}", file=sys.stderr)
        print(e.read().decode(errors="replace"), file=sys.stderr)
        return 1
    except urllib.error.URLError as e:
        print(f"Ошибка сети: {e.reason}", file=sys.stderr)
        return 1
    print_response(ctype, body)
    return 0


def cmd_events(base: str, token: str, args: argparse.Namespace) -> int:
    params: dict[str, str] = {"format": "json", "limit": str(args.limit)}
    if args.event_type:
        params["event_type"] = args.event_type
    if args.session_id:
        params["session_id"] = args.session_id
    if args.scenario_id:
        params["scenario_id"] = args.scenario_id
    if args.from_ts:
        params["from"] = args.from_ts
    if args.to_ts:
        params["to"] = args.to_ts
    if args.cursor:
        params["cursor"] = args.cursor

    qs = urllib.parse.urlencode(params)
    url = f"{base}/events?{qs}"
    try:
        ctype, body = fetch_json(url, token)
    except urllib.error.HTTPError as e:
        print(f"HTTP {e.code}: {e.reason}", file=sys.stderr)
        print(e.read().decode(errors="replace"), file=sys.stderr)
        return 1
    except urllib.error.URLError as e:
        print(f"Ошибка сети: {e.reason}", file=sys.stderr)
        return 1
    print_response(ctype, body)
    return 0


def main() -> int:
    token = get_token()
    if not token:
        print("Задайте STG_API_TOKEN (Bearer API-токен вида stg_...)", file=sys.stderr)
        return 1

    base = os.environ.get("STG_API_BASE", "http://localhost:8000/api/v1").rstrip("/")

    parser = argparse.ArgumentParser(description="STG API (Bearer token)")
    sub = parser.add_subparsers(dest="command", help="команда")

    sub.add_parser("me", help="GET /auth/me — текущий пользователь")

    p_ev = sub.add_parser("events", help="GET /events — список событий")
    p_ev.add_argument("--limit", type=int, default=100, help="до 10000 (по умолчанию 100)")
    p_ev.add_argument("--event-type", dest="event_type", help="фильтр: click, scroll, type, ...")
    p_ev.add_argument("--session-id", dest="session_id", help="UUID сессии")
    p_ev.add_argument("--scenario-id", dest="scenario_id", help="UUID сценария")
    p_ev.add_argument("--from", dest="from_ts", help="ISO timestamp начала периода")
    p_ev.add_argument("--to", dest="to_ts", help="ISO timestamp конца периода")
    p_ev.add_argument("--cursor", help="UUID курсор для постранички")

    argv = sys.argv[1:]
    if not argv:
        return cmd_me(base, token)

    args = parser.parse_args(argv)
    if args.command == "me":
        return cmd_me(base, token)
    if args.command == "events":
        return cmd_events(base, token, args)

    parser.print_help()
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
