"""Pydantic schemas for API request/response."""

from shared.schemas.auth import LoginRequest, TokenResponse, UserResponse
from shared.schemas.api_token import (
    ApiTokenCreate,
    ApiTokenResponse,
    ApiTokenCreatedResponse,
)
from shared.schemas.scenario import ScenarioCreate, ScenarioUpdate, ScenarioResponse
from shared.schemas.generation import GenerationRequest, JobResponse, JobStatus
from shared.schemas.session import SessionResponse, SessionDetail
from shared.schemas.event import EventResponse, EventFilter, EventStreamMessage
from shared.schemas.webhook import (
    WebhookCreate,
    WebhookUpdate,
    WebhookResponse,
    WebhookLogResponse,
    WebhookTestResponse,
)
from shared.schemas.stats import FunnelStats, ThroughputStats, AgentStats

__all__ = [
    "LoginRequest",
    "TokenResponse",
    "UserResponse",
    "ApiTokenCreate",
    "ApiTokenResponse",
    "ApiTokenCreatedResponse",
    "ScenarioCreate",
    "ScenarioUpdate",
    "ScenarioResponse",
    "GenerationRequest",
    "JobResponse",
    "JobStatus",
    "SessionResponse",
    "SessionDetail",
    "EventResponse",
    "EventFilter",
    "EventStreamMessage",
    "WebhookCreate",
    "WebhookUpdate",
    "WebhookResponse",
    "WebhookLogResponse",
    "WebhookTestResponse",
    "FunnelStats",
    "ThroughputStats",
    "AgentStats",
]
