"""Scenario schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field, field_validator


class ScenarioBase(BaseModel):
    """Base scenario schema."""

    name: str = Field(..., min_length=1, max_length=255)
    description: str | None = None
    persona_prompt: str = Field(..., min_length=1)
    target_urls: dict = Field(...)
    funnel_config: dict = Field(default_factory=dict)
    device_pool: list = Field(default_factory=list)

    @field_validator("target_urls")
    @classmethod
    def validate_target_urls(cls, v):
        """Validate that target_urls contains at least a start URL."""
        if "start" not in v:
            raise ValueError("target_urls must contain 'start' key")
        return v


class ScenarioCreate(ScenarioBase):
    """Schema for creating a scenario."""

    pass


class ScenarioUpdate(BaseModel):
    """Schema for updating a scenario."""

    name: str | None = Field(None, min_length=1, max_length=255)
    description: str | None = None
    persona_prompt: str | None = Field(None, min_length=1)
    target_urls: dict | None = None
    funnel_config: dict | None = None
    device_pool: list | None = None
    is_active: bool | None = None

    @field_validator("target_urls")
    @classmethod
    def validate_target_urls(cls, v):
        """Validate that target_urls contains at least a start URL."""
        if v is not None and "start" not in v:
            raise ValueError("target_urls must contain 'start' key")
        return v


class ScenarioResponse(ScenarioBase):
    """Schema for scenario response."""

    id: uuid.UUID
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
