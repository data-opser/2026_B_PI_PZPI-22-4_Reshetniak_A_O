"""API token schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class ApiTokenCreate(BaseModel):
    """Create API token (optional target user for admin)."""

    name: str | None = Field(None, max_length=255)
    expires_at: datetime | None = None
    user_id: uuid.UUID | None = Field(
        None, description="Admin only: create token for another user"
    )


class ApiTokenResponse(BaseModel):
    """API token metadata (no secret)."""

    id: uuid.UUID
    user_id: uuid.UUID
    owner_name: str | None = None
    name: str | None
    expires_at: datetime | None
    created_at: datetime

    class Config:
        from_attributes = True


class ApiTokenCreatedResponse(ApiTokenResponse):
    """Response right after creation — includes plaintext token once."""

    token: str = Field(..., description="Save this value; it will not be shown again")
