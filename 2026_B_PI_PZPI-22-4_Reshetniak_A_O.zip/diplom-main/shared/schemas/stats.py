"""Statistics schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel


class FunnelStage(BaseModel):
    """Schema for funnel stage."""

    name: str
    count: int
    percent: float


class FunnelStats(BaseModel):
    """Schema for funnel statistics."""

    total_sessions: int
    stages: list[FunnelStage]


class ThroughputBucket(BaseModel):
    """Schema for throughput bucket."""

    timestamp: datetime
    events: int
    sessions_started: int
    sessions_completed: int


class ThroughputStats(BaseModel):
    """Schema for throughput statistics."""

    buckets: list[ThroughputBucket]


class AgentStats(BaseModel):
    """Schema for agent statistics."""

    avg_llm_latency_ms: float
    p95_llm_latency_ms: float
    total_decisions: int
    parse_failure_rate: float
    action_distribution: dict[str, float]


class WebhookDeliveryByWebhook(BaseModel):
    """Deliveries grouped by webhook endpoint."""

    endpoint_id: uuid.UUID
    webhook_name: str
    owner_name: str | None = None
    delivery_count: int
    success_count: int


class WebhookDeliveryByEventType(BaseModel):
    """Deliveries grouped by event type."""

    event_type: str
    count: int


class WebhookDeliveryStats(BaseModel):
    """Webhook delivery statistics (events sent to webhook URLs)."""

    total_deliveries: int
    successful_deliveries: int
    failed_deliveries: int
    unique_events_delivered: int
    by_webhook: list[WebhookDeliveryByWebhook]
    by_event_type: list[WebhookDeliveryByEventType]
