"""Generation schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class GenerationRequest(BaseModel):
    """Schema for requesting traffic generation."""

    scenario_id: uuid.UUID
    num_sessions: int = Field(..., ge=1, le=10000)
    config_override: dict | None = None
    schedule_cron: str | None = None


class JobResponse(BaseModel):
    """Schema for generation job response."""

    id: uuid.UUID
    scenario_id: uuid.UUID
    scenario_name: str | None = None
    total_sessions: int
    completed_sessions: int
    failed_sessions: int
    status: str
    config_override: dict | None
    schedule_cron: str | None
    created_at: datetime
    started_at: datetime | None
    finished_at: datetime | None

    class Config:
        from_attributes = True


class JobStatus(BaseModel):
    """Schema for job status with progress."""

    id: uuid.UUID
    status: str
    total: int
    completed: int
    failed: int
    running: int
    percent_complete: float
