"""Webhook schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field, HttpUrl


class WebhookBase(BaseModel):
    """Base webhook schema."""

    name: str = Field(..., min_length=1, max_length=255)
    url: str  # HttpUrl but we'll validate as string for flexibility
    secret: str | None = None
    headers: dict = Field(default_factory=dict)
    event_filter: list[str] = Field(default_factory=list)
    scenario_filter: list[uuid.UUID] = Field(default_factory=list, description="Empty = all scenarios")


class WebhookCreate(WebhookBase):
    """Schema for creating a webhook."""

    pass


class WebhookUpdate(BaseModel):
    """Schema for updating a webhook."""

    name: str | None = Field(None, min_length=1, max_length=255)
    url: str | None = None
    secret: str | None = None
    headers: dict | None = None
    event_filter: list[str] | None = None
    scenario_filter: list[uuid.UUID] | None = None
    is_active: bool | None = None


class WebhookResponse(WebhookBase):
    """Schema for webhook response."""

    id: uuid.UUID
    user_id: uuid.UUID
    owner_name: str | None = None  # Set by API for admin view
    is_active: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class WebhookLogResponse(BaseModel):
    """Schema for webhook log response."""

    id: uuid.UUID
    endpoint_id: uuid.UUID
    event_id: uuid.UUID
    attempt: int
    status_code: int | None
    success: bool
    error_message: str | None
    duration_ms: int | None
    sent_at: datetime

    class Config:
        from_attributes = True


class WebhookTestResponse(BaseModel):
    """Schema for webhook test response."""

    success: bool
    status_code: int | None
    response_body: str | None
    duration_ms: int | None
    error_message: str | None
