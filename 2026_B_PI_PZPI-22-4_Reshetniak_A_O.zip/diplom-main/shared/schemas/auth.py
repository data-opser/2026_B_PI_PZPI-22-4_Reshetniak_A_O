"""Auth schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    """Login request body."""

    name: str = Field(..., min_length=1, max_length=255)
    password: str = Field(..., min_length=1)


class TokenResponse(BaseModel):
    """JWT token response."""

    access_token: str
    token_type: str = "bearer"


class UserResponse(BaseModel):
    """Current user info (for /me)."""

    id: uuid.UUID
    name: str
    role: str
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True
