"""Session schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel


class SessionResponse(BaseModel):
    """Schema for session response."""

    id: uuid.UUID
    job_id: uuid.UUID
    scenario_id: uuid.UUID
    status: str
    user_profile: dict
    result: str | None
    total_actions: int
    total_events: int
    error_message: str | None
    started_at: datetime | None
    finished_at: datetime | None
    created_at: datetime

    class Config:
        from_attributes = True


class SessionDetail(SessionResponse):
    """Schema for detailed session view with events and decisions."""

    events: list[dict]
    agent_decisions: list[dict]
