"""Event schemas."""

import uuid
from datetime import datetime
from pydantic import BaseModel, Field


class EventResponse(BaseModel):
    """Schema for event response."""

    id: uuid.UUID
    event_type: str
    visitor_id: str
    session_id: str | None
    page_url: str
    page_title: str | None
    page_referrer: str | None = None
    event_data: dict
    device_type: str | None = None
    browser_family: str | None = None
    os_family: str | None = None
    app_id: str
    collector_tstamp: datetime

    class Config:
        from_attributes = True


class EventFilter(BaseModel):
    """Schema for filtering events."""

    event_type: str | None = None
    session_id: str | None = None
    visitor_id: str | None = None
    from_timestamp: datetime | None = Field(None, alias="from")
    to_timestamp: datetime | None = Field(None, alias="to")
    cursor: uuid.UUID | None = None
    limit: int = Field(100, ge=1, le=10000)
    format: str = Field("json", pattern="^(json|csv)$")


class EventStreamMessage(BaseModel):
    """Schema for SSE event stream message."""

    event_id: uuid.UUID
    event_type: str
    timestamp: datetime
    session_id: str | None
    page_url: str
