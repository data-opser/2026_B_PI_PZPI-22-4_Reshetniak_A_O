"""User model."""

from sqlalchemy import Boolean, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from shared.models.api_token import ApiToken
    from shared.models.generation_job import GenerationJob
    from shared.models.webhook_endpoint import WebhookEndpoint


class User(Base, UUIDMixin, TimestampMixin):
    """User model - accounts for authentication and authorization."""

    __tablename__ = "users"

    name: Mapped[str] = mapped_column(String(255), nullable=False)
    password: Mapped[str] = mapped_column(String(255), nullable=False)  # hashed
    role: Mapped[str] = mapped_column(Text, nullable=False, server_default="'user'")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")

    # Relationships
    api_tokens: Mapped[list["ApiToken"]] = relationship(
        "ApiToken", back_populates="user", cascade="all, delete-orphan"
    )
    generation_jobs: Mapped[list["GenerationJob"]] = relationship(
        "GenerationJob", back_populates="user"
    )
    webhook_endpoints: Mapped[list["WebhookEndpoint"]] = relationship(
        "WebhookEndpoint", back_populates="user", cascade="all, delete-orphan"
    )
