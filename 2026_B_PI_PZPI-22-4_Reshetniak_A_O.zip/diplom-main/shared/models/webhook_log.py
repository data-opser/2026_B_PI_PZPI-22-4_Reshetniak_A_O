"""Webhook log model."""

import uuid
from datetime import datetime
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, UUIDMixin

if TYPE_CHECKING:
    from shared.models.webhook_endpoint import WebhookEndpoint
    from shared.models.event import Event


class WebhookLog(Base, UUIDMixin):
    """Webhook log model - delivery attempt log."""

    __tablename__ = "webhook_logs"

    endpoint_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("webhook_endpoints.id"), nullable=False
    )
    event_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("events.id"), nullable=False
    )
    attempt: Mapped[int] = mapped_column(Integer, nullable=False, server_default="1")
    status_code: Mapped[int | None] = mapped_column(Integer, nullable=True)
    request_body: Mapped[dict] = mapped_column(JSONB, nullable=False)
    response_body: Mapped[str | None] = mapped_column(Text, nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    success: Mapped[bool] = mapped_column(Boolean, nullable=False)
    duration_ms: Mapped[int | None] = mapped_column(Integer, nullable=True)
    sent_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default="now()"
    )

    # Relationships
    endpoint: Mapped["WebhookEndpoint"] = relationship(
        "WebhookEndpoint", back_populates="webhook_logs"
    )
    event: Mapped["Event"] = relationship("Event", back_populates="webhook_logs")
