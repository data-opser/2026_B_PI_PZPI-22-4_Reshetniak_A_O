"""Agent decision model."""

import uuid
from datetime import datetime
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, String, Text, Index
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, UUIDMixin

if TYPE_CHECKING:
    from shared.models.session import Session


class AgentDecision(Base, UUIDMixin):
    """Agent decision model - LLM decision log for debugging."""

    __tablename__ = "agent_decisions"

    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("sessions.id"), nullable=False
    )
    step_number: Mapped[int] = mapped_column(Integer, nullable=False)
    page_url: Mapped[str] = mapped_column(Text, nullable=False)
    page_state_summary: Mapped[str] = mapped_column(Text, nullable=False)
    llm_raw_response: Mapped[str] = mapped_column(Text, nullable=False)
    llm_thought: Mapped[str | None] = mapped_column(Text, nullable=True)
    action_taken: Mapped[dict] = mapped_column(JSONB, nullable=False)
    llm_model: Mapped[str] = mapped_column(String(100), nullable=False)
    response_time_ms: Mapped[int] = mapped_column(Integer, nullable=False)
    parse_success: Mapped[bool] = mapped_column(Boolean, nullable=False)
    retry_count: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    timestamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default="now()"
    )

    # Relationships
    session: Mapped["Session"] = relationship("Session", back_populates="agent_decisions")

    __table_args__ = (
        Index("idx_decisions_session", "session_id", "step_number"),
    )
