"""Generation job model."""

import uuid
from datetime import datetime
from sqlalchemy import DateTime, ForeignKey, Integer, String, CheckConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from shared.models.scenario import Scenario
    from shared.models.session import Session
    from shared.models.user import User


class GenerationJob(Base, UUIDMixin, TimestampMixin):
    """Generation job model - tracks batch generation runs."""

    __tablename__ = "generation_jobs"

    scenario_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("scenarios.id"), nullable=False
    )
    user_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    total_sessions: Mapped[int] = mapped_column(Integer, nullable=False)
    completed_sessions: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    failed_sessions: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'pending'"
    )
    config_override: Mapped[dict | None] = mapped_column(JSONB, nullable=True)
    schedule_cron: Mapped[str | None] = mapped_column(String(100), nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    scenario: Mapped["Scenario"] = relationship("Scenario", back_populates="generation_jobs")
    user: Mapped["User | None"] = relationship("User", back_populates="generation_jobs")
    sessions: Mapped[list["Session"]] = relationship(
        "Session", back_populates="generation_job", cascade="all, delete-orphan"
    )

    __table_args__ = (
        CheckConstraint("total_sessions > 0", name="check_total_sessions_positive"),
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'cancelled', 'failed')",
            name="check_job_status",
        ),
    )
