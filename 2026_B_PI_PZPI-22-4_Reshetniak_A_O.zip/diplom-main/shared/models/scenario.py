"""Scenario model."""

from sqlalchemy import Boolean, String, Text
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from shared.models.generation_job import GenerationJob
    from shared.models.session import Session


class Scenario(Base, UUIDMixin, TimestampMixin):
    """Scenario model - defines agent behavior templates."""

    __tablename__ = "scenarios"

    name: Mapped[str] = mapped_column(String(255), nullable=False, unique=True)
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    persona_prompt: Mapped[str] = mapped_column(Text, nullable=False)
    target_urls: Mapped[dict] = mapped_column(JSONB, nullable=False)
    funnel_config: Mapped[dict] = mapped_column(JSONB, nullable=False, server_default="{}")
    device_pool: Mapped[list] = mapped_column(JSONB, nullable=False, server_default="[]")
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")

    # Relationships
    generation_jobs: Mapped[list["GenerationJob"]] = relationship(
        "GenerationJob", back_populates="scenario", cascade="all, delete-orphan"
    )
    sessions: Mapped[list["Session"]] = relationship(
        "Session", back_populates="scenario"
    )
