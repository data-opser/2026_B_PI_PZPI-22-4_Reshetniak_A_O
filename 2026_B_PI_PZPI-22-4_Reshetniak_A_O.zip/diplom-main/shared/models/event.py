"""Event model — canonical analytics events from the JS tracker (collector pipeline)."""

import uuid
from datetime import datetime
from sqlalchemy import DateTime, ForeignKey, String, Text, Index, Boolean
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, UUIDMixin

if TYPE_CHECKING:
    from shared.models.webhook_log import WebhookLog
    from shared.models.session import Session


class Event(Base, UUIDMixin):
    """Canonical analytics event collected from website JS tracker."""

    __tablename__ = "events"

    # ── Event identification ──────────────────────────────────────────────
    event_type: Mapped[str] = mapped_column(String(50), nullable=False)
    schema_version: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="1.0"
    )
    app_id: Mapped[str] = mapped_column(
        String(100), nullable=False, server_default="mock-website"
    )

    # ── Visitor / session context ─────────────────────────────────────────
    visitor_id: Mapped[str] = mapped_column(String(100), nullable=False)
    session_id: Mapped[str | None] = mapped_column(String(100), nullable=True)

    # FK to our internal sessions table — populated for simulated traffic where
    # the worker pre-sets the _stg_id cookie to the session UUID.
    simulation_session_id: Mapped[uuid.UUID | None] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("sessions.id", ondelete="SET NULL"),
        nullable=True,
    )

    # ── Page context ──────────────────────────────────────────────────────
    page_url: Mapped[str] = mapped_column(Text, nullable=False)
    page_title: Mapped[str | None] = mapped_column(String(500), nullable=True)
    page_referrer: Mapped[str | None] = mapped_column(Text, nullable=True)

    # ── Custom event data ─────────────────────────────────────────────────
    event_data: Mapped[dict] = mapped_column(
        JSONB, nullable=False, server_default="{}"
    )

    # ── Enrichment: user agent ────────────────────────────────────────────
    useragent: Mapped[str | None] = mapped_column(Text, nullable=True)
    browser_family: Mapped[str | None] = mapped_column(String(100), nullable=True)
    browser_version: Mapped[str | None] = mapped_column(String(50), nullable=True)
    os_family: Mapped[str | None] = mapped_column(String(100), nullable=True)
    os_version: Mapped[str | None] = mapped_column(String(50), nullable=True)
    device_type: Mapped[str | None] = mapped_column(String(20), nullable=True)

    # ── Timestamps ────────────────────────────────────────────────────────
    collector_tstamp: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, server_default="now()"
    )
    dvce_sent_tstamp: Mapped[datetime | None] = mapped_column(
        DateTime(timezone=True), nullable=True
    )

    # ── Collector metadata ────────────────────────────────────────────────
    collector_version: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="1.0.0"
    )
    ip_address: Mapped[str | None] = mapped_column(String(45), nullable=True)

    # ── Validation ────────────────────────────────────────────────────────
    is_valid: Mapped[bool] = mapped_column(
        Boolean, nullable=False, server_default="true"
    )
    validation_errors: Mapped[list | None] = mapped_column(JSONB, nullable=True)

    # Relationships
    webhook_logs: Mapped[list["WebhookLog"]] = relationship(
        "WebhookLog", back_populates="event", cascade="all, delete-orphan"
    )
    simulation_session: Mapped["Session | None"] = relationship(
        "Session", back_populates="events"
    )

    __table_args__ = (
        Index("idx_events_visitor", "visitor_id"),
        Index("idx_events_event_type", "event_type"),
        Index("idx_events_collector_tstamp", "collector_tstamp"),
        Index("idx_events_session", "session_id"),
        Index("idx_events_app", "app_id"),
        Index("idx_events_simulation_session", "simulation_session_id"),
    )
