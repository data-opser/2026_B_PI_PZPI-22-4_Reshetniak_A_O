"""Session model."""

import uuid
from datetime import datetime
from sqlalchemy import DateTime, ForeignKey, Integer, String, Text, CheckConstraint
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from shared.models.scenario import Scenario
    from shared.models.generation_job import GenerationJob
    from shared.models.agent_decision import AgentDecision
    from shared.models.event import Event


class Session(Base, UUIDMixin, TimestampMixin):
    """Session model - one virtual user journey."""

    __tablename__ = "sessions"

    job_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("generation_jobs.id"), nullable=False
    )
    scenario_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("scenarios.id"), nullable=False
    )
    status: Mapped[str] = mapped_column(
        String(20), nullable=False, server_default="'pending'"
    )
    user_profile: Mapped[dict] = mapped_column(JSONB, nullable=False)
    result: Mapped[str | None] = mapped_column(String(50), nullable=True)
    total_actions: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    total_events: Mapped[int] = mapped_column(Integer, nullable=False, server_default="0")
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    started_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)

    # Relationships
    generation_job: Mapped["GenerationJob"] = relationship(
        "GenerationJob", back_populates="sessions"
    )
    scenario: Mapped["Scenario"] = relationship("Scenario", back_populates="sessions")
    agent_decisions: Mapped[list["AgentDecision"]] = relationship(
        "AgentDecision", back_populates="session", cascade="all, delete-orphan"
    )
    events: Mapped[list["Event"]] = relationship(
        "Event", back_populates="simulation_session"
    )

    __table_args__ = (
        CheckConstraint(
            "status IN ('pending', 'running', 'completed', 'failed', 'timeout')",
            name="check_session_status",
        ),
    )
