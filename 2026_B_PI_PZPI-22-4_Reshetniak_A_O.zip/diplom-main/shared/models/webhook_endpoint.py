"""Webhook endpoint model."""

import uuid
from sqlalchemy import Boolean, ForeignKey, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, JSONB, UUID
from sqlalchemy.orm import Mapped, mapped_column, relationship
from typing import TYPE_CHECKING

from shared.models.base import Base, TimestampMixin, UUIDMixin

if TYPE_CHECKING:
    from shared.models.user import User
    from shared.models.webhook_log import WebhookLog


class WebhookEndpoint(Base, UUIDMixin, TimestampMixin):
    """Webhook endpoint model - configured HTTP endpoints for event notifications."""

    __tablename__ = "webhook_endpoints"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    name: Mapped[str] = mapped_column(String(255), nullable=False)
    url: Mapped[str] = mapped_column(Text, nullable=False)
    secret: Mapped[str | None] = mapped_column(String(255), nullable=True)
    headers: Mapped[dict] = mapped_column(JSONB, nullable=False, server_default="{}")
    event_filter: Mapped[list[str]] = mapped_column(
        ARRAY(String), nullable=False, server_default="{}"
    )
    scenario_filter: Mapped[list[uuid.UUID]] = mapped_column(
        ARRAY(UUID(as_uuid=True)), nullable=False, server_default="{}"
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, server_default="true")

    # Relationships
    user: Mapped["User"] = relationship("User", back_populates="webhook_endpoints")
    webhook_logs: Mapped[list["WebhookLog"]] = relationship(
        "WebhookLog", back_populates="endpoint", cascade="all, delete-orphan"
    )
