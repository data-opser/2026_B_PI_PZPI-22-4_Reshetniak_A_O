"""
Local webhook receiver for testing.
The first received request does NOT acknowledge delivery (returns 500).
All subsequent requests respond with 200 OK and log the body.
"""

import json
from collections import deque
from datetime import datetime, timezone
from flask import Flask, request, jsonify

app = Flask(__name__)

# Request counter: first one is not acknowledged, rest are
_request_count = 0

# Last N received events
_MAX_EVENTS = 100
_events: deque = deque(maxlen=_MAX_EVENTS)


@app.route("/", methods=["GET"])
def index():
    return {
        "service": "webhook-receiver",
        "usage": "POST JSON here. First request returns 500 (no ack), rest return 200.",
        "request_count": _request_count,
        "stored_events": len(_events),
        "endpoints": {
            "GET /events": "List received events (?limit=10)",
            "GET /events/stats": "Aggregated stats by event_type",
        },
    }


@app.route("/events", methods=["GET"])
def list_events():
    """Return last N received events (newest first). ?limit=10 by default."""
    limit = request.args.get("limit", 10, type=int)
    event_type = request.args.get("type", None)

    items = list(reversed(_events))
    if event_type:
        items = [e for e in items if e.get("event_type") == event_type]
    items = items[:limit]

    return jsonify({"count": len(items), "total": len(_events), "items": items})


@app.route("/events/stats", methods=["GET"])
def event_stats():
    """Aggregated stats by event_type."""
    stats: dict[str, int] = {}
    for e in _events:
        et = e.get("event_type", "unknown")
        stats[et] = stats.get(et, 0) + 1
    return jsonify({
        "total": len(_events),
        "by_type": dict(sorted(stats.items(), key=lambda x: -x[1])),
    })


def _log_request():
    """Print the full request to console."""
    try:
        body = request.get_json(force=True, silent=True) or {}
        body_str = json.dumps(body, ensure_ascii=False, indent=2)
    except Exception:
        body = {}
        body_str = "(parse error)"

    print("\n" + "=" * 60)
    print(f"  [{request.method}] {request.url}")
    print("  Headers:")
    for k, v in request.headers:
        if k.lower() != "authorization":
            print(f"    {k}: {v}")
        else:
            print(f"    {k}: ***")
    print("  Body:")
    for line in body_str.splitlines():
        print(f"    {line}")
    print("=" * 60 + "\n")


@app.route("/", methods=["POST"])
@app.route("/webhook", methods=["POST"])
def receive_webhook():
    global _request_count
    _request_count += 1

    _log_request()

    try:
        body = request.get_json(force=True, silent=True) or {}
    except Exception:
        body = {}

    event_id = body.get("event_id", "?")
    event_type = body.get("event_type", "?")

    _events.append({
        "received_at": datetime.now(timezone.utc).isoformat(),
        "request_number": _request_count,
        "event_id": event_id,
        "event_type": event_type,
        "body": body,
    })

    # First request — do not acknowledge delivery (simulate a failure before responding)
    if _request_count == 1:
        print(f"[{_request_count}] First request — NOT acknowledging (500): event_id={event_id} event_type={event_type}")
        return jsonify({"error": "Simulated first delivery failure"}), 500

    # All subsequent — normal acknowledgement
    print(f"[{_request_count}] OK (200): event_id={event_id} event_type={event_type}")
    return jsonify({"received": True, "event_id": event_id, "request_number": _request_count}), 200


if __name__ == "__main__":
    print("Webhook receiver: first POST -> 500, rest -> 200")
    print("Endpoints:")
    print("  GET  /             - service info")
    print("  GET  /events       - list received events (?limit=10&type=page_view)")
    print("  GET  /events/stats - stats by event_type")
    print("  POST /             - receive webhook")
    print("  POST /webhook      - receive webhook")
    print()
    print("Run: python app.py  ->  http://127.0.0.1:5050")
    app.run(host="0.0.0.0", port=5050, debug=True)
