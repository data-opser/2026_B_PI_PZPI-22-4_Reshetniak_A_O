# Webhook receiver (тестовый)

Локальный приёмник для проверки доставки вебхуков.

- **Первый** POST-запрос → ответ **500** (доставка не подтверждается, платформа сделает retry).
- **Все последующие** POST-запросы → ответ **200** и тело `{"received": true, ...}`.

## Запуск

```bash
cd webhook-receiver
pip install -r requirements.txt
python app.py
```

Сервер: **http://127.0.0.1:5050**

## Проверка

```bash
# Первый запрос — 500
curl -X POST http://127.0.0.1:5050/ -H "Content-Type: application/json" -d '{"event_id":"a","event_type":"click"}'

# Второй и дальше — 200
curl -X POST http://127.0.0.1:5050/ -H "Content-Type: application/json" -d '{"event_id":"b","event_type":"click"}'
```

В вебхуках платформы укажи URL: `http://127.0.0.1:5050/` или `http://host.docker.internal:5050/` если запросы идут из Docker.
