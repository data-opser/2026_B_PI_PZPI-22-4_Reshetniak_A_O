#!/bin/sh
# Ollama Keep-Alive Script
# Prevents model from being paged out of memory by sending periodic requests

MODEL="${OLLAMA_MODEL:-qwen2.5:7b}"
INTERVAL=45  # seconds between pings

# Install curl if not present
if ! command -v curl > /dev/null; then
    apk add --no-cache curl > /dev/null 2>&1
fi

echo "🔥 Ollama Keep-Alive starting for model: $MODEL"
echo "Ping interval: ${INTERVAL}s"

while true; do
    # Send a minimal request to keep model warm
    curl -s http://ollama:11434/api/generate -d "{
        \"model\": \"$MODEL\",
        \"prompt\": \"ok\",
        \"stream\": false,
        \"options\": {
            \"num_predict\": 1
        }
    }" > /dev/null 2>&1

    if [ $? -eq 0 ]; then
        echo "$(date '+%Y-%m-%d %H:%M:%S') ✓ Keep-alive ping sent"
    else
        echo "$(date '+%Y-%m-%d %H:%M:%S') ✗ Keep-alive ping failed"
    fi

    sleep $INTERVAL
done
