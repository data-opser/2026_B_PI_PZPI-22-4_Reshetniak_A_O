"""Celery Beat app configuration for scheduler."""

from celery import Celery
from celery.schedules import crontab
from shared.config import settings

# Create Celery app
celery_app = Celery(
    "stg_scheduler",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

# Celery configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_default_queue="scheduler",  # Scheduler tasks go to scheduler queue
    task_routes={
        "scheduler.tasks.*": {"queue": "scheduler"},
        "worker.tasks.deliver_webhook_retry": {"queue": "webhooks"},
        "worker.tasks.*": {"queue": "celery"},
    },
)

# Beat schedule - periodic tasks
celery_app.conf.beat_schedule = {
    "check-scheduled-jobs": {
        "task": "scheduler.tasks.check_scheduled_jobs",
        "schedule": 60.0,  # Every 60 seconds
    },
    "monitor-job-health": {
        "task": "scheduler.tasks.monitor_job_health",
        "schedule": 30.0,  # Every 30 seconds
    },
    "retry-failed-webhooks": {
        "task": "scheduler.tasks.retry_failed_webhooks",
        "schedule": 60.0,  # Every 60 seconds
    },
}

# Auto-discover tasks (only scheduler tasks - worker tasks run in worker container)
celery_app.autodiscover_tasks(["scheduler"])
