"""Scheduler entry point (Celery Beat)."""

from scheduler.celery_app import celery_app

# Import tasks to register them
import scheduler.tasks.periodic_tasks

if __name__ == "__main__":
    celery_app.start()
