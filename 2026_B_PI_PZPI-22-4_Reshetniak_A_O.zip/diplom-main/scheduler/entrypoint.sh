#!/bin/bash
set -e

# Start Celery Beat in the background
celery -A scheduler.celery_app beat --loglevel=info &

# Start Celery Worker for scheduler queue (foreground)
celery -A scheduler.celery_app worker -Q scheduler --loglevel=info --concurrency=2
