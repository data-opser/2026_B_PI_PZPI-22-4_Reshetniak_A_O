"""Periodic tasks for the scheduler.

Uses a fresh async engine/session per task run so connections are bound to the
current event loop (Celery workers fork, so the global engine must not be shared).
"""

import asyncio
from contextlib import asynccontextmanager
from datetime import datetime, timezone, timedelta
from celery import group
from croniter import croniter
from sqlalchemy import and_, exists, func, literal, select, update
from sqlalchemy.orm import aliased
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from scheduler.celery_app import celery_app
from shared.config import settings
from shared.models import GenerationJob, WebhookLog


@asynccontextmanager
async def _scheduler_session():
    """Create engine and session in the current event loop (safe after Celery fork)."""
    engine = create_async_engine(
        settings.DATABASE_URL,
        echo=False,
        pool_size=1,
        max_overflow=0,
        pool_pre_ping=True,
    )
    session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    async with session_factory() as db:
        try:
            yield db
            await db.commit()
        except Exception:
            await db.rollback()
            raise
    await engine.dispose()


@celery_app.task(name="scheduler.tasks.check_scheduled_jobs")
def check_scheduled_jobs():
    """Check for scheduled jobs that need to be triggered."""
    return asyncio.run(check_scheduled_jobs_async())


def _should_trigger_now(cron_expr: str, now: datetime) -> bool:
    """True if the cron expression matches the current minute (we are in the scheduled slot)."""
    try:
        it = croniter(cron_expr, now)
        prev_run = it.get_prev(datetime)
        # Trigger if previous occurrence is in the same minute as now
        return prev_run.replace(second=0, microsecond=0) == now.replace(second=0, microsecond=0)
    except Exception:
        return False


def _dispatch_job_sessions(job_id: str, scenario_id: str, total_sessions: int, config_override: dict | None) -> None:
    """Dispatch Celery generate_session tasks to the worker queue (routed via scheduler task_routes)."""
    task_sig = celery_app.signature(
        "worker.tasks.generate_session",
        args=[job_id, scenario_id, config_override],
    )
    group([task_sig.clone() for _ in range(total_sessions)]).apply_async()


async def check_scheduled_jobs_async():
    """Check scheduled jobs and trigger those whose cron matches the current minute."""
    now = datetime.now(timezone.utc)
    triggered = 0

    async with _scheduler_session() as db:
        result = await db.execute(
            select(GenerationJob).where(
                GenerationJob.schedule_cron.isnot(None),
                GenerationJob.status == "pending",
            )
        )
        scheduled_jobs = result.scalars().all()

        for job in scheduled_jobs:
            if not _should_trigger_now(job.schedule_cron, now):
                continue

            _dispatch_job_sessions(
                str(job.id),
                str(job.scenario_id),
                job.total_sessions,
                job.config_override,
            )
            await db.execute(
                update(GenerationJob)
                .where(GenerationJob.id == job.id)
                .values(
                    status="running",
                    started_at=now,
                )
            )
            # Повторяющееся расписание: создаём клон джобы на следующий раз
            next_job = GenerationJob(
                scenario_id=job.scenario_id,
                total_sessions=job.total_sessions,
                config_override=job.config_override,
                schedule_cron=job.schedule_cron,
                status="pending",
            )
            db.add(next_job)
            triggered += 1

        return {"checked": len(scheduled_jobs), "triggered": triggered}


@celery_app.task(name="scheduler.tasks.monitor_job_health")
def monitor_job_health():
    """Monitor job health and mark stale jobs as failed."""
    return asyncio.run(monitor_job_health_async())


async def monitor_job_health_async():
    """Async implementation of job health monitoring."""
    async with _scheduler_session() as db:
        result = await db.execute(
            select(GenerationJob).where(GenerationJob.status == "running")
        )
        running_jobs = result.scalars().all()

        stale_count = 0
        for job in running_jobs:
            if job.started_at:
                max_time = job.total_sessions * 300 * 2  # 2x max time per session
                elapsed = (datetime.now(timezone.utc) - job.started_at).total_seconds()

                if elapsed > max_time:
                    await db.execute(
                        update(GenerationJob)
                        .where(GenerationJob.id == job.id)
                        .values(
                            status="failed",
                            finished_at=datetime.now(timezone.utc),
                        )
                    )
                    stale_count += 1

        return {"stale_jobs_marked": stale_count}


@celery_app.task(name="scheduler.tasks.retry_failed_webhooks")
def retry_failed_webhooks():
    """Retry failed webhook deliveries."""
    return asyncio.run(retry_failed_webhooks_async())


async def retry_failed_webhooks_async():
    """Async implementation of webhook retry logic.

    Only the **latest** log row per (endpoint_id, event_id) by ``attempt`` may be
    retried. Older failed rows are ignored once a newer attempt exists (fixes
    infinite retries: retry used to INSERT a new row while the original failed
    row stayed eligible forever).

    Pairs that already have any ``success=True`` log are skipped (delivery
    succeeded; no further retries).

    Uses Redis dedup keys to prevent re-scheduling retries that are already
    in-flight (avoids stale retry spam in worker logs).
    """
    import redis

    r = redis.from_url(settings.REDIS_URL)

    async with _scheduler_session() as db:
        wl = aliased(WebhookLog, name="wl")
        w_succ = aliased(WebhookLog, name="w_succ")

        max_attempt_per_pair = (
            select(
                WebhookLog.endpoint_id,
                WebhookLog.event_id,
                func.max(WebhookLog.attempt).label("max_attempt"),
            )
            .group_by(WebhookLog.endpoint_id, WebhookLog.event_id)
            .subquery()
        )

        pair_has_success = exists(
            select(literal(1))
            .select_from(w_succ)
            .where(
                w_succ.endpoint_id == wl.endpoint_id,
                w_succ.event_id == wl.event_id,
                w_succ.success.is_(True),
            )
        )

        result = await db.execute(
            select(wl).join(
                max_attempt_per_pair,
                and_(
                    wl.endpoint_id == max_attempt_per_pair.c.endpoint_id,
                    wl.event_id == max_attempt_per_pair.c.event_id,
                    wl.attempt == max_attempt_per_pair.c.max_attempt,
                ),
            ).where(
                wl.success.is_(False),
                wl.attempt < settings.WEBHOOK_MAX_RETRIES,
                ~pair_has_success,
            )
        )
        failed_logs = result.scalars().all()

        retry_count = 0
        skipped = 0
        for log in failed_logs:
            base_delay = 30
            next_delay = base_delay * (2 ** (log.attempt - 1))
            next_retry_time = log.sent_at + timedelta(seconds=next_delay)

            if datetime.now(timezone.utc) >= next_retry_time:
                # Dedup: only schedule if not already in-flight (Redis NX lock, 5 min TTL)
                lock_key = f"webhook_retry:{log.id}"
                if r.set(lock_key, "1", ex=300, nx=True):
                    celery_app.send_task(
                        "worker.tasks.deliver_webhook_retry",
                        args=[str(log.id)],
                    )
                    retry_count += 1
                else:
                    skipped += 1

        return {"retried": retry_count, "skipped_in_flight": skipped}
