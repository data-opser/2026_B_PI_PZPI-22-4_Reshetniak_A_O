# Import so Celery autodiscover_tasks registers these tasks
import scheduler.tasks.periodic_tasks  # noqa: F401
