"""Execute LLM decisions via Playwright."""

import asyncio
import random
from playwright.async_api import Page, ElementHandle
from worker.agent.human_actions import human_click, human_scroll, human_type


async def get_element_by_number(page: Page, element_num: int) -> ElementHandle | None:
    """
    Resolve element number from accessibility tree/DOM to Playwright element.

    The LLM references elements by number (e.g., [7]).
    We need to map this back to an actual element.
    """
    # Try to get accessibility snapshot and match by role+name
    try:
        snapshot = await page.accessibility.snapshot()
        if snapshot:
            elements = flatten_accessibility_tree(snapshot)
            if 0 < element_num <= len(elements):
                node = elements[element_num - 1]
                role = node.get("role", "")
                name = node.get("name", "")

                # Try to find by role and name using get_by_role
                if role and name:
                    try:
                        locator = page.get_by_role(role, name=name, exact=True)
                        count = await locator.count()
                        if count == 1:
                            return await locator.element_handle()
                        elif count > 1:
                            return await locator.first.element_handle()
                    except Exception:
                        pass

                    # Try non-exact match
                    try:
                        locator = page.get_by_role(role, name=name)
                        count = await locator.count()
                        if count == 1:
                            return await locator.element_handle()
                        elif count > 1:
                            return await locator.first.element_handle()
                    except Exception:
                        pass

                # For textbox/searchbox, try by placeholder or label
                if role in ("textbox", "searchbox") and name:
                    try:
                        locator = page.get_by_placeholder(name)
                        count = await locator.count()
                        if count == 1:
                            return await locator.element_handle()
                    except Exception:
                        pass
                    try:
                        locator = page.get_by_label(name)
                        count = await locator.count()
                        if count == 1:
                            return await locator.element_handle()
                    except Exception:
                        pass
    except Exception:
        pass

    # Fallback: use CSS selector matching
    try:
        interactive = await page.query_selector_all(
            'a, button, input, select, textarea, [role="button"], [onclick]'
        )
        if 0 < element_num <= len(interactive):
            return interactive[element_num - 1]
    except Exception:
        pass

    return None


def flatten_accessibility_tree(node: dict, result: list | None = None, depth: int = 0) -> list:
    """Flatten accessibility tree to list of nodes.

    IMPORTANT: Must use the same filter logic and depth limit as
    page_state.format_accessibility_tree to keep element numbering in sync.
    """
    if result is None:
        result = []

    role = node.get("role", "")
    name = node.get("name", "")

    # Only include interactive elements — must match page_state.py exactly
    relevant_roles = {
        "link", "button", "textbox", "checkbox", "radio", "combobox",
        "menuitem", "tab", "searchbox", "switch", "heading"
    }

    if role in relevant_roles and (name or node.get("value") or role == "textbox"):
        result.append(node)

    # Recurse — same depth limit as page_state.py
    if depth < 8:
        for child in node.get("children", []):
            flatten_accessibility_tree(child, result, depth + 1)

    return result


async def execute_action(page: Page, decision: dict, profile: dict):
    """
    Execute an LLM decision as a Playwright action.

    Args:
        page: Playwright page
        decision: LLM decision dict with 'action' key
        profile: User profile dict
    """
    action = decision.get("action", "wait")

    if action == "click":
        element_num = decision.get("element")
        if element_num:
            print(f"🎯 Trying to click element #{element_num}")
            element = await get_element_by_number(page, element_num)
            if element:
                print(f"✓ Found element #{element_num}, executing click")
                url_before = page.url
                # Check if element is a button/submit (may have JS-delayed redirect)
                tag_name = await element.evaluate("el => el.tagName.toLowerCase()") if element else ""
                el_type = await element.evaluate("el => el.type || ''") if element else ""
                is_submit_like = tag_name in ("button", "input") and el_type in ("submit", "", "button")

                await human_click(page, element, profile)

                # Wait for navigation
                try:
                    await page.wait_for_load_state("networkidle", timeout=3000)
                except Exception:
                    pass

                # For buttons (likely form submit), wait longer for JS-delayed redirects
                if page.url == url_before and is_submit_like:
                    for _ in range(6):  # Up to 3 more seconds
                        await asyncio.sleep(0.5)
                        if page.url != url_before:
                            break

                if page.url != url_before:
                    print(f"✓ Navigation: {url_before} → {page.url}")
                    try:
                        await page.wait_for_load_state("networkidle", timeout=5000)
                    except Exception:
                        pass
            else:
                # Element not found, wait instead
                print(f"✗ Element #{element_num} not found, waiting instead")
                await asyncio.sleep(random.uniform(1, 2))

    elif action == "scroll":
        direction = decision.get("direction", "down")
        await human_scroll(page, direction, profile)

    elif action == "type":
        element_num = decision.get("element")
        value = decision.get("value", "")
        if element_num and value:
            element = await get_element_by_number(page, element_num)
            if element:
                await human_type(page, element, value, profile)

    elif action == "wait":
        await asyncio.sleep(random.uniform(1, 3))

    # "leave" action is handled in the agent loop, not here
