"""Ollama LLM client for agent decisions."""

import json
import re
import time
import httpx
from shared.config import settings


class LLMClient:
    """Client for communicating with Ollama."""

    def __init__(self, model: str | None = None, base_url: str | None = None):
        self.model = model or settings.OLLAMA_MODEL
        self.base_url = base_url or settings.OLLAMA_URL
        # Longer timeout for LLM inference (especially on first load which can take 2-3 minutes)
        self.http_client = httpx.AsyncClient(timeout=180.0)

    async def close(self):
        """Close HTTP client."""
        await self.http_client.aclose()

    def build_system_prompt(
        self, persona: str, profile: dict, step: int, max_actions: int
    ) -> str:
        """Build system prompt for the LLM."""
        return f"""You are a simulated web user browsing a website. Your behavior is defined by the following persona:

---
{persona}
---

YOUR IDENTITY (use this data when filling forms):
- Name: {profile.get('name', 'John Doe')}
- Email: {profile.get('email', 'user@example.com')}
- Phone: {profile.get('phone', '+1 555-0100')}
- Address: {profile.get('address', '123 Main St, New York, NY 10001')}
- Card number: {profile.get('card_number', '4111111111111111')}
- Card expiry: {profile.get('card_expiry', '12/28')}
- CVV: 123

BEHAVIORAL TRAITS:
- Patience: {profile['patience']:.0%} (0% = very impatient; 100% = very patient)
- Purchase intent: {profile['purchase_intent']:.0%} (0% = just browsing; 100% = ready to buy)

You are on step {step} of {max_actions}.

BEHAVIOR RULES:
- Act naturally like a real person with your persona traits
- When you see a form, decide whether to fill it based on your purchase intent
- If you decide to fill a form, use YOUR IDENTITY data above — fill fields one at a time using the "type" action
- CRITICAL: Only type into fields marked "EMPTY". Skip fields that already show value="...".
- CRITICAL: When ALL form fields have values (no EMPTY fields remain), you MUST click the submit/purchase/complete button immediately. Do NOT re-type into filled fields.
- If you see "ALL FORM FIELDS ARE FILLED" in the page state, your next action MUST be to click the submit button.
- High purchase intent → more likely to complete forms and finish checkout
- Low purchase intent → more likely to browse, hesitate, and leave without buying
- When you're done (purchased, lost interest, or frustrated), use "leave"
- Don't repeat the same action on the same element — move to the next empty field or action

AVAILABLE ACTIONS:
- click: Click an element. Requires "element" (number from the list).
- scroll: Scroll the page. Requires "direction" ("up" or "down").
- type: Type into a form field. Requires "element" (number) and "value" (text to type).
- wait: Pause and look around.
- leave: Leave the website.

RESPONSE FORMAT (strict JSON only, no other text):
{{
  "thought": "Brief reason for your decision (1 sentence)",
  "action": "click|scroll|type|wait|leave",
  "element": 7,
  "value": "text to type",
  "direction": "down"
}}

Only include fields relevant to your chosen action.

CURRENT PAGE STATE:
"""

    async def decide(
        self, persona: str, profile: dict, page_state: str, step: int, max_actions: int
    ) -> tuple[dict, str, int, bool, int]:
        """
        Ask LLM to decide on next action.

        Returns:
            - decision: parsed action dict
            - raw_response: raw LLM text
            - latency_ms: response time in milliseconds
            - parse_ok: whether parsing succeeded
            - retries: number of retries needed
        """
        system_prompt = self.build_system_prompt(persona, profile, step, max_actions)

        start = time.monotonic()
        try:
            response = await self.http_client.post(
                f"{self.base_url}/api/chat",
                json={
                    "model": self.model,
                    "messages": [
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": page_state},
                    ],
                    "stream": False,
                    "options": {
                        "temperature": 0.7,  # Some randomness for diversity
                        "num_predict": 200,  # Limit response length
                    },
                },
            )
            response.raise_for_status()
            latency_ms = int((time.monotonic() - start) * 1000)

            raw_text = response.json()["message"]["content"]

            # Try to parse response
            decision, parse_ok, _ = self.parse_response(raw_text)

            if not parse_ok:
                # Retry with explicit reminder
                retry_start = time.monotonic()
                retry_response = await self.http_client.post(
                    f"{self.base_url}/api/chat",
                    json={
                        "model": self.model,
                        "messages": [
                            {"role": "system", "content": system_prompt},
                            {"role": "user", "content": page_state},
                            {"role": "assistant", "content": raw_text},
                            {
                                "role": "user",
                                "content": "Invalid JSON. Respond with ONLY valid JSON.",
                            },
                        ],
                        "stream": False,
                        "options": {"temperature": 0.7, "num_predict": 200},
                    },
                )
                retry_latency = int((time.monotonic() - retry_start) * 1000)
                latency_ms += retry_latency

                raw_text = retry_response.json()["message"]["content"]
                decision, parse_ok, _ = self.parse_response(raw_text)

                if not parse_ok:
                    # Fallback to safe action
                    decision = {
                        "action": "scroll",
                        "direction": "down",
                        "thought": "LLM parse failure, fallback action",
                    }
                return decision, raw_text, latency_ms, parse_ok, 1

            return decision, raw_text, latency_ms, parse_ok, 0

        except Exception as e:
            latency_ms = int((time.monotonic() - start) * 1000)
            # Fallback on error
            decision = {
                "action": "leave",
                "thought": f"Error communicating with LLM: {str(e)}",
            }
            return decision, str(e), latency_ms, False, 0

    def parse_response(self, raw_text: str) -> tuple[dict, bool, int]:
        """
        Parse LLM response into decision dict.

        Returns: (decision, parse_ok, retries)
        """
        # Try direct JSON parse
        try:
            decision = json.loads(raw_text)
            if "action" in decision:
                return decision, True, 0
        except json.JSONDecodeError:
            pass

        # Try extracting JSON from markdown code block
        match = re.search(r'```(?:json)?\s*(\{.*?\})\s*```', raw_text, re.DOTALL)
        if match:
            try:
                decision = json.loads(match.group(1))
                if "action" in decision:
                    return decision, True, 0
            except json.JSONDecodeError:
                pass

        # Try finding first { ... } in text
        match = re.search(r'\{[^{}]*\}', raw_text)
        if match:
            try:
                decision = json.loads(match.group(0))
                if "action" in decision:
                    return decision, True, 0
            except json.JSONDecodeError:
                pass

        # Try more aggressive extraction for nested braces
        match = re.search(r'\{.*\}', raw_text, re.DOTALL)
        if match:
            try:
                decision = json.loads(match.group(0))
                if "action" in decision:
                    return decision, True, 0
            except json.JSONDecodeError:
                pass

        return {}, False, 0
