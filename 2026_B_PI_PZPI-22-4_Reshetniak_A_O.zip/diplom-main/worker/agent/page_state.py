"""Page state extraction from Playwright page."""

from playwright.async_api import Page


async def extract_page_state(page: Page) -> str:
    """
    Extract a compact text representation of the page for the LLM.

    Uses accessibility tree as primary method, falls back to simplified DOM.
    """
    url = page.url
    title = await page.title()

    # Get scroll position
    scroll_info = await page.evaluate("""() => {
        const scrollTop = window.scrollY || document.documentElement.scrollTop;
        const scrollHeight = document.documentElement.scrollHeight - window.innerHeight;
        const percent = scrollHeight > 0 ? Math.round((scrollTop / scrollHeight) * 100) : 0;
        return {percent, scrollTop, scrollHeight};
    }""")

    # Try to get accessibility tree, enriched with actual DOM values
    try:
        snapshot = await page.accessibility.snapshot()
        if snapshot:
            # Get actual input values from DOM keyed by field identifiers
            # so we can reliably match them to accessibility tree nodes
            dom_values_map = await page.evaluate("""() => {
                const inputs = document.querySelectorAll('input, textarea, select');
                const result = {};
                inputs.forEach(el => {
                    const key = el.name || el.getAttribute('aria-label') || el.placeholder || '';
                    if (key) {
                        result[key] = {
                            value: el.value || '',
                            placeholder: el.placeholder || '',
                            type: el.type || ''
                        };
                    }
                });
                return result;
            }""")
            elements_text = format_accessibility_tree(snapshot, dom_values_map=dom_values_map)
        else:
            elements_text = await extract_simplified_dom(page)
    except Exception:
        elements_text = await extract_simplified_dom(page)

    # Count form fields status for summary
    form_summary = ""
    if "/checkout" in url:
        form_info = await page.evaluate("""() => {
            const inputs = document.querySelectorAll('input[required], input[name]');
            let total = 0, filled = 0;
            inputs.forEach(el => {
                if (el.type === 'hidden' || el.type === 'submit') return;
                total++;
                if (el.value && el.value.trim()) filled++;
            });
            return {total, filled};
        }""")
        empty = form_info['total'] - form_info['filled']
        if empty == 0:
            form_summary = f"\n>>> ALL {form_info['total']} FORM FIELDS ARE FILLED. Click the submit/purchase button now! <<<"
        else:
            form_summary = f"\nForm progress: {form_info['filled']}/{form_info['total']} fields filled, {empty} still EMPTY."

    # Assemble page state
    state = f"""URL: {url}
Title: {title}
Scroll Position: {scroll_info['percent']}% of page
{form_summary}
Interactive Elements:
{elements_text}
"""

    # Limit to ~3000 chars to fit in context
    if len(state) > 3000:
        state = state[:3000] + "\n... (truncated)"

    return state


def format_accessibility_tree(
    node: dict, depth: int = 0, counter: list[int] = None,
    dom_values_map: dict | None = None,
) -> str:
    """
    Format accessibility tree as numbered list.

    Returns text like:
    [1] link "Home"
    [2] button "Add to Cart"
    """
    if counter is None:
        counter = [0]

    lines = []

    # Only include interactive and meaningful elements
    role = node.get("role", "")
    name = node.get("name", "")
    value = node.get("value", "")

    # Filter for relevant roles
    relevant_roles = {
        "link", "button", "textbox", "checkbox", "radio", "combobox",
        "menuitem", "tab", "searchbox", "switch", "heading"
    }

    if role in relevant_roles and (name or value or role == "textbox"):
        counter[0] += 1
        display_name = name or "(unnamed field)"
        if role in ("textbox", "combobox", "searchbox"):
            # Look up actual DOM value by matching on name/placeholder
            actual_value = value
            if dom_values_map and name:
                # Try matching by name (which could be field name, aria-label, or placeholder)
                dom_entry = dom_values_map.get(name)
                if dom_entry:
                    dom_val = dom_entry.get("value", "")
                    if dom_val:
                        actual_value = dom_val

            if actual_value:
                element_text = f'[{counter[0]}] textbox "{display_name}" value="{actual_value}"'
            else:
                element_text = f'[{counter[0]}] textbox "{display_name}" EMPTY'
        else:
            element_text = f'[{counter[0]}] {role} "{display_name}"'
            if value:
                element_text += f' (value: "{value}")'
        lines.append(element_text)

    # Recurse into children (limit depth to avoid huge output)
    if depth < 8 and "children" in node:
        for child in node.get("children", []):
            child_lines = format_accessibility_tree(child, depth + 1, counter, dom_values_map)
            if child_lines:
                lines.append(child_lines)

    return "\n".join(lines)


async def extract_simplified_dom(page: Page) -> str:
    """
    Fallback: extract simplified DOM when accessibility tree is unavailable.

    Queries for common interactive elements.
    """
    elements_data = await page.evaluate("""() => {
        const selectors = 'a, button, input, select, textarea, h1, h2, h3, [role="button"], [onclick]';
        const elements = document.querySelectorAll(selectors);

        return Array.from(elements).slice(0, 50).map((el, i) => {
            const tag = el.tagName.toLowerCase();
            const text = (el.textContent || '').trim().slice(0, 100);
            const role = el.getAttribute('role') || el.getAttribute('type') || tag;
            const href = el.getAttribute('href') || '';
            const value = el.value || '';
            const placeholder = el.getAttribute('placeholder') || '';

            return {
                index: i + 1,
                role: role,
                text: text,
                href: href,
                value: value,
                placeholder: placeholder
            };
        });
    }""")

    lines = []
    for elem in elements_data:
        parts = [f"[{elem['index']}]", elem['role']]

        if elem['text']:
            parts.append(f'"{elem["text"]}"')
        elif elem['placeholder']:
            parts.append(f'(placeholder: "{elem["placeholder"]}")')

        if elem['value']:
            parts.append(f'(value: "{elem["value"]}")')

        if elem['href']:
            parts.append(f'href={elem["href"]}')

        lines.append(" ".join(parts))

    return "\n".join(lines)
