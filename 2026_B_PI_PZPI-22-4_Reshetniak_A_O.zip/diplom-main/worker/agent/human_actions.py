"""Human-like browser actions using Playwright."""

import asyncio
import random
from playwright.async_api import Page, ElementHandle


async def human_move_to(page: Page, target_x: float, target_y: float):
    """
    Move mouse along a quadratic Bezier curve to target position.

    Makes mouse movement look more natural with curved path.
    """
    # Get current mouse position (tracked in page context)
    current = await page.evaluate("({x: window._mouseX || 0, y: window._mouseY || 0})")

    # Random control point for Bezier curve
    cp_x = (current['x'] + target_x) / 2 + random.uniform(-100, 100)
    cp_y = (current['y'] + target_y) / 2 + random.uniform(-50, 50)

    # Number of steps in the curve
    steps = random.randint(15, 30)

    for i in range(steps + 1):
        t = i / steps
        # Quadratic Bezier formula
        x = (1 - t) ** 2 * current['x'] + 2 * (1 - t) * t * cp_x + t ** 2 * target_x
        y = (1 - t) ** 2 * current['y'] + 2 * (1 - t) * t * cp_y + t ** 2 * target_y

        await page.mouse.move(x, y)
        await asyncio.sleep(random.uniform(0.005, 0.025))

    # Track position for next movement
    await page.evaluate(f"window._mouseX = {target_x}; window._mouseY = {target_y}")


async def human_click(page: Page, element: ElementHandle, profile: dict):
    """
    Click element with human-like mouse movement.

    Moves to element center (with slight offset) before clicking.
    """
    box = await element.bounding_box()

    if not box:
        # Element not visible, try direct click
        try:
            await element.click()
        except Exception:
            pass
        return

    # Click slightly off-center (humans don't click exact center)
    target_x = box['x'] + box['width'] / 2 + random.uniform(-5, 5)
    target_y = box['y'] + box['height'] / 2 + random.uniform(-3, 3)

    await human_move_to(page, target_x, target_y)
    await asyncio.sleep(random.uniform(0.05, 0.15))  # Brief pause before clicking
    # Use element.click() instead of page.mouse.click() to trigger actual DOM events and navigation
    try:
        await element.click()
        print(f"✓ Clicked element successfully")
    except Exception as e:
        # Fallback to coordinate click if element click fails
        print(f"✗ Element click failed: {e}, using coordinate click")
        await page.mouse.click(target_x, target_y)


async def human_scroll(page: Page, direction: str, profile: dict):
    """
    Scroll page with human-like incremental movement and reading pauses.

    Args:
        page: Playwright page
        direction: "up" or "down"
        profile: User profile with scroll_speed
    """
    total_delta = random.randint(300, 800)
    step_size = random.randint(50, 150)
    sign = 1 if direction == "down" else -1

    scrolled = 0
    while scrolled < total_delta:
        delta = min(step_size, total_delta - scrolled)
        await page.mouse.wheel(0, sign * delta)
        scrolled += delta

        # Reading pause - longer for patient users
        base_pause = random.uniform(0.1, 0.5)
        pause = base_pause / profile.get('scroll_speed', 1.0)

        # Occasionally stop longer (reading something interesting)
        if random.random() < 0.15:
            pause += random.uniform(1, 3)

        await asyncio.sleep(pause)


async def human_type(page: Page, element: ElementHandle, text: str, profile: dict):
    """
    Type text character by character with realistic timing and occasional typos.

    Args:
        page: Playwright page
        element: Element to type into
        text: Text to type
        profile: User profile with typing_speed
    """
    # Click to focus
    await element.click()
    await asyncio.sleep(random.uniform(0.2, 0.5))

    # Clear existing value — triple-click to select all, then delete
    try:
        await element.click(click_count=3)
        await asyncio.sleep(random.uniform(0.05, 0.15))
        await page.keyboard.press("Backspace")
        await asyncio.sleep(random.uniform(0.05, 0.15))
    except Exception:
        # Fallback: use Ctrl+A then Backspace
        try:
            await page.keyboard.press("Control+a")
            await page.keyboard.press("Backspace")
        except Exception:
            pass

    typing_speed = profile.get('typing_speed', 0.08)

    for i, char in enumerate(text):
        await page.keyboard.type(char)

        # Base delay from profile
        delay = max(0.02, random.gauss(typing_speed, typing_speed * 0.3))

        # Occasional thinking pauses (between words, after punctuation)
        if char == ' ' and random.random() < 0.1:
            delay += random.uniform(0.3, 1.0)
        if char in '.@-' and random.random() < 0.2:
            delay += random.uniform(0.1, 0.5)

        # Occasional typo + correction (makes it look very human)
        if random.random() < 0.02 and i < len(text) - 1:
            wrong_char = random.choice('abcdefghijklmnopqrstuvwxyz')
            await page.keyboard.type(wrong_char)
            await asyncio.sleep(random.uniform(0.1, 0.3))
            await page.keyboard.press("Backspace")
            await asyncio.sleep(random.uniform(0.1, 0.2))

        await asyncio.sleep(delay)
