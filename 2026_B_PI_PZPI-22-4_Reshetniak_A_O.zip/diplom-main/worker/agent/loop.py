"""Main agent loop - observe, decide, act, record decisions."""

import time
import random
import asyncio
import uuid
from playwright.async_api import Page
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from worker.agent.llm_client import LLMClient
from worker.agent.page_state import extract_page_state
from worker.agent.action_executor import execute_action
from shared.models import AgentDecision, GenerationJob
from shared.config import settings


async def agent_loop(
    page: Page,
    llm_client: LLMClient,
    scenario: dict,
    profile: dict,
    session_id: str,
    job_id: str,
    db: AsyncSession,
) -> str:
    """
    Run the agent loop: observe → decide → act → record decision.

    The JS tracker on the target page sends events to the collector,
    which stores them in the events table and dispatches webhooks.
    The agent loop only records LLM decisions for auditing.

    Returns:
        Exit reason (e.g., "left", "max_actions", "timeout", "cancelled")
    """
    step = 0
    start_time = time.time()

    # Get funnel config with defaults
    funnel_config = scenario.get("funnel_config", {})
    max_actions = funnel_config.get("max_actions", 30)
    max_time = funnel_config.get("max_time_seconds", 300)
    delay_min = funnel_config.get("action_delay_min", 1.0)
    delay_max = funnel_config.get("action_delay_max", 5.0)

    while step < max_actions and (time.time() - start_time) < max_time:
        step += 1

        # Check if job was cancelled
        if await _is_job_cancelled(db, job_id):
            return "cancelled"

        try:
            # 1. OBSERVE: extract page state
            page_state = await extract_page_state(page)
            print(f"\n{'='*60}")
            print(f"STEP {step}/{max_actions} | URL: {page.url}")
            print(f"{'='*60}")
            print(f"Page state:\n{page_state[:1500]}")

            # 2. DECIDE: ask LLM
            decision, raw_response, latency_ms, parse_ok, retries = await llm_client.decide(
                persona=scenario["persona_prompt"],
                profile=profile,
                page_state=page_state,
                step=step,
                max_actions=max_actions,
            )
            print(f"LLM decision ({latency_ms}ms): {decision}")

            # 3. LOG DECISION
            await record_decision(
                db=db,
                session_id=session_id,
                step=step,
                page_url=page.url,
                page_state=page_state,
                raw_response=raw_response,
                decision=decision,
                latency_ms=latency_ms,
                parse_ok=parse_ok,
                retries=retries,
            )

            # 4. CHECK EXIT
            if decision.get("action") == "leave":
                return decision.get("thought", "left")

            # 5. ACT: execute with human-like behavior
            await execute_action(page, decision, profile)

            # 6. WAIT (human-like pause between actions)
            delay = random.uniform(delay_min, delay_max)
            delay *= (2.0 - profile.get("patience", 0.5))
            await asyncio.sleep(delay)

            # 7. WAIT FOR PAGE (if navigation occurred)
            try:
                await page.wait_for_load_state("networkidle", timeout=10000)
            except Exception:
                pass

        except Exception as e:
            print(f"Error in agent loop step {step}: {e}")
            return f"error: {str(e)}"

    # If we exit the loop normally (max_actions or timeout)
    reason = "max_actions" if step >= max_actions else "timeout"
    return reason


async def _is_job_cancelled(db: AsyncSession, job_id: str) -> bool:
    """Check if the generation job has been cancelled."""
    result = await db.execute(
        select(GenerationJob.status).where(GenerationJob.id == uuid.UUID(job_id))
    )
    status = result.scalar_one_or_none()
    return status == "cancelled"


async def record_decision(
    db: AsyncSession,
    session_id: str,
    step: int,
    page_url: str,
    page_state: str,
    raw_response: str,
    decision: dict,
    latency_ms: int,
    parse_ok: bool,
    retries: int,
):
    """Record an agent decision to the database."""
    from datetime import datetime, timezone

    agent_decision = AgentDecision(
        id=uuid.uuid4(),
        session_id=uuid.UUID(session_id),
        step_number=step,
        page_url=page_url,
        page_state_summary=page_state[:2000],
        llm_raw_response=raw_response,
        llm_thought=decision.get("thought"),
        action_taken=decision,
        llm_model=settings.OLLAMA_MODEL,
        response_time_ms=latency_ms,
        parse_success=parse_ok,
        retry_count=retries,
        timestamp=datetime.now(timezone.utc),
    )
    db.add(agent_decision)
    await db.commit()
