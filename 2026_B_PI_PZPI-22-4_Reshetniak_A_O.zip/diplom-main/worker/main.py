"""Worker entry point."""

from worker.celery_app import celery_app

# Import tasks to register them
import worker.tasks

if __name__ == "__main__":
    celery_app.start()
