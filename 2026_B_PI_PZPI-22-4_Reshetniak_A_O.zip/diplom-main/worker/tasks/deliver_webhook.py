"""Webhook delivery task — retry task for failed deliveries.

Initial webhook delivery now happens in the collector in real time.
This module handles retries dispatched by the scheduler.
"""

import hashlib
import hmac
import json
import time
import uuid
import asyncio
import httpx
from datetime import datetime, timezone
from sqlalchemy import func, select
from sqlalchemy.orm import selectinload
from worker.celery_app import celery_app
from shared.models import WebhookEndpoint, Event, WebhookLog
from shared.config import settings


def _get_async_db():
    """Create engine and session in the current event loop (safe after Celery fork)."""
    from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession

    engine = create_async_engine(
        settings.DATABASE_URL,
        echo=False,
        pool_size=2,
        max_overflow=0,
        pool_pre_ping=True,
    )
    factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    return engine, factory()


@celery_app.task(name="worker.tasks.deliver_webhook_retry", bind=True, max_retries=2)
def deliver_webhook_retry_task(self, webhook_log_id: str):
    """Retry a single failed webhook delivery by log id (Celery task entry point)."""
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    return loop.run_until_complete(deliver_webhook_retry_async(webhook_log_id))


async def deliver_webhook_retry_async(webhook_log_id: str):
    """Retry a single failed webhook delivery (loads log, resends to same endpoint)."""
    engine, db = _get_async_db()
    try:
        result = await db.execute(
            select(WebhookLog)
            .options(
                selectinload(WebhookLog.endpoint),
                selectinload(WebhookLog.event),
            )
            .where(WebhookLog.id == uuid.UUID(webhook_log_id))
        )
        log = result.scalar_one_or_none()
        if not log or log.success:
            return {"error": "WebhookLog not found or already succeeded"}
        if not log.endpoint:
            return {"error": "Endpoint not found"}

        # Ignore stale retry jobs
        latest_attempt = await db.scalar(
            select(func.max(WebhookLog.attempt)).where(
                WebhookLog.endpoint_id == log.endpoint_id,
                WebhookLog.event_id == log.event_id,
            )
        )
        if latest_attempt is None or log.attempt != latest_attempt:
            return {"error": "Stale retry: superseded by a newer attempt"}

        if log.attempt >= settings.WEBHOOK_MAX_RETRIES:
            return {"error": "Max retries exceeded"}

        payload = log.request_body
        success = await _send_and_log(db, log.endpoint, log.event, payload, attempt=log.attempt + 1)
        return {"delivered": 1 if success else 0}
    finally:
        await db.close()
        await engine.dispose()


def build_webhook_payload(event: Event) -> dict:
    """Build webhook payload from event data."""
    return {
        "event_id": str(event.id),
        "event_type": event.event_type,
        "timestamp": event.collector_tstamp.isoformat(),
        "visitor_id": event.visitor_id,
        "session_id": event.session_id,
        "page": {
            "url": event.page_url,
            "title": event.page_title,
            "referrer": event.page_referrer,
        },
        "data": event.event_data,
        "device": {
            "type": event.device_type,
            "browser": event.browser_family,
            "os": event.os_family,
        },
        "app_id": event.app_id,
    }


async def _send_and_log(
    db, webhook: WebhookEndpoint, event: Event, payload: dict, attempt: int
) -> bool:
    """Send HTTP POST to endpoint and record WebhookLog with given attempt number."""
    headers = {**(webhook.headers or {}), "Content-Type": "application/json"}
    headers["X-STG-Event-Type"] = event.event_type
    headers["X-STG-Attempt"] = str(attempt)

    payload_with_attempt = {**payload, "attempt": attempt}

    if webhook.secret:
        payload_str = json.dumps(payload_with_attempt, separators=(",", ":"))
        signature = hmac.new(
            webhook.secret.encode(),
            payload_str.encode(),
            hashlib.sha256,
        ).hexdigest()
        headers["X-STG-Signature"] = f"sha256={signature}"

    start = time.monotonic()
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                webhook.url,
                json=payload_with_attempt,
                headers=headers,
                timeout=settings.WEBHOOK_TIMEOUT,
            )
            duration_ms = int((time.monotonic() - start) * 1000)
            success = 200 <= response.status_code < 300
            log = WebhookLog(
                endpoint_id=webhook.id,
                event_id=event.id,
                attempt=attempt,
                status_code=response.status_code,
                request_body=payload,
                response_body=response.text[:1000],
                success=success,
                duration_ms=duration_ms,
                sent_at=datetime.now(timezone.utc),
            )
            db.add(log)
            await db.commit()
            return success
        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            log = WebhookLog(
                endpoint_id=webhook.id,
                event_id=event.id,
                attempt=attempt,
                status_code=None,
                request_body=payload,
                response_body=None,
                error_message=str(e),
                success=False,
                duration_ms=duration_ms,
                sent_at=datetime.now(timezone.utc),
            )
            db.add(log)
            await db.commit()
            return False
