"""Celery task for generating a single session."""

import uuid
import asyncio
from datetime import datetime, timezone
from playwright.async_api import async_playwright
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import create_async_engine, async_sessionmaker, AsyncSession
from worker.celery_app import celery_app
from worker.agent.loop import agent_loop
from worker.agent.llm_client import LLMClient
from worker.profile.generator import generate_user_profile, profile_to_dict
from shared.config import settings
from shared.models import Scenario, GenerationJob, Session


@celery_app.task(name="worker.tasks.generate_session", bind=True)
def generate_session_task(self, job_id: str, scenario_id: str, config_override: dict | None = None):
    """
    Generate a single browser session (Celery task entry point).

    With solo pool, we need to get the existing event loop instead of creating a new one.
    """
    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)

    return loop.run_until_complete(generate_session_async(job_id, scenario_id, config_override))


async def generate_session_async(job_id: str, scenario_id: str, config_override: dict | None = None):
    """Async implementation of session generation."""
    # Create a fresh engine on the current event loop to avoid loop conflicts
    engine = create_async_engine(
        settings.DATABASE_URL,
        echo=False,
        pool_size=5,
        max_overflow=10,
        pool_pre_ping=True,
    )
    AsyncSessionFactory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
        autoflush=False,
    )
    db = AsyncSessionFactory()
    session_id = None

    try:
        # 1. Load scenario
        result = await db.execute(select(Scenario).where(Scenario.id == uuid.UUID(scenario_id)))
        scenario = result.scalar_one_or_none()

        if not scenario:
            raise ValueError(f"Scenario {scenario_id} not found")

        # Merge config override
        funnel_config = {**scenario.funnel_config}
        if config_override:
            funnel_config.update(config_override)

        scenario_dict = {
            "id": str(scenario.id),
            "name": scenario.name,
            "persona_prompt": scenario.persona_prompt,
            "target_urls": scenario.target_urls,
            "funnel_config": funnel_config,
        }

        # 2. Generate user profile with trait ranges from scenario
        device_pool = scenario.device_pool if scenario.device_pool else None
        trait_overrides = {
            k: v for k, v in funnel_config.items()
            if k in ("purchase_intent_min", "purchase_intent_max", "patience_min", "patience_max")
        }
        profile = generate_user_profile(device_pool, trait_overrides or None)
        profile_dict = profile_to_dict(profile)

        # 3. Create session row
        session = Session(
            id=uuid.uuid4(),
            job_id=uuid.UUID(job_id),
            scenario_id=uuid.UUID(scenario_id),
            status="running",
            user_profile=profile_dict,
            started_at=datetime.now(timezone.utc),
        )
        db.add(session)
        await db.commit()
        session_id = str(session.id)

        # 4. Update job: mark as started if first session
        await db.execute(
            update(GenerationJob)
            .where(GenerationJob.id == uuid.UUID(job_id))
            .where(GenerationJob.started_at.is_(None))
            .values(started_at=datetime.now(timezone.utc), status="running")
        )
        await db.commit()

        # 5. Launch browser and run agent loop
        async with async_playwright() as p:
            browser = await p.chromium.launch(
                headless=True,
                args=["--disable-blink-features=AutomationControlled"]
            )

            # Create context with user profile
            context = await browser.new_context(
                viewport={
                    "width": profile_dict["device"]["width"],
                    "height": profile_dict["device"]["height"],
                },
                user_agent=profile_dict["user_agent"],
                locale=profile_dict["locale"],
                is_mobile=profile_dict["device"]["mobile"],
            )

            page = await context.new_page()

            # Navigate to start URL
            start_url = scenario.target_urls.get("start")
            if not start_url:
                raise ValueError("Scenario missing 'start' URL")

            # Pre-set the visitor cookie (_stg_id) so the JS tracker
            # adopts the agent's identity — like a real platform where the
            # first-party cookie persists across visits.
            # The JS tracker will create its own _stg_ses (session) cookie
            # client-side with a 30-min sliding window, exactly like
            # Snowplow sp.js or GA analytics.js.
            from urllib.parse import urlparse
            parsed = urlparse(start_url)
            await context.add_cookies([{
                "name": "_stg_id",
                "value": session_id,
                "domain": parsed.hostname,
                "path": "/",
                "maxAge": 63072000,  # 2 years, matches JS tracker
            }])

            await page.goto(start_url, wait_until="networkidle", timeout=30000)

            # Create LLM client (use model from config_override if provided)
            model = funnel_config.get("ollama_model")
            print(f"🤖 LLM Model Config: funnel_config={funnel_config}, model={model}")
            llm_client = LLMClient(model=model)

            try:
                # Run agent loop
                exit_reason = await agent_loop(
                    page=page,
                    llm_client=llm_client,
                    scenario=scenario_dict,
                    profile=profile_dict,
                    session_id=session_id,
                    job_id=job_id,
                    db=db,
                )

                if exit_reason == "cancelled":
                    await db.execute(
                        update(Session)
                        .where(Session.id == uuid.UUID(session_id))
                        .values(
                            status="failed",
                            result="cancelled",
                            finished_at=datetime.now(timezone.utc),
                        )
                    )
                    await db.commit()
                else:
                    # 6. Update session: completed
                    result = "success"
                    await db.execute(
                        update(Session)
                        .where(Session.id == uuid.UUID(session_id))
                        .values(
                            status="completed",
                            result=result,
                            finished_at=datetime.now(timezone.utc),
                        )
                    )
                    await db.commit()

            finally:
                await llm_client.close()
                await browser.close()

        # 7. Update job: increment completed/failed sessions
        await update_job_progress(db, job_id, completed=(exit_reason != "cancelled"))

        final_result = "cancelled" if exit_reason == "cancelled" else result
        return {"session_id": session_id, "status": "completed" if exit_reason != "cancelled" else "cancelled", "result": final_result}

    except Exception as e:
        # On error, mark session as failed
        if session_id:
            await db.execute(
                update(Session)
                .where(Session.id == uuid.UUID(session_id))
                .values(
                    status="failed",
                    error_message=str(e),
                    finished_at=datetime.now(timezone.utc),
                )
            )
            await db.commit()

        # Update job: increment failed_sessions
        await update_job_progress(db, job_id, completed=False)

        raise e

    finally:
        await db.close()
        await engine.dispose()


async def update_job_progress(db, job_id: str, completed: bool):
    """Update job progress counters."""
    if completed:
        await db.execute(
            update(GenerationJob)
            .where(GenerationJob.id == uuid.UUID(job_id))
            .values(completed_sessions=GenerationJob.completed_sessions + 1)
        )
    else:
        await db.execute(
            update(GenerationJob)
            .where(GenerationJob.id == uuid.UUID(job_id))
            .values(failed_sessions=GenerationJob.failed_sessions + 1)
        )
    await db.commit()

    # Check if job is complete
    result = await db.execute(
        select(GenerationJob).where(GenerationJob.id == uuid.UUID(job_id))
    )
    job = result.scalar_one_or_none()

    if job and (job.completed_sessions + job.failed_sessions) >= job.total_sessions:
        await db.execute(
            update(GenerationJob)
            .where(GenerationJob.id == uuid.UUID(job_id))
            .values(status="completed", finished_at=datetime.now(timezone.utc))
        )
        await db.commit()


