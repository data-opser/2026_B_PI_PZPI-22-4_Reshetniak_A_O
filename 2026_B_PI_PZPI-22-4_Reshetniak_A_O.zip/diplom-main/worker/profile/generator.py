"""User profile generator using Faker."""

import random
import uuid
from dataclasses import dataclass, asdict
from faker import Faker

fake = Faker()

# Default device pool
DEFAULT_DEVICES = [
    {"width": 1920, "height": 1080, "mobile": False, "label": "Desktop 1080p"},
    {"width": 1366, "height": 768, "mobile": False, "label": "Desktop 768p"},
    {"width": 1440, "height": 900, "mobile": False, "label": "Desktop MacBook"},
    {"width": 390, "height": 844, "mobile": True, "label": "iPhone 15"},
    {"width": 414, "height": 896, "mobile": True, "label": "iPhone 11"},
    {"width": 360, "height": 800, "mobile": True, "label": "Android Generic"},
    {"width": 768, "height": 1024, "mobile": True, "label": "iPad"},
]


@dataclass
class DeviceConfig:
    """Device configuration."""

    width: int
    height: int
    mobile: bool
    label: str


@dataclass
class UserProfile:
    """Generated user profile for a session."""

    # Identity
    id: str
    name: str
    email: str
    phone: str
    ip: str
    locale: str

    # Device
    device: dict
    user_agent: str

    # Behavioral traits
    patience: float  # 0.0-1.0, skewed towards impatient
    purchase_intent: float  # 0.0-1.0
    scroll_speed: float  # multiplier for scroll pauses
    typing_speed: float  # seconds per character

    # Payment data (for checkout forms)
    card_number: str
    card_expiry: str
    address: str


def generate_user_profile(
    device_pool: list[dict] | None = None,
    trait_overrides: dict | None = None,
) -> UserProfile:
    """Generate a random user profile.

    trait_overrides can contain:
      purchase_intent_min/max: float 0-1
      patience_min/max: float 0-1
    """
    # Select device (device_pool from DB may contain dicts or malformed entries)
    devices = device_pool if device_pool else DEFAULT_DEVICES
    device_dict = random.choice(devices)
    if not isinstance(device_dict, dict):
        device_dict = random.choice(DEFAULT_DEVICES)
    device = DeviceConfig(**device_dict)

    # Generate user agent matching device type
    if device.mobile:
        user_agent = fake.user_agent()
        # Ensure it's a mobile user agent
        while "Mobile" not in user_agent and "Android" not in user_agent and "iPhone" not in user_agent:
            user_agent = fake.user_agent()
    else:
        user_agent = fake.user_agent()
        # Ensure it's a desktop user agent
        while "Mobile" in user_agent or "Android" in user_agent or "iPhone" in user_agent:
            user_agent = fake.user_agent()

    # Generate behavioral traits
    overrides = trait_overrides or {}
    pi_min = overrides.get("purchase_intent_min", 0.0)
    pi_max = overrides.get("purchase_intent_max", 1.0)
    pa_min = overrides.get("patience_min", 0.0)
    pa_max = overrides.get("patience_max", 1.0)

    # Beta distribution, then clamp to scenario range
    patience_raw = random.betavariate(2, 5)  # Skewed low (0.2-0.4 typical)
    patience = pa_min + patience_raw * (pa_max - pa_min)

    purchase_intent_raw = random.betavariate(2, 3)  # Slightly skewed low
    purchase_intent = pi_min + purchase_intent_raw * (pi_max - pi_min)
    scroll_speed = random.uniform(0.5, 2.0)
    typing_speed = max(0.02, random.gauss(0.08, 0.02))  # Mean 80ms per char

    # Generate unique email
    user_id = uuid.uuid4().hex[:6]
    username = fake.user_name()
    domain = fake.free_email_domain()
    email = f"{username}.{user_id}@{domain}"

    return UserProfile(
        id=str(uuid.uuid4()),
        name=fake.name(),
        email=email,
        phone=fake.phone_number(),
        ip=fake.ipv4_public(),
        locale=random.choice(["en-US", "en-GB", "en-CA"]),
        device=asdict(device),
        user_agent=user_agent,
        patience=patience,
        purchase_intent=purchase_intent,
        scroll_speed=scroll_speed,
        typing_speed=typing_speed,
        card_number=fake.credit_card_number(),
        card_expiry=fake.credit_card_expire(),
        address=fake.address(),
    )


def profile_to_dict(profile: UserProfile) -> dict:
    """Convert profile to dictionary."""
    return asdict(profile)
