"""Celery app configuration."""

from celery import Celery
from shared.config import settings

# Create Celery app
celery_app = Celery(
    "synthetic_traffic_generator",
    broker=settings.CELERY_BROKER_URL,
    backend=settings.CELERY_RESULT_BACKEND,
)

# Celery configuration
celery_app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="UTC",
    enable_utc=True,
    task_track_started=True,
    task_acks_late=True,
    worker_prefetch_multiplier=2,
    task_routes={
        "worker.tasks.deliver_webhook_retry": {"queue": "webhooks"},
    },
)

# Auto-discover tasks
celery_app.autodiscover_tasks(["worker.tasks"])
