"""Stats service - business logic for statistics."""

import uuid
from datetime import datetime
from sqlalchemy import select, func, and_, case
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import Session, Event, AgentDecision, WebhookLog, WebhookEndpoint, User
from shared.schemas import FunnelStats, ThroughputStats, AgentStats
from shared.schemas.stats import (
    WebhookDeliveryStats,
    WebhookDeliveryByWebhook,
    WebhookDeliveryByEventType,
)


class StatsService:
    """Service for generating statistics."""

    @staticmethod
    async def get_funnel_stats(
        db: AsyncSession,
        scenario_id: uuid.UUID | None = None,
        from_date: datetime | None = None,
        to_date: datetime | None = None,
    ) -> FunnelStats:
        """Calculate funnel statistics."""
        # Build query for sessions
        query = select(Session)

        conditions = []
        if scenario_id:
            conditions.append(Session.scenario_id == scenario_id)
        if from_date:
            conditions.append(Session.created_at >= from_date)
        if to_date:
            conditions.append(Session.created_at < to_date)

        if conditions:
            query = query.where(and_(*conditions))

        result = await db.execute(query)
        sessions = result.scalars().all()

        total_sessions = len(sessions)

        # Calculate funnel stages based on result labels
        stages = {}
        for session in sessions:
            result_label = session.result or "unknown"
            stages[result_label] = stages.get(result_label, 0) + 1

        # Convert to stage list
        stage_list = []
        for stage_name, count in sorted(stages.items(), key=lambda x: -x[1]):
            stage_list.append({
                "name": stage_name,
                "count": count,
                "percent": round(count / total_sessions * 100, 2) if total_sessions > 0 else 0,
            })

        return FunnelStats(
            total_sessions=total_sessions,
            stages=stage_list,
        )

    @staticmethod
    async def get_throughput_stats(
        db: AsyncSession,
        period: str = "hour",
        from_date: datetime | None = None,
        to_date: datetime | None = None,
    ) -> ThroughputStats:
        """Calculate throughput statistics."""
        # For simplicity, return empty buckets
        # Full implementation would use time-series aggregation
        return ThroughputStats(buckets=[])

    @staticmethod
    async def get_agent_stats(db: AsyncSession) -> AgentStats:
        """Calculate agent performance statistics."""
        # Average LLM latency
        avg_latency_result = await db.execute(
            select(func.avg(AgentDecision.response_time_ms))
        )
        avg_latency = avg_latency_result.scalar() or 0

        # P95 latency (approximate using SQL)
        # For true P95, would need more complex query or post-processing
        p95_latency = avg_latency * 1.5  # Rough approximation

        # Total decisions
        total_decisions_result = await db.execute(
            select(func.count(AgentDecision.id))
        )
        total_decisions = total_decisions_result.scalar() or 0

        # Parse failure rate
        parse_failures_result = await db.execute(
            select(func.count(AgentDecision.id)).where(
                AgentDecision.parse_success == False
            )
        )
        parse_failures = parse_failures_result.scalar() or 0
        parse_failure_rate = (
            parse_failures / total_decisions if total_decisions > 0 else 0
        )

        # Action distribution
        # Count actions from action_taken JSONB field
        action_distribution = {
            "click": 0.35,
            "scroll": 0.30,
            "type": 0.15,
            "wait": 0.10,
            "leave": 0.10,
        }  # Placeholder - would need JSONB queries for real data

        return AgentStats(
            avg_llm_latency_ms=round(avg_latency, 2),
            p95_llm_latency_ms=round(p95_latency, 2),
            total_decisions=total_decisions,
            parse_failure_rate=round(parse_failure_rate, 4),
            action_distribution=action_distribution,
        )

    @staticmethod
    def _webhook_delivery_base_conditions(
        current_user: User,
        owner_user_id: uuid.UUID | None,
        endpoint_id: uuid.UUID | None,
        event_type: str | None,
        from_dt: datetime | None,
        to_dt: datetime | None,
        success_only: bool | None,
    ) -> list:
        conditions = []
        if current_user.role != "admin":
            conditions.append(WebhookEndpoint.user_id == current_user.id)
        elif owner_user_id is not None:
            conditions.append(WebhookEndpoint.user_id == owner_user_id)
        if endpoint_id is not None:
            conditions.append(WebhookLog.endpoint_id == endpoint_id)
        if event_type:
            conditions.append(Event.event_type == event_type)
        if from_dt is not None:
            conditions.append(WebhookLog.sent_at >= from_dt)
        if to_dt is not None:
            conditions.append(WebhookLog.sent_at <= to_dt)
        if success_only is True:
            conditions.append(WebhookLog.success.is_(True))
        elif success_only is False:
            conditions.append(WebhookLog.success.is_(False))
        return conditions

    @staticmethod
    async def get_webhook_delivery_stats(
        db: AsyncSession,
        current_user: User,
        owner_user_id: uuid.UUID | None = None,
        endpoint_id: uuid.UUID | None = None,
        event_type: str | None = None,
        from_dt: datetime | None = None,
        to_dt: datetime | None = None,
        success_only: bool | None = None,
    ) -> WebhookDeliveryStats:
        """Stats for webhook deliveries (logs). User: own webhooks only; admin: all + filters."""
        conditions = StatsService._webhook_delivery_base_conditions(
            current_user, owner_user_id, endpoint_id, event_type, from_dt, to_dt, success_only
        )
        base_from = (
            WebhookLog.__table__.join(WebhookEndpoint.__table__, WebhookLog.endpoint_id == WebhookEndpoint.id)
            .join(Event.__table__, WebhookLog.event_id == Event.id)
        )

        def apply_where(stmt):
            if conditions:
                return stmt.where(and_(*conditions))
            return stmt

        total = await db.scalar(
            apply_where(select(func.count(WebhookLog.id)).select_from(base_from))
        ) or 0
        successful = await db.scalar(
            apply_where(
                select(func.count(WebhookLog.id))
                .select_from(base_from)
                .where(WebhookLog.success.is_(True))
            )
        ) or 0
        failed = max(0, total - successful)

        unique_events = await db.scalar(
            apply_where(
                select(func.count(func.distinct(WebhookLog.event_id)))
                .select_from(base_from)
                .where(WebhookLog.success.is_(True))
            )
        ) or 0

        by_webhook_from = (
            WebhookLog.__table__.join(WebhookEndpoint.__table__, WebhookLog.endpoint_id == WebhookEndpoint.id)
            .join(Event.__table__, WebhookLog.event_id == Event.id)
            .outerjoin(User.__table__, WebhookEndpoint.user_id == User.id)
        )
        bw_stmt = (
            select(
                WebhookEndpoint.id,
                WebhookEndpoint.name,
                User.name.label("owner_name"),
                func.count(WebhookLog.id).label("dc"),
                func.sum(case((WebhookLog.success.is_(True), 1), else_=0)).label("sc"),
            )
            .select_from(by_webhook_from)
        )
        if conditions:
            bw_stmt = bw_stmt.where(and_(*conditions))
        bw_stmt = bw_stmt.group_by(WebhookEndpoint.id, WebhookEndpoint.name, User.name).order_by(
            func.count(WebhookLog.id).desc()
        )
        bw_rows = (await db.execute(bw_stmt)).all()

        et_stmt = (
            select(Event.event_type, func.count(WebhookLog.id).label("cnt"))
            .select_from(base_from)
        )
        if conditions:
            et_stmt = et_stmt.where(and_(*conditions))
        et_stmt = et_stmt.group_by(Event.event_type).order_by(func.count(WebhookLog.id).desc())
        et_rows = (await db.execute(et_stmt)).all()

        by_webhook = [
            WebhookDeliveryByWebhook(
                endpoint_id=row[0],
                webhook_name=row[1],
                owner_name=row[2] if current_user.role == "admin" else None,
                delivery_count=int(row[3]),
                success_count=int(row[4] or 0),
            )
            for row in bw_rows
        ]
        by_event_type = [
            WebhookDeliveryByEventType(event_type=row[0], count=int(row[1])) for row in et_rows
        ]

        return WebhookDeliveryStats(
            total_deliveries=int(total),
            successful_deliveries=int(successful),
            failed_deliveries=int(failed),
            unique_events_delivered=int(unique_events),
            by_webhook=by_webhook,
            by_event_type=by_event_type,
        )
