"""Auth service - password hashing and JWT."""

from datetime import datetime, timezone, timedelta
import uuid
import bcrypt
import jwt
from shared.config import settings


def get_jwt_secret() -> str:
    """JWT secret: JWT_SECRET_KEY or SECRET_KEY."""
    return settings.JWT_SECRET_KEY or settings.SECRET_KEY


def hash_password(password: str) -> str:
    """Hash password for storage (bcrypt)."""
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(plain: str, hashed: str) -> bool:
    """Verify password against bcrypt hash."""
    try:
        return bcrypt.checkpw(plain.encode("utf-8"), hashed.encode("utf-8"))
    except (ValueError, TypeError):
        return False


def create_access_token(user_id: uuid.UUID) -> str:
    """Create JWT access token for user."""
    now = datetime.now(timezone.utc)
    expire = now + timedelta(minutes=settings.JWT_EXPIRE_MINUTES)
    payload = {
        "sub": str(user_id),
        "iat": now,
        "exp": expire,
    }
    return jwt.encode(
        payload,
        get_jwt_secret(),
        algorithm=settings.JWT_ALGORITHM,
    )


def decode_access_token(token: str) -> dict | None:
    """Decode and validate JWT; return payload or None."""
    try:
        return jwt.decode(
            token,
            get_jwt_secret(),
            algorithms=[settings.JWT_ALGORITHM],
        )
    except jwt.PyJWTError:
        return None
