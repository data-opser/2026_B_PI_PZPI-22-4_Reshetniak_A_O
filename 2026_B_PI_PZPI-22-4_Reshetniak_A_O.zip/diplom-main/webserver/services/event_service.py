"""Event service - business logic for events."""

import uuid
from datetime import datetime
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import Event
from shared.schemas import EventFilter


class EventService:
    """Service for managing events."""

    @staticmethod
    async def list_events(
        db: AsyncSession,
        filters: EventFilter,
    ) -> tuple[list[Event], uuid.UUID | None]:
        """
        List events with filtering and cursor-based pagination.

        Returns: (events, next_cursor)
        """
        query = select(Event)

        conditions = []

        if filters.event_type:
            event_types = filters.event_type.split(",")
            conditions.append(Event.event_type.in_(event_types))

        if filters.session_id:
            conditions.append(Event.session_id == filters.session_id)

        if filters.visitor_id:
            conditions.append(Event.visitor_id == filters.visitor_id)

        if filters.from_timestamp:
            conditions.append(Event.collector_tstamp >= filters.from_timestamp)

        if filters.to_timestamp:
            conditions.append(Event.collector_tstamp < filters.to_timestamp)

        if filters.cursor:
            conditions.append(Event.id > filters.cursor)

        if conditions:
            query = query.where(and_(*conditions))

        query = query.order_by(Event.collector_tstamp.desc()).limit(filters.limit)

        result = await db.execute(query)
        events = list(result.scalars().all())

        next_cursor = events[-1].id if len(events) == filters.limit else None

        return events, next_cursor

    @staticmethod
    async def get_events_count(
        db: AsyncSession,
        event_type: str | None = None,
        session_id: str | None = None,
    ) -> int:
        """Get count of events matching filters."""
        query = select(func.count(Event.id))

        conditions = []
        if event_type:
            conditions.append(Event.event_type == event_type)
        if session_id:
            conditions.append(Event.session_id == session_id)

        if conditions:
            query = query.where(and_(*conditions))

        count = await db.scalar(query)
        return count or 0

    @staticmethod
    async def export_events_csv(
        db: AsyncSession,
        filters: EventFilter,
    ) -> list[Event]:
        """Export events as list for CSV generation."""
        query = select(Event)

        conditions = []

        if filters.event_type:
            event_types = filters.event_type.split(",")
            conditions.append(Event.event_type.in_(event_types))

        if filters.session_id:
            conditions.append(Event.session_id == filters.session_id)

        if filters.visitor_id:
            conditions.append(Event.visitor_id == filters.visitor_id)

        if filters.from_timestamp:
            conditions.append(Event.collector_tstamp >= filters.from_timestamp)

        if filters.to_timestamp:
            conditions.append(Event.collector_tstamp < filters.to_timestamp)

        if conditions:
            query = query.where(and_(*conditions))

        query = query.order_by(Event.collector_tstamp.desc()).limit(filters.limit)

        result = await db.execute(query)
        return list(result.scalars().all())
