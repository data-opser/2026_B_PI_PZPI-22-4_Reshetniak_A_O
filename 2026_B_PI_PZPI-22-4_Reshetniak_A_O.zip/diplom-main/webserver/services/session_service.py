"""Session service - business logic for sessions."""

import uuid
from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from shared.models import Session, Event, AgentDecision


class SessionService:
    """Service for managing sessions."""

    @staticmethod
    async def get_session(db: AsyncSession, session_id: uuid.UUID) -> Session | None:
        """Get session by ID."""
        result = await db.execute(
            select(Session).where(Session.id == session_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def get_session_detail(db: AsyncSession, session_id: uuid.UUID) -> dict | None:
        """Get session with agent decisions and related events from collector."""
        # Get session with agent decisions
        result = await db.execute(
            select(Session)
            .options(selectinload(Session.agent_decisions))
            .where(Session.id == session_id)
        )
        session = result.scalar_one_or_none()

        if not session:
            return None

        # Query events from collector via FK populated at ingest time.
        events_result = await db.execute(
            select(Event)
            .where(Event.simulation_session_id == session_id)
            .order_by(Event.collector_tstamp)
        )
        events = list(events_result.scalars().all())

        # Update cached counters on the session object (not persisted, just for response)
        session.total_events = len(events)
        session.total_actions = len(session.agent_decisions)

        return {
            "session": session,
            "events": events,
            "agent_decisions": sorted(session.agent_decisions, key=lambda d: d.step_number),
        }

    @staticmethod
    async def _enrich_sessions_with_counts(
        db: AsyncSession, sessions: list[Session]
    ) -> list[Session]:
        """Compute total_events and total_actions dynamically for a list of sessions."""
        if not sessions:
            return sessions

        session_ids = [s.id for s in sessions]

        # Count events per session via the simulation_session_id FK.
        event_counts_result = await db.execute(
            select(Event.simulation_session_id, func.count(Event.id))
            .where(Event.simulation_session_id.in_(session_ids))
            .group_by(Event.simulation_session_id)
        )
        event_counts = {row[0]: row[1] for row in event_counts_result.all()}

        # Count agent decisions per session
        action_counts_result = await db.execute(
            select(AgentDecision.session_id, func.count(AgentDecision.id))
            .where(AgentDecision.session_id.in_(session_ids))
            .group_by(AgentDecision.session_id)
        )
        action_counts = {row[0]: row[1] for row in action_counts_result.all()}

        for session in sessions:
            session.total_events = event_counts.get(session.id, 0)
            session.total_actions = action_counts.get(session.id, 0)

        return sessions

    @staticmethod
    async def list_sessions(
        db: AsyncSession,
        job_id: uuid.UUID | None = None,
        scenario_id: uuid.UUID | None = None,
        status: str | None = None,
        result: str | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> tuple[list[Session], int]:
        """List sessions with filtering and pagination."""
        query = select(Session)

        conditions = []
        if job_id:
            conditions.append(Session.job_id == job_id)
        if scenario_id:
            conditions.append(Session.scenario_id == scenario_id)
        if status:
            conditions.append(Session.status == status)
        if result:
            conditions.append(Session.result == result)

        if conditions:
            query = query.where(and_(*conditions))

        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await db.scalar(count_query)

        # Get paginated results
        query = query.order_by(Session.created_at.desc())
        query = query.offset((page - 1) * limit).limit(limit)
        result_exec = await db.execute(query)
        sessions = list(result_exec.scalars().all())

        # Enrich with dynamic event/action counts
        await SessionService._enrich_sessions_with_counts(db, sessions)

        return sessions, total or 0
