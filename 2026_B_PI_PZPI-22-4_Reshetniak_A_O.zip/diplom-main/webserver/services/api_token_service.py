"""API token service — create, list, revoke; hash for auth."""

import hashlib
import secrets
import uuid
from datetime import datetime, timezone
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import ApiToken, User


def hash_api_token(plain: str) -> str:
    """SHA-256 hex digest of the raw token (for storage and lookup)."""
    return hashlib.sha256(plain.encode("utf-8")).hexdigest()


def generate_api_token_plain() -> str:
    """Generate a new opaque API token (shown once to the user)."""
    return f"stg_{secrets.token_urlsafe(32)}"


class ApiTokenService:
    """Manage API tokens per user."""

    @staticmethod
    async def find_user_by_token(db: AsyncSession, plain_token: str) -> User | None:
        """Resolve active user from raw API token, or None if invalid/expired."""
        if not plain_token or len(plain_token) < 8:
            return None
        th = hash_api_token(plain_token)
        result = await db.execute(
            select(ApiToken)
            .options(selectinload(ApiToken.user))
            .where(ApiToken.token_hash == th)
        )
        row = result.scalar_one_or_none()
        if not row or not row.user or not row.user.is_active:
            return None
        now = datetime.now(timezone.utc)
        if row.expires_at is not None and row.expires_at <= now:
            return None
        return row.user

    @staticmethod
    async def create_token(
        db: AsyncSession,
        user_id: uuid.UUID,
        name: str | None,
        expires_at: datetime | None,
    ) -> tuple[ApiToken, str]:
        """Create token; returns (db_row, plaintext_token_to_show_once)."""
        plain = generate_api_token_plain()
        token = ApiToken(
            user_id=user_id,
            token_hash=hash_api_token(plain),
            name=name,
            expires_at=expires_at,
        )
        db.add(token)
        await db.commit()
        await db.refresh(token)
        return token, plain

    @staticmethod
    async def get_by_id(db: AsyncSession, token_id: uuid.UUID) -> ApiToken | None:
        result = await db.execute(
            select(ApiToken)
            .options(selectinload(ApiToken.user))
            .where(ApiToken.id == token_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def list_for_user(db: AsyncSession, current_user: User) -> list[ApiToken]:
        q = select(ApiToken).options(selectinload(ApiToken.user)).order_by(ApiToken.created_at.desc())
        if current_user.role != "admin":
            q = q.where(ApiToken.user_id == current_user.id)
        result = await db.execute(q)
        return list(result.scalars().unique().all())

    @staticmethod
    async def delete_token(
        db: AsyncSession, token_id: uuid.UUID, current_user: User
    ) -> bool:
        token = await ApiTokenService.get_by_id(db, token_id)
        if not token:
            return False
        if current_user.role != "admin" and token.user_id != current_user.id:
            return False
        await db.delete(token)
        await db.commit()
        return True
