"""Event enrichment pipeline — adds derived fields to raw tracker events.

Similar to Snowplow's enrichment step: user agent parsing, timestamp
normalization, device detection. The collector is intentionally dumb —
it stores raw events without imposing funnel logic.
"""

from datetime import datetime, timezone
from user_agents import parse as parse_ua


def enrich_event(raw: dict, headers: dict) -> dict:
    """
    Take a raw tracker payload + HTTP headers and return enriched fields.

    Returns a dict of enrichment fields to merge into the canonical event.
    """
    enriched: dict = {}

    # ── User-Agent parsing ────────────────────────────────────────────────
    ua_string = headers.get("user-agent", "")
    enriched["useragent"] = ua_string

    if ua_string:
        ua = parse_ua(ua_string)
        enriched["browser_family"] = ua.browser.family
        enriched["browser_version"] = ua.browser.version_string
        enriched["os_family"] = ua.os.family
        enriched["os_version"] = ua.os.version_string

        if ua.is_mobile:
            enriched["device_type"] = "mobile"
        elif ua.is_tablet:
            enriched["device_type"] = "tablet"
        else:
            enriched["device_type"] = "desktop"
    else:
        enriched["browser_family"] = None
        enriched["browser_version"] = None
        enriched["os_family"] = None
        enriched["os_version"] = None
        enriched["device_type"] = None

    # ── Timestamp normalization ───────────────────────────────────────────
    enriched["collector_tstamp"] = datetime.now(timezone.utc)

    # Client-sent timestamp (if present)
    dvce_tstamp = raw.get("dvce_sent_tstamp")
    if dvce_tstamp:
        try:
            enriched["dvce_sent_tstamp"] = datetime.fromisoformat(dvce_tstamp)
        except (ValueError, TypeError):
            enriched["dvce_sent_tstamp"] = None
    else:
        enriched["dvce_sent_tstamp"] = None

    # ── IP address ────────────────────────────────────────────────────────
    enriched["ip_address"] = headers.get("x-forwarded-for", headers.get("x-real-ip"))

    # ── Referrer from HTTP header (fallback) ──────────────────────────────
    if not raw.get("data", {}).get("referrer"):
        http_referrer = headers.get("referer")
        if http_referrer:
            enriched["page_referrer"] = http_referrer
    else:
        enriched["page_referrer"] = raw.get("data", {}).get("referrer")

    return enriched
