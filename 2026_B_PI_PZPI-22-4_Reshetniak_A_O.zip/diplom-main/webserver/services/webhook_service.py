"""Webhook service - business logic for webhooks."""

import uuid
import time
from datetime import datetime, timezone
import httpx
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import User, WebhookEndpoint, WebhookLog
from shared.schemas import WebhookCreate, WebhookUpdate, WebhookTestResponse
from shared.config import settings


class WebhookService:
    """Service for managing webhooks."""

    @staticmethod
    async def create_webhook(
        db: AsyncSession, data: WebhookCreate, user_id: uuid.UUID
    ) -> WebhookEndpoint:
        """Create a new webhook endpoint for the given user."""
        webhook = WebhookEndpoint(user_id=user_id, **data.model_dump())
        db.add(webhook)
        await db.commit()
        await db.refresh(webhook)
        return webhook

    @staticmethod
    async def get_webhook(
        db: AsyncSession, webhook_id: uuid.UUID, current_user: User
    ) -> WebhookEndpoint | None:
        """Get webhook by ID; user can only get own, admin can get any."""
        result = await db.execute(
            select(WebhookEndpoint)
            .options(selectinload(WebhookEndpoint.user))
            .where(WebhookEndpoint.id == webhook_id)
        )
        webhook = result.scalar_one_or_none()
        if not webhook:
            return None
        if current_user.role != "admin" and webhook.user_id != current_user.id:
            return None
        return webhook

    @staticmethod
    async def list_webhooks(
        db: AsyncSession, current_user: User
    ) -> list[WebhookEndpoint]:
        """List webhooks: admin sees all (with owner), user sees only own."""
        query = (
            select(WebhookEndpoint)
            .options(selectinload(WebhookEndpoint.user))
            .order_by(WebhookEndpoint.created_at.desc())
        )
        if current_user.role != "admin":
            query = query.where(WebhookEndpoint.user_id == current_user.id)
        result = await db.execute(query)
        return list(result.scalars().unique().all())

    @staticmethod
    async def update_webhook(
        db: AsyncSession, webhook_id: uuid.UUID, data: WebhookUpdate, current_user: User
    ) -> WebhookEndpoint | None:
        """Update a webhook; user can only update own, admin any."""
        webhook = await WebhookService.get_webhook(db, webhook_id, current_user)
        if not webhook:
            return None

        update_data = data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(webhook, field, value)

        await db.commit()
        await db.refresh(webhook)
        return webhook

    @staticmethod
    async def delete_webhook(
        db: AsyncSession, webhook_id: uuid.UUID, current_user: User
    ) -> bool:
        """Delete a webhook; user can only delete own, admin any."""
        webhook = await WebhookService.get_webhook(db, webhook_id, current_user)
        if not webhook:
            return False

        await db.delete(webhook)
        await db.commit()
        return True

    @staticmethod
    async def test_webhook(
        db: AsyncSession, webhook_id: uuid.UUID, current_user: User
    ) -> WebhookTestResponse:
        """Test a webhook; user can only test own, admin any."""
        webhook = await WebhookService.get_webhook(db, webhook_id, current_user)
        if not webhook:
            return WebhookTestResponse(
                success=False,
                status_code=None,
                response_body=None,
                duration_ms=None,
                error_message="Webhook not found",
            )

        # Create test payload
        test_payload = {
            "event_id": str(uuid.uuid4()),
            "event_type": "test",
            "timestamp": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
            "test": True,
            "message": "This is a test webhook from Synthetic Traffic Generator",
        }

        # Send request
        start = time.monotonic()
        async with httpx.AsyncClient() as client:
            try:
                headers = {**webhook.headers, "Content-Type": "application/json"}
                response = await client.post(
                    webhook.url,
                    json=test_payload,
                    headers=headers,
                    timeout=settings.WEBHOOK_TIMEOUT,
                )
                duration_ms = int((time.monotonic() - start) * 1000)

                return WebhookTestResponse(
                    success=response.status_code >= 200 and response.status_code < 300,
                    status_code=response.status_code,
                    response_body=response.text[:1000],
                    duration_ms=duration_ms,
                    error_message=None,
                )
            except Exception as e:
                duration_ms = int((time.monotonic() - start) * 1000)
                return WebhookTestResponse(
                    success=False,
                    status_code=None,
                    response_body=None,
                    duration_ms=duration_ms,
                    error_message=str(e),
                )

    @staticmethod
    async def get_webhook_logs(
        db: AsyncSession,
        webhook_id: uuid.UUID,
        current_user: User,
        success: bool | None = None,
        page: int = 1,
        limit: int = 50,
    ) -> tuple[list[WebhookLog], int]:
        """Get webhook logs; user can only view own webhook logs, admin any."""
        webhook = await WebhookService.get_webhook(db, webhook_id, current_user)
        if not webhook:
            return [], 0
        query = select(WebhookLog).where(WebhookLog.endpoint_id == webhook_id)
        if success is not None:
            query = query.where(WebhookLog.success == success)

        # Get total count
        from sqlalchemy import func
        count_query = select(func.count()).select_from(query.subquery())
        total = await db.scalar(count_query)

        # Get paginated results
        query = query.order_by(WebhookLog.sent_at.desc())
        query = query.offset((page - 1) * limit).limit(limit)
        result = await db.execute(query)
        logs = result.scalars().all()

        return list(logs), total
