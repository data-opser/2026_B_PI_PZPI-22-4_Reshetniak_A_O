"""Event schema registry — defines known event types and their validation rules.

The collector accepts ANY event_type. Known types get validated against
their schema (required/optional fields). Unknown types pass through as
unstructured events — this is intentional, like Snowplow's self-describing
events.

Funnel logic is NOT here. The collector is a dumb pipe — it stores raw
events. Funnel stages, conversion labels, and analytics are applied later
by whoever queries the data.
"""

from dataclasses import dataclass, field


@dataclass(frozen=True)
class EventSchema:
    """Validation rules for a known event type."""

    event_type: str
    required_fields: set[str] = field(default_factory=set)
    optional_fields: set[str] = field(default_factory=set)
    description: str = ""


# ── Schema Registry ──────────────────────────────────────────────────────────

SCHEMAS: dict[str, EventSchema] = {}


def _register(schema: EventSchema) -> EventSchema:
    SCHEMAS[schema.event_type] = schema
    return schema


# Page-level events
_register(EventSchema(
    event_type="page_view",
    optional_fields={"referrer", "page_url", "page_title"},
    description="Fires on every page load",
))

# Interaction events
_register(EventSchema(
    event_type="click",
    optional_fields={"element_text", "element_class", "element_id", "href"},
    description="Click on a link or button",
))

_register(EventSchema(
    event_type="form_submit",
    optional_fields={"form_id", "form_action"},
    description="HTML form submission",
))

_register(EventSchema(
    event_type="form_field_focus",
    optional_fields={"field_name", "field_type"},
    description="Focus on a form input field",
))

_register(EventSchema(
    event_type="scroll_depth",
    optional_fields={"percent", "max_percent"},
    description="User scrolled to a certain depth",
))

# E-commerce events
_register(EventSchema(
    event_type="add_to_cart",
    required_fields={"product_id", "product_name", "price"},
    optional_fields={"quantity", "category"},
    description="Product added to shopping cart",
))

_register(EventSchema(
    event_type="checkout_initiated",
    required_fields={"total"},
    optional_fields={"items_count"},
    description="User began checkout flow",
))

_register(EventSchema(
    event_type="purchase_completed",
    required_fields={"total"},
    optional_fields={"items_count", "payment_method"},
    description="Payment processed successfully",
))

_register(EventSchema(
    event_type="purchase_success",
    optional_fields={"order_id"},
    description="Order confirmation page viewed",
))


# ── Helpers ──────────────────────────────────────────────────────────────────

def get_schema(event_type: str) -> EventSchema | None:
    """Return schema for a known event type, or None for unstructured events."""
    return SCHEMAS.get(event_type)


def validate_event_data(event_type: str, data: dict) -> list[str]:
    """Validate event data against schema. Returns list of error messages (empty = valid)."""
    schema = get_schema(event_type)
    if schema is None:
        return []  # unstructured events pass validation

    errors = []
    for field_name in schema.required_fields:
        if field_name not in data:
            errors.append(f"Missing required field '{field_name}' for event type '{event_type}'")

    return errors
