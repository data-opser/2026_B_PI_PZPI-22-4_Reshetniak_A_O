"""Generation service - business logic for traffic generation."""

import uuid
from datetime import datetime, timezone
from sqlalchemy import select, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload
from celery import group
from shared.models import GenerationJob, Scenario, Session
from shared.schemas import GenerationRequest, JobResponse, JobStatus
from worker.celery_app import celery_app


class GenerationService:
    """Service for managing traffic generation."""

    @staticmethod
    async def create_generation_job(
        db: AsyncSession, data: GenerationRequest
    ) -> GenerationJob:
        """Create a new generation job and dispatch tasks."""
        # Validate scenario exists and is active
        result = await db.execute(
            select(Scenario).where(
                Scenario.id == data.scenario_id, Scenario.is_active == True
            )
        )
        scenario = result.scalar_one_or_none()
        if not scenario:
            raise ValueError("Scenario not found or inactive")

        # Create job
        job = GenerationJob(
            scenario_id=data.scenario_id,
            total_sessions=data.num_sessions,
            config_override=data.config_override,
            schedule_cron=data.schedule_cron,
            status="pending",
        )
        db.add(job)
        await db.commit()
        await db.refresh(job)

        # If no schedule, dispatch tasks immediately
        if not data.schedule_cron:
            await GenerationService._dispatch_session_tasks(
                str(job.id), str(data.scenario_id), data.num_sessions, data.config_override
            )
            # Update job status to running
            await db.execute(
                update(GenerationJob)
                .where(GenerationJob.id == job.id)
                .values(status="running")
            )
            await db.commit()
            await db.refresh(job)

        return job

    @staticmethod
    async def _dispatch_session_tasks(
        job_id: str, scenario_id: str, num_sessions: int, config_override: dict | None
    ):
        """Dispatch Celery tasks for all sessions in a job."""
        from worker.celery_app import celery_app

        # Use task signature by name (avoids importing Playwright dependencies)
        task_signature = celery_app.signature(
            "worker.tasks.generate_session",
            args=[job_id, scenario_id, config_override]
        )

        # Create a group of tasks
        tasks = [task_signature.clone() for _ in range(num_sessions)]

        # Dispatch all tasks
        job = group(tasks)
        job.apply_async()

    @staticmethod
    async def get_job(db: AsyncSession, job_id: uuid.UUID) -> GenerationJob | None:
        """Get job by ID."""
        result = await db.execute(
            select(GenerationJob).where(GenerationJob.id == job_id)
        )
        return result.scalar_one_or_none()

    @staticmethod
    async def list_jobs(
        db: AsyncSession,
        status: str | None = None,
        scenario_id: uuid.UUID | None = None,
        page: int = 1,
        limit: int = 20,
    ) -> tuple[list[GenerationJob], int]:
        """List jobs with filtering and pagination."""
        query = select(GenerationJob).options(selectinload(GenerationJob.scenario))

        if status:
            query = query.where(GenerationJob.status == status)
        if scenario_id:
            query = query.where(GenerationJob.scenario_id == scenario_id)

        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await db.scalar(count_query)

        # Get paginated results
        query = query.order_by(GenerationJob.created_at.desc())
        query = query.offset((page - 1) * limit).limit(limit)
        result = await db.execute(query)
        jobs = result.scalars().all()

        return list(jobs), total

    @staticmethod
    async def get_job_status(db: AsyncSession, job_id: uuid.UUID) -> JobStatus | None:
        """Get detailed job status with progress."""
        job = await GenerationService.get_job(db, job_id)
        if not job:
            return None

        running = job.total_sessions - job.completed_sessions - job.failed_sessions
        percent = (
            (job.completed_sessions + job.failed_sessions) / job.total_sessions * 100
            if job.total_sessions > 0
            else 0
        )

        return JobStatus(
            id=job.id,
            status=job.status,
            total=job.total_sessions,
            completed=job.completed_sessions,
            failed=job.failed_sessions,
            running=running,
            percent_complete=round(percent, 2),
        )

    @staticmethod
    async def cancel_job(db: AsyncSession, job_id: uuid.UUID) -> GenerationJob | None:
        """Cancel a running job."""
        job = await GenerationService.get_job(db, job_id)
        if not job:
            return None

        # Update job status
        await db.execute(
            update(GenerationJob)
            .where(GenerationJob.id == job_id)
            .values(
                status="cancelled",
                finished_at=datetime.now(timezone.utc),
            )
        )
        await db.commit()

        # Note: Celery tasks that are already running will complete
        # Only pending tasks can be revoked
        # TODO: Implement task revocation if needed

        await db.refresh(job)
        return job
