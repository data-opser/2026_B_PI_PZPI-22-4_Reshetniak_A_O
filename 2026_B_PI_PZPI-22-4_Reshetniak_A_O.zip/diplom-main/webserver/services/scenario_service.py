"""Scenario service - business logic for scenarios."""

import uuid
from sqlalchemy import select, update, delete, func
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import Scenario
from shared.schemas import ScenarioCreate, ScenarioUpdate


class ScenarioService:
    """Service for managing scenarios."""

    @staticmethod
    async def get_by_name(db: AsyncSession, name: str) -> Scenario | None:
        """Get scenario by name."""
        result = await db.execute(select(Scenario).where(Scenario.name == name))
        return result.scalar_one_or_none()

    @staticmethod
    async def create_scenario(db: AsyncSession, data: ScenarioCreate) -> Scenario:
        """Create a new scenario."""
        scenario = Scenario(**data.model_dump())
        db.add(scenario)
        await db.commit()
        await db.refresh(scenario)
        return scenario

    @staticmethod
    async def get_scenario(db: AsyncSession, scenario_id: uuid.UUID) -> Scenario | None:
        """Get scenario by ID."""
        result = await db.execute(select(Scenario).where(Scenario.id == scenario_id))
        return result.scalar_one_or_none()

    @staticmethod
    async def list_scenarios(
        db: AsyncSession,
        page: int = 1,
        limit: int = 20,
        is_active: bool | None = None,
    ) -> tuple[list[Scenario], int]:
        """List scenarios with pagination."""
        query = select(Scenario)
        if is_active is not None:
            query = query.where(Scenario.is_active == is_active)

        # Get total count
        count_query = select(func.count()).select_from(query.subquery())
        total = await db.scalar(count_query)

        # Get paginated results
        query = query.order_by(Scenario.created_at.desc())
        query = query.offset((page - 1) * limit).limit(limit)
        result = await db.execute(query)
        scenarios = result.scalars().all()

        return list(scenarios), total

    @staticmethod
    async def update_scenario(
        db: AsyncSession, scenario_id: uuid.UUID, data: ScenarioUpdate
    ) -> Scenario | None:
        """Update a scenario."""
        # Get existing scenario
        scenario = await ScenarioService.get_scenario(db, scenario_id)
        if not scenario:
            return None

        # Update fields
        update_data = data.model_dump(exclude_unset=True)
        for field, value in update_data.items():
            setattr(scenario, field, value)

        await db.commit()
        await db.refresh(scenario)
        return scenario

    @staticmethod
    async def delete_scenario(db: AsyncSession, scenario_id: uuid.UUID) -> bool:
        """Soft delete a scenario (deactivate)."""
        result = await db.execute(
            update(Scenario)
            .where(Scenario.id == scenario_id)
            .values(is_active=False)
        )
        await db.commit()
        return result.rowcount > 0

    @staticmethod
    async def hard_delete_scenario(db: AsyncSession, scenario_id: uuid.UUID) -> bool:
        """Permanently delete a scenario and all related data."""
        scenario = await ScenarioService.get_scenario(db, scenario_id)
        if not scenario:
            return False
        await db.delete(scenario)
        await db.commit()
        return True
