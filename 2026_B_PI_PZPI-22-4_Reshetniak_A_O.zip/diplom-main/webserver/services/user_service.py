"""User service - get user by id or name, create users."""

import uuid
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from shared.models import User, WebhookEndpoint
from webserver.services.auth_service import hash_password


class UserService:
    """Service for user lookup and management."""

    @staticmethod
    async def get_by_id(db: AsyncSession, user_id: uuid.UUID) -> User | None:
        """Get user by ID."""
        result = await db.execute(select(User).where(User.id == user_id))
        return result.scalar_one_or_none()

    @staticmethod
    async def get_by_name(db: AsyncSession, name: str) -> User | None:
        """Get user by name (for login)."""
        result = await db.execute(select(User).where(User.name == name))
        return result.scalar_one_or_none()

    @staticmethod
    async def create_user(
        db: AsyncSession,
        name: str,
        password: str,
        role: str = "user",
    ) -> User:
        """Create a new user with hashed password."""
        user = User(
            name=name,
            password=hash_password(password),
            role=role,
            is_active=True,
        )
        db.add(user)
        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def change_password(db: AsyncSession, user: User, new_password: str) -> User:
        """Change user password."""
        user.password = hash_password(new_password)
        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def set_active(db: AsyncSession, user: User, is_active: bool) -> User:
        """Activate or deactivate a user account.

        Deactivating a user cascades to their resources:
          - Webhook endpoints get `is_active=False` so the collector stops
            dispatching to them.
          - API tokens stop working automatically because
            `ApiTokenService.find_user_by_token` checks `user.is_active`.

        Reactivating only restores the user's ability to log in; webhooks
        must be re-enabled by an admin/owner explicitly to avoid surprise
        traffic to endpoints whose URLs may no longer be valid.
        """
        user.is_active = is_active
        if not is_active:
            await db.execute(
                update(WebhookEndpoint)
                .where(WebhookEndpoint.user_id == user.id)
                .values(is_active=False)
            )
        await db.commit()
        await db.refresh(user)
        return user

    @staticmethod
    async def delete_user(db: AsyncSession, user_id: uuid.UUID) -> bool:
        """Permanently delete a user."""
        result = await db.execute(select(User).where(User.id == user_id))
        user = result.scalar_one_or_none()
        if not user:
            return False
        await db.delete(user)
        await db.commit()
        return True
