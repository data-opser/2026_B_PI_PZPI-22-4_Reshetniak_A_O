"""FastAPI dependencies."""

import uuid
from fastapi import Depends, Header, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from shared.database import AsyncSessionLocal
from shared.config import settings
from shared.models import User
from webserver.services.auth_service import decode_access_token
from webserver.services.user_service import UserService
from webserver.services.api_token_service import ApiTokenService

security = HTTPBearer(auto_error=True)
security_optional = HTTPBearer(auto_error=False)


async def get_db():
    """Get database session dependency."""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def api_key_auth(x_api_key: str = Header(..., alias="X-API-Key")):
    """Validate API key from header (legacy)."""
    if x_api_key != settings.API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid API key",
        )
    return x_api_key


async def _resolve_user(token: str, db: AsyncSession) -> User:
    """Resolve a user from a JWT or API token string."""
    payload = decode_access_token(token)
    if payload and "sub" in payload:
        try:
            user_id = uuid.UUID(payload["sub"])
        except (ValueError, TypeError):
            user_id = None
        if user_id is not None:
            user = await UserService.get_by_id(db, user_id)
            if user and user.is_active:
                return user

    user = await ApiTokenService.find_user_by_token(db, token)
    if user:
        return user

    return None


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Validate JWT Bearer or API token (stg_...) and return current user."""
    token = credentials.credentials.strip()
    user = await _resolve_user(token, db)
    if user:
        return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def get_current_user_optional_bearer(
    request: Request,
    credentials: HTTPAuthorizationCredentials | None = Depends(security_optional),
    db: AsyncSession = Depends(get_db),
) -> User:
    """Like get_current_user but also accepts ?token= query parameter.

    This allows browser-initiated downloads (CSV export links) where
    the Bearer header cannot be set.
    """
    # 1. Try Bearer header
    if credentials and credentials.credentials:
        user = await _resolve_user(credentials.credentials.strip(), db)
        if user:
            return user

    # 2. Try ?token= query param (for browser download links)
    query_token = request.query_params.get("token")
    if query_token:
        user = await _resolve_user(query_token.strip(), db)
        if user:
            return user

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Invalid or expired token. Pass Bearer header or ?token= query param.",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def require_admin(current_user: User = Depends(get_current_user)) -> User:
    """Require current user to have role 'admin'. Raises 403 for non-admin."""
    if current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin access required",
        )
    return current_user
