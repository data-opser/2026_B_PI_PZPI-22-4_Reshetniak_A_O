"""Collector endpoints — lightweight Snowplow-like event collector.

Receives events from the mock-website JS tracker, validates against the schema
registry, enriches with UA parsing / timestamps, and stores canonical events
in the events table. After storing, dispatches webhook deliveries in the
background so subscribers receive events in real time.
"""

import asyncio
import hashlib
import hmac
import json
import time
import uuid
from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, Request, Response
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from shared.config import settings
from shared.database import AsyncSessionLocal
from shared.models.event import Event
from shared.models.session import Session
from shared.models.webhook_endpoint import WebhookEndpoint
from shared.models.webhook_log import WebhookLog
from webserver.services.schema_registry import validate_event_data, SCHEMAS
from webserver.services.enrichment import enrich_event

COLLECTOR_VERSION = "1.0.0"

router = APIRouter(prefix="/col", tags=["collector"])


# ── Request schemas ───────────────────────────────────────────────────────────

class TrackPayload(BaseModel):
    """Incoming event from the JS tracker."""
    event_type: str
    page_url: str
    page_title: str | None = None
    visitor_id: str
    session_id: str | None = None
    session_event_index: int | None = None
    new_session: bool = False
    data: dict = {}
    app_id: str = "mock-website"
    dvce_sent_tstamp: str | None = None


class BatchPayload(BaseModel):
    """Batch of events from the JS tracker."""
    events: list[TrackPayload]


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.post("/track")
async def track_single(payload: TrackPayload, request: Request):
    """Collect a single event — primary endpoint for the JS tracker."""
    headers = dict(request.headers)
    client_host = request.client.host if request.client else None
    event_id = await _process_event(payload, headers, client_host)
    return {"ok": True, "event_id": str(event_id)}


@router.post("/batch")
async def track_batch(payload: BatchPayload, request: Request):
    """Collect a batch of events in one request."""
    headers = dict(request.headers)
    client_host = request.client.host if request.client else None
    event_ids = []
    for event in payload.events:
        eid = await _process_event(event, headers, client_host)
        event_ids.append(str(eid))
    return {"ok": True, "event_ids": event_ids, "count": len(event_ids)}


@router.get("/health")
async def collector_health():
    """Collector health check."""
    return {"status": "ok", "version": COLLECTOR_VERSION}


@router.get("/schemas")
async def list_schemas():
    """List all registered event schemas (for debugging / documentation)."""
    result = {}
    for name, schema in SCHEMAS.items():
        result[name] = {
            "required_fields": sorted(schema.required_fields),
            "optional_fields": sorted(schema.optional_fields),
            "description": schema.description,
        }
    return result


# ── Pixel endpoint (GET-based tracking like Snowplow's /i) ───────────────────

@router.get("/i")
async def track_pixel(
    e: str = "page_view",
    url: str = "",
    title: str | None = None,
    vid: str = "",
    request: Request = None,
):
    """1x1 pixel GET-based tracker (like Snowplow's /i endpoint)."""
    payload = TrackPayload(
        event_type=e,
        page_url=url,
        page_title=title,
        visitor_id=vid,
    )
    headers = dict(request.headers) if request else {}
    client_host = request.client.host if request and request.client else None
    await _process_event(payload, headers, client_host)

    # Return transparent 1x1 GIF
    gif = b"\x47\x49\x46\x38\x39\x61\x01\x00\x01\x00\x80\x00\x00\xff\xff\xff\x00\x00\x00\x21\xf9\x04\x00\x00\x00\x00\x00\x2c\x00\x00\x00\x00\x01\x00\x01\x00\x00\x02\x02\x44\x01\x00\x3b"
    return Response(content=gif, media_type="image/gif")


# ── Processing pipeline ──────────────────────────────────────────────────────

async def _resolve_simulation_session(visitor_id: str | None) -> uuid.UUID | None:
    """If visitor_id parses as a UUID matching a session row, return that UUID."""
    if not visitor_id:
        return None
    try:
        candidate = uuid.UUID(visitor_id)
    except (ValueError, AttributeError):
        return None
    async with AsyncSessionLocal() as db:
        exists = await db.scalar(select(Session.id).where(Session.id == candidate))
        return exists


async def _process_event(payload: TrackPayload, headers: dict, client_host: str | None = None) -> uuid.UUID:
    """Validate → Enrich → Store → Dispatch webhooks. Returns event UUID."""
    raw = payload.model_dump()

    # 1. Validate against schema registry
    errors = validate_event_data(payload.event_type, payload.data)
    is_valid = len(errors) == 0

    # 2. Enrich
    enriched = enrich_event(raw, headers)
    if not enriched.get("ip_address") and client_host:
        enriched["client_host"] = client_host

    # 3. Build canonical event
    event_id = uuid.uuid4()

    # For simulated traffic the worker pre-sets the _stg_id cookie to the
    # session UUID, so visitor_id parses as a UUID matching a sessions.id row.
    simulation_session_id = await _resolve_simulation_session(payload.visitor_id)

    event = Event(
        id=event_id,
        event_type=payload.event_type,
        app_id=payload.app_id,
        visitor_id=payload.visitor_id,
        session_id=payload.session_id,
        simulation_session_id=simulation_session_id,
        page_url=payload.page_url,
        page_title=payload.page_title,
        page_referrer=enriched.get("page_referrer"),
        event_data=payload.data,
        useragent=enriched.get("useragent"),
        browser_family=enriched.get("browser_family"),
        browser_version=enriched.get("browser_version"),
        os_family=enriched.get("os_family"),
        os_version=enriched.get("os_version"),
        device_type=enriched.get("device_type"),
        collector_tstamp=enriched["collector_tstamp"],
        dvce_sent_tstamp=enriched.get("dvce_sent_tstamp"),
        collector_version=COLLECTOR_VERSION,
        ip_address=enriched.get("ip_address") or enriched.get("client_host"),
        is_valid=is_valid,
        validation_errors=errors if errors else None,
    )

    # 4. Store
    async with AsyncSessionLocal() as db:
        db.add(event)
        await db.commit()

    # 5. Dispatch webhooks in background (non-blocking)
    asyncio.create_task(_dispatch_webhooks(event))

    return event_id


# ── Webhook dispatch ─────────────────────────────────────────────────────────

async def _dispatch_webhooks(event: Event) -> None:
    """Send event to all matching active webhook endpoints."""
    try:
        async with AsyncSessionLocal() as db:
            result = await db.execute(
                select(WebhookEndpoint).where(WebhookEndpoint.is_active.is_(True))
            )
            webhooks = result.scalars().all()

            for webhook in webhooks:
                # Filter by event type
                if webhook.event_filter and event.event_type not in webhook.event_filter:
                    continue

                payload = _build_webhook_payload(event)
                await _send_and_log(db, webhook, event, payload, attempt=1)
    except Exception as e:
        print(f"[collector] webhook dispatch error: {e}")


def _build_webhook_payload(event: Event) -> dict:
    """Build webhook payload from event."""
    return {
        "event_id": str(event.id),
        "event_type": event.event_type,
        "timestamp": event.collector_tstamp.isoformat(),
        "visitor_id": event.visitor_id,
        "session_id": event.session_id,
        "page": {
            "url": event.page_url,
            "title": event.page_title,
            "referrer": event.page_referrer,
        },
        "data": event.event_data,
        "device": {
            "type": event.device_type,
            "browser": event.browser_family,
            "os": event.os_family,
        },
        "app_id": event.app_id,
    }


async def _send_and_log(
    db: AsyncSession, webhook: WebhookEndpoint, event: Event, payload: dict, attempt: int
) -> bool:
    """Send HTTP POST to endpoint and record WebhookLog."""
    headers = {**(webhook.headers or {}), "Content-Type": "application/json"}
    headers["X-STG-Event-Type"] = event.event_type
    headers["X-STG-Attempt"] = str(attempt)

    payload_with_attempt = {**payload, "attempt": attempt}

    if webhook.secret:
        payload_str = json.dumps(payload_with_attempt, separators=(",", ":"))
        signature = hmac.new(
            webhook.secret.encode(),
            payload_str.encode(),
            hashlib.sha256,
        ).hexdigest()
        headers["X-STG-Signature"] = f"sha256={signature}"

    start = time.monotonic()
    async with httpx.AsyncClient() as client:
        try:
            response = await client.post(
                webhook.url,
                json=payload_with_attempt,
                headers=headers,
                timeout=settings.WEBHOOK_TIMEOUT,
            )
            duration_ms = int((time.monotonic() - start) * 1000)
            success = 200 <= response.status_code < 300
            log = WebhookLog(
                endpoint_id=webhook.id,
                event_id=event.id,
                attempt=attempt,
                status_code=response.status_code,
                request_body=payload,
                response_body=response.text[:1000],
                success=success,
                duration_ms=duration_ms,
                sent_at=datetime.now(timezone.utc),
            )
            db.add(log)
            await db.commit()
            return success
        except Exception as e:
            duration_ms = int((time.monotonic() - start) * 1000)
            log = WebhookLog(
                endpoint_id=webhook.id,
                event_id=event.id,
                attempt=attempt,
                status_code=None,
                request_body=payload,
                response_body=None,
                error_message=str(e),
                success=False,
                duration_ms=duration_ms,
                sent_at=datetime.now(timezone.utc),
            )
            db.add(log)
            await db.commit()
            return False
