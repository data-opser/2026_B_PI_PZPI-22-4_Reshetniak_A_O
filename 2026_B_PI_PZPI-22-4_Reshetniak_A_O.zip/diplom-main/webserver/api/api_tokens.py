"""API token management endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import ApiTokenCreate, ApiTokenResponse, ApiTokenCreatedResponse
from shared.models import User
from webserver.dependencies import get_db, get_current_user
from webserver.services.api_token_service import ApiTokenService
from webserver.services.user_service import UserService

router = APIRouter(prefix="/api/v1/api-tokens", tags=["api-tokens"])


def _row_to_response(row) -> ApiTokenResponse:
    owner_name = row.user.name if getattr(row, "user", None) else None
    return ApiTokenResponse(
        id=row.id,
        user_id=row.user_id,
        owner_name=owner_name,
        name=row.name,
        expires_at=row.expires_at,
        created_at=row.created_at,
    )


@router.post("", response_model=ApiTokenCreatedResponse, status_code=status.HTTP_201_CREATED)
async def create_api_token(
    data: ApiTokenCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Create a new API token. Plaintext token is returned only in this response."""
    target_user_id = current_user.id
    if data.user_id is not None:
        if current_user.role != "admin":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only admin can create tokens for other users",
            )
        target = await UserService.get_by_id(db, data.user_id)
        if not target or not target.is_active:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Target user not found",
            )
        target_user_id = data.user_id

    row, plain = await ApiTokenService.create_token(
        db, target_user_id, data.name, data.expires_at
    )
    row = await ApiTokenService.get_by_id(db, row.id)
    base = _row_to_response(row)
    return ApiTokenCreatedResponse(**base.model_dump(), token=plain)


@router.get("", response_model=list[ApiTokenResponse])
async def list_api_tokens(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List tokens: own only for regular users; all tokens for admin."""
    rows = await ApiTokenService.list_for_user(db, current_user)
    return [_row_to_response(r) for r in rows]


@router.delete("/{token_id}", status_code=status.HTTP_204_NO_CONTENT)
async def revoke_api_token(
    token_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Revoke (delete) a token. User: own only; admin: any."""
    ok = await ApiTokenService.delete_token(db, token_id, current_user)
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Token not found",
        )
