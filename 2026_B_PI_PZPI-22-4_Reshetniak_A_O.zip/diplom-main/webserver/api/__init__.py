"""API router aggregation."""

from fastapi import APIRouter
from webserver.api import auth, api_tokens, users, scenarios, webhooks, generation, events, sessions, stats, collector

api_router = APIRouter()
api_router.include_router(auth.router)
api_router.include_router(api_tokens.router)
api_router.include_router(users.router)
api_router.include_router(scenarios.router)
api_router.include_router(webhooks.router)
api_router.include_router(generation.router)
api_router.include_router(events.router)
api_router.include_router(sessions.router)
api_router.include_router(stats.router)
api_router.include_router(collector.router)

__all__ = ["api_router"]
