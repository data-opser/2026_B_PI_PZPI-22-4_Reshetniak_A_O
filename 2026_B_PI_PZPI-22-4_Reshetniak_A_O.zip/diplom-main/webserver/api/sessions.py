"""Sessions API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import SessionResponse, SessionDetail, EventResponse
from webserver.dependencies import get_db, get_current_user
from shared.models import User
from webserver.services.session_service import SessionService

router = APIRouter(prefix="/api/v1/sessions", tags=["sessions"])


@router.get("", response_model=dict)
async def list_sessions(
    job_id: uuid.UUID | None = None,
    scenario_id: uuid.UUID | None = None,
    status_filter: str | None = Query(None, alias="status"),
    result: str | None = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """List sessions with filtering and pagination."""
    sessions, total = await SessionService.list_sessions(
        db, job_id, scenario_id, status_filter, result, page, limit
    )

    return {
        "items": [SessionResponse.model_validate(s) for s in sessions],
        "total": total,
        "page": page,
    }


@router.get("/{session_id}", response_model=dict)
async def get_session_detail(
    session_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Get detailed session view with events and agent decisions."""
    detail = await SessionService.get_session_detail(db, session_id)

    if not detail:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found",
        )

    # Convert to response format
    session_response = SessionResponse.model_validate(detail["session"])

    return {
        "session": session_response,
        "events": [EventResponse.model_validate(e) for e in detail["events"]],
        "agent_decisions": [
            {
                "step_number": d.step_number,
                "thought": d.llm_thought,
                "action": d.action_taken,
                "page_url": d.page_url,
                "response_time_ms": d.response_time_ms,
                "parse_success": d.parse_success,
            }
            for d in detail["agent_decisions"]
        ],
    }
