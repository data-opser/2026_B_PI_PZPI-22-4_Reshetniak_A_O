"""Generation API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import GenerationRequest, JobResponse, JobStatus
from webserver.dependencies import get_db, require_admin
from shared.models import User
from webserver.services.generation_service import GenerationService

router = APIRouter(prefix="/api/v1", tags=["generation"])


@router.post("/generate", response_model=JobResponse, status_code=status.HTTP_201_CREATED)
async def create_generation_job(
    data: GenerationRequest,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Create a new traffic generation job."""
    try:
        job = await GenerationService.create_generation_job(db, data)
        return job
    except ValueError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(e),
        )


@router.get("/jobs", response_model=dict)
async def list_jobs(
    status_filter: str | None = Query(None, alias="status"),
    scenario_id: uuid.UUID | None = None,
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """List generation jobs with filtering."""
    jobs, total = await GenerationService.list_jobs(
        db, status_filter, scenario_id, page, limit
    )
    items = [
        JobResponse.model_validate(j).model_copy(
            update={"scenario_name": j.scenario.name if j.scenario else None}
        )
        for j in jobs
    ]
    return {
        "items": items,
        "total": total,
        "page": page,
    }


@router.get("/jobs/{job_id}", response_model=JobStatus)
async def get_job_status(
    job_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Get job status with progress details."""
    job_status = await GenerationService.get_job_status(db, job_id)
    if not job_status:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    return job_status


@router.post("/jobs/{job_id}/cancel", response_model=JobResponse)
async def cancel_job(
    job_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Cancel a running job."""
    job = await GenerationService.cancel_job(db, job_id)
    if not job:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Job not found",
        )
    return job
