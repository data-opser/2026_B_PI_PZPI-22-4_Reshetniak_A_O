"""Stats API endpoints."""

import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import FunnelStats, ThroughputStats, AgentStats
from shared.schemas.stats import WebhookDeliveryStats
from webserver.dependencies import get_db, get_current_user
from shared.models import User
from webserver.services.stats_service import StatsService

router = APIRouter(prefix="/api/v1/stats", tags=["stats"])


@router.get("/funnel", response_model=FunnelStats)
async def get_funnel_stats(
    scenario_id: uuid.UUID | None = None,
    from_date: str | None = Query(None, alias="from"),
    to_date: str | None = Query(None, alias="to"),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Get funnel statistics."""
    # Parse dates
    from_dt = None
    to_dt = None

    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
        except Exception:
            pass

    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
        except Exception:
            pass

    stats = await StatsService.get_funnel_stats(db, scenario_id, from_dt, to_dt)
    return stats


@router.get("/throughput", response_model=ThroughputStats)
async def get_throughput_stats(
    period: str = Query("hour", pattern="^(hour|day)$"),
    from_date: str | None = Query(None, alias="from"),
    to_date: str | None = Query(None, alias="to"),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Get throughput statistics."""
    # Parse dates
    from_dt = None
    to_dt = None

    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
        except Exception:
            pass

    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
        except Exception:
            pass

    stats = await StatsService.get_throughput_stats(db, period, from_dt, to_dt)
    return stats


@router.get("/agent", response_model=AgentStats)
async def get_agent_stats(
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Get agent performance statistics."""
    stats = await StatsService.get_agent_stats(db)
    return stats


@router.get("/webhook-deliveries", response_model=WebhookDeliveryStats)
async def get_webhook_delivery_stats(
    owner_user_id: uuid.UUID | None = Query(None, description="Admin: filter by webhook owner"),
    endpoint_id: uuid.UUID | None = Query(None, description="Filter by webhook id"),
    event_type: str | None = Query(None, description="Filter by event type in payload"),
    from_date: str | None = Query(None, alias="from"),
    to_date: str | None = Query(None, alias="to"),
    success_only: bool | None = Query(None, description="true=only successful, false=only failed"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """
    Webhook delivery statistics: how many event notifications were sent, per webhook and event type.
    Regular users see only their webhooks; admins see all and can filter by owner, webhook, dates, etc.
    """
    if owner_user_id is not None and current_user.role != "admin":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only admin can filter by owner_user_id",
        )

    from_dt = to_dt = None
    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace("Z", "+00:00"))
        except Exception:
            pass
    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace("Z", "+00:00"))
        except Exception:
            pass

    return await StatsService.get_webhook_delivery_stats(
        db,
        current_user,
        owner_user_id=owner_user_id,
        endpoint_id=endpoint_id,
        event_type=event_type,
        from_dt=from_dt,
        to_dt=to_dt,
        success_only=success_only,
    )
