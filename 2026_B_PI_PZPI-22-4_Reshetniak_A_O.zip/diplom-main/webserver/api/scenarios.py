"""Scenarios API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import ScenarioCreate, ScenarioUpdate, ScenarioResponse
from webserver.dependencies import get_db, get_current_user, require_admin
from shared.models import User
from webserver.services.scenario_service import ScenarioService

router = APIRouter(prefix="/api/v1/scenarios", tags=["scenarios"])


@router.post("", response_model=ScenarioResponse, status_code=status.HTTP_201_CREATED)
async def create_scenario(
    data: ScenarioCreate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Create a new scenario (admin only)."""
    existing = await ScenarioService.get_by_name(db, data.name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Scenario '{data.name}' already exists",
        )
    try:
        scenario = await ScenarioService.create_scenario(db, data)
    except IntegrityError:
        # Race: someone else inserted the same name between the check and commit.
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Scenario '{data.name}' already exists",
        )
    return scenario


@router.get("", response_model=dict)
async def list_scenarios(
    page: int = Query(1, ge=1),
    limit: int = Query(20, ge=1, le=100),
    is_active: bool | None = None,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """List scenarios with pagination (all authenticated users)."""
    scenarios, total = await ScenarioService.list_scenarios(db, page, limit, is_active)
    return {
        "items": [ScenarioResponse.model_validate(s) for s in scenarios],
        "total": total,
        "page": page,
    }


@router.get("/{scenario_id}", response_model=ScenarioResponse)
async def get_scenario(
    scenario_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user),
):
    """Get scenario by ID (all authenticated users)."""
    scenario = await ScenarioService.get_scenario(db, scenario_id)
    if not scenario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Scenario not found",
        )
    return scenario


@router.put("/{scenario_id}", response_model=ScenarioResponse)
async def update_scenario(
    scenario_id: uuid.UUID,
    data: ScenarioUpdate,
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Update a scenario (admin only)."""
    scenario = await ScenarioService.update_scenario(db, scenario_id, data)
    if not scenario:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Scenario not found",
        )
    return scenario


@router.delete("/{scenario_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_scenario(
    scenario_id: uuid.UUID,
    hard: bool = Query(False, description="Permanently delete instead of deactivating"),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(require_admin),
):
    """Delete a scenario (admin only). Use ?hard=true for permanent deletion."""
    if hard:
        deleted = await ScenarioService.hard_delete_scenario(db, scenario_id)
    else:
        deleted = await ScenarioService.delete_scenario(db, scenario_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Scenario not found",
        )
