"""Events API endpoints."""

import csv
import io
from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import EventResponse, EventFilter
from webserver.dependencies import get_db, get_current_user, get_current_user_optional_bearer
from shared.models import User
from webserver.services.event_service import EventService

router = APIRouter(prefix="/api/v1/events", tags=["events"])


@router.get("", response_model=dict)
async def list_events(
    event_type: str | None = None,
    session_id: str | None = None,
    visitor_id: str | None = None,
    from_ts: str | None = Query(None, alias="from"),
    to_ts: str | None = Query(None, alias="to"),
    cursor: str | None = None,
    limit: int = Query(100, ge=1, le=10000),
    format: str = Query("json", pattern="^(json|csv)$"),
    token: str | None = Query(None, description="API token for CSV download links"),
    db: AsyncSession = Depends(get_db),
    _: User = Depends(get_current_user_optional_bearer),
):
    """
    List events with filtering and cursor-based pagination.

    Supports JSON and CSV export formats.
    """
    import uuid
    from datetime import datetime

    filters = EventFilter(
        event_type=event_type,
        session_id=session_id or None,
        visitor_id=visitor_id or None,
        cursor=uuid.UUID(cursor) if cursor else None,
        limit=limit,
        format=format,
    )

    if from_ts:
        try:
            filters.from_timestamp = datetime.fromisoformat(from_ts.replace("Z", "+00:00"))
        except Exception:
            pass

    if to_ts:
        try:
            filters.to_timestamp = datetime.fromisoformat(to_ts.replace("Z", "+00:00"))
        except Exception:
            pass

    if format == "csv":
        events = await EventService.export_events_csv(db, filters)
        return generate_csv_response(events)

    events, next_cursor = await EventService.list_events(db, filters)

    return {
        "items": [EventResponse.model_validate(e) for e in events],
        "next_cursor": str(next_cursor) if next_cursor else None,
        "limit": limit,
    }


def generate_csv_response(events: list) -> StreamingResponse:
    """Generate CSV file from events.

    Uses semicolon delimiter + UTF-8 BOM so Microsoft Excel opens the file
    correctly in non-English locales (ru, uk, de, etc.) without import wizard.
    """
    output = io.StringIO()
    writer = csv.writer(output, delimiter=";")

    writer.writerow([
        "id",
        "event_type",
        "visitor_id",
        "session_id",
        "page_url",
        "page_title",
        "device_type",
        "browser_family",
        "os_family",
        "event_data",
        "collector_tstamp",
    ])

    for event in events:
        writer.writerow([
            str(event.id),
            event.event_type,
            event.visitor_id,
            event.session_id or "",
            event.page_url,
            event.page_title or "",
            event.device_type or "",
            event.browser_family or "",
            event.os_family or "",
            str(event.event_data),
            event.collector_tstamp.isoformat(),
        ])

    csv_text = output.getvalue()
    # Encode with UTF-8 BOM so Excel detects encoding automatically
    csv_bytes = b"\xef\xbb\xbf" + csv_text.encode("utf-8")

    return StreamingResponse(
        iter([csv_bytes]),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": "attachment; filename=events.csv"},
    )
