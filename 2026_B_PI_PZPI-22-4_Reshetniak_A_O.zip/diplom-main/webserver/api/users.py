"""User management (admin) — listing and creation."""

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from pydantic import BaseModel, Field
import uuid
from shared.models import User as UserModel
from webserver.dependencies import get_db, require_admin
from webserver.services.user_service import UserService

router = APIRouter(prefix="/api/v1/users", tags=["users"])


class UserListItem(BaseModel):
    id: uuid.UUID
    name: str
    role: str
    is_active: bool

    class Config:
        from_attributes = True


class UserCreateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=255)
    password: str = Field(..., min_length=4, max_length=255)
    role: str = Field(default="user", pattern=r"^(admin|user)$")


class ChangePasswordRequest(BaseModel):
    password: str = Field(..., min_length=4, max_length=255)


class SetActiveRequest(BaseModel):
    is_active: bool


@router.get("", response_model=list[UserListItem])
async def list_users(
    db: AsyncSession = Depends(get_db),
    _: UserModel = Depends(require_admin),
):
    """List users (admin only) — for assigning API tokens etc."""
    result = await db.execute(select(UserModel).order_by(UserModel.name))
    users = result.scalars().all()
    return [UserListItem.model_validate(u) for u in users]


@router.post("", response_model=UserListItem, status_code=status.HTTP_201_CREATED)
async def create_user(
    body: UserCreateRequest,
    db: AsyncSession = Depends(get_db),
    _: UserModel = Depends(require_admin),
):
    """Create a new user (admin only)."""
    existing = await UserService.get_by_name(db, body.name)
    if existing:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"User '{body.name}' already exists",
        )
    user = await UserService.create_user(db, body.name, body.password, body.role)
    return UserListItem.model_validate(user)


@router.patch("/{user_id}/password", status_code=status.HTTP_200_OK)
async def change_user_password(
    user_id: uuid.UUID,
    body: ChangePasswordRequest,
    db: AsyncSession = Depends(get_db),
    _: UserModel = Depends(require_admin),
):
    """Change a user's password (admin only)."""
    user = await UserService.get_by_id(db, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    await UserService.change_password(db, user, body.password)
    return {"detail": "Password updated"}


@router.patch("/{user_id}/active", response_model=UserListItem)
async def set_user_active(
    user_id: uuid.UUID,
    body: SetActiveRequest,
    db: AsyncSession = Depends(get_db),
    current_user: UserModel = Depends(require_admin),
):
    """Activate or deactivate a user (admin only). Cannot deactivate yourself."""
    if user_id == current_user.id and not body.is_active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot deactivate yourself",
        )
    user = await UserService.get_by_id(db, user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
    user = await UserService.set_active(db, user, body.is_active)
    return UserListItem.model_validate(user)


@router.delete("/{user_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_user(
    user_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: UserModel = Depends(require_admin),
):
    """Delete a user (admin only). Cannot delete yourself."""
    if user_id == current_user.id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete yourself",
        )
    deleted = await UserService.delete_user(db, user_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found",
        )
