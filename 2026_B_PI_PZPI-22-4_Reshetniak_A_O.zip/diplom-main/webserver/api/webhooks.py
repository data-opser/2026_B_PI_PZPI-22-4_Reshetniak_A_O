"""Webhooks API endpoints."""

import uuid
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from shared.schemas import (
    WebhookCreate,
    WebhookUpdate,
    WebhookResponse,
    WebhookLogResponse,
    WebhookTestResponse,
)
from webserver.dependencies import get_db, get_current_user
from shared.models import User
from webserver.services.webhook_service import WebhookService

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


def _webhook_to_response(webhook, owner_name: str | None = None) -> WebhookResponse:
    """Build WebhookResponse; include owner_name from loaded user or argument."""
    data = WebhookResponse.model_validate(webhook)
    if owner_name is not None:
        data.owner_name = owner_name
    elif hasattr(webhook, "user") and webhook.user is not None:
        data.owner_name = webhook.user.name
    return data


@router.post("", response_model=WebhookResponse, status_code=status.HTTP_201_CREATED)
async def create_webhook(
    data: WebhookCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Create a new webhook endpoint (owned by current user)."""
    webhook = await WebhookService.create_webhook(db, data, current_user.id)
    return _webhook_to_response(webhook, owner_name=current_user.name)


@router.get("", response_model=list[WebhookResponse])
async def list_webhooks(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """List webhooks: admin sees all with owner, user sees only own."""
    webhooks = await WebhookService.list_webhooks(db, current_user)
    return [_webhook_to_response(w) for w in webhooks]


@router.get("/{webhook_id}", response_model=WebhookResponse)
async def get_webhook(
    webhook_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get webhook by ID (user: own only, admin: any)."""
    webhook = await WebhookService.get_webhook(db, webhook_id, current_user)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found",
        )
    return _webhook_to_response(webhook)


@router.put("/{webhook_id}", response_model=WebhookResponse)
async def update_webhook(
    webhook_id: uuid.UUID,
    data: WebhookUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Update a webhook (user: own only, admin: any)."""
    webhook = await WebhookService.update_webhook(db, webhook_id, data, current_user)
    if not webhook:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found",
        )
    return _webhook_to_response(webhook)


@router.delete("/{webhook_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_webhook(
    webhook_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Delete a webhook (user: own only, admin: any)."""
    deleted = await WebhookService.delete_webhook(db, webhook_id, current_user)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Webhook not found",
        )


@router.post("/{webhook_id}/test", response_model=WebhookTestResponse)
async def test_webhook(
    webhook_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Test a webhook endpoint (user: own only, admin: any)."""
    result = await WebhookService.test_webhook(db, webhook_id, current_user)
    return result


@router.get("/{webhook_id}/logs", response_model=dict)
async def get_webhook_logs(
    webhook_id: uuid.UUID,
    success: bool | None = None,
    page: int = Query(1, ge=1),
    limit: int = Query(50, ge=1, le=100),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get webhook delivery logs (user: own webhook only, admin: any)."""
    logs, total = await WebhookService.get_webhook_logs(
        db, webhook_id, current_user, success, page, limit
    )
    return {
        "items": [WebhookLogResponse.model_validate(log) for log in logs],
        "total": total,
        "page": page,
    }
