import { useState, useMemo } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { sessionsApi } from '../api/sessions'
import { statsApi, type WebhookDeliveryFilters } from '../api/stats'
import { webhooksApi } from '../api/webhooks'
import { usersApi } from '../api/users'
import StatusBadge from '../components/StatusBadge'
import { useAuth } from '../contexts/AuthContext'

const EVENT_TYPES = ['page_view', 'click', 'form_submit', 'form_field_focus', 'add_to_cart', 'checkout_initiated', 'purchase_completed', 'purchase_success']

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="bg-white overflow-hidden shadow rounded-lg">
      <div className="p-5">
        <div className="flex items-center">
          <div className="ml-5 w-0 flex-1">
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">{label}</dt>
              <dd className="text-3xl font-semibold text-gray-900">{value}</dd>
            </dl>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Dashboard() {
  const { isAdmin } = useAuth()
  const [whFrom, setWhFrom] = useState('')
  const [whTo, setWhTo] = useState('')
  const [whEventType, setWhEventType] = useState('')
  const [whEndpointId, setWhEndpointId] = useState('')
  const [whOwnerId, setWhOwnerId] = useState('')
  const [whSuccess, setWhSuccess] = useState<'all' | 'ok' | 'fail'>('all')

  const deliveryFilters: WebhookDeliveryFilters = useMemo(() => {
    const f: WebhookDeliveryFilters = {}
    if (whFrom) f.from = new Date(whFrom).toISOString()
    if (whTo) f.to = new Date(whTo).toISOString()
    if (whEventType) f.event_type = whEventType
    if (whEndpointId) f.endpoint_id = whEndpointId
    if (isAdmin && whOwnerId) f.owner_user_id = whOwnerId
    if (whSuccess === 'ok') f.success_only = true
    if (whSuccess === 'fail') f.success_only = false
    return f
  }, [whFrom, whTo, whEventType, whEndpointId, whOwnerId, whSuccess, isAdmin])

  const { data: sessionsPage, isLoading } = useQuery({
    queryKey: ['sessions', 'recent'],
    queryFn: () => sessionsApi.list(1, 5),
    refetchInterval: 15_000,
  })
  const sessions = sessionsPage?.items

  const { data: whStats, isLoading: whLoading } = useQuery({
    queryKey: ['stats', 'webhook-deliveries', deliveryFilters],
    queryFn: () => statsApi.webhookDeliveries(deliveryFilters),
    refetchInterval: 30_000,
  })

  const { data: webhooksList } = useQuery({
    queryKey: ['webhooks'],
    queryFn: webhooksApi.list,
  })

  const { data: usersList } = useQuery({
    queryKey: ['users', 'list'],
    queryFn: usersApi.list,
    enabled: isAdmin,
  })

  return (
    <div className="px-4 sm:px-0">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard</h1>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <StatCard label="Recent Sessions" value={sessions?.length ?? '—'} />
        <StatCard
          label="Running"
          value={sessions?.filter((s) => s.status === 'running').length ?? '—'}
        />
        <StatCard
          label="Completed"
          value={sessions?.filter((s) => s.status === 'completed').length ?? '—'}
        />
        <StatCard
          label="Failed"
          value={sessions?.filter((s) => s.status === 'failed').length ?? '—'}
        />
      </div>

      {/* Webhook delivery statistics */}
      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-2">Webhook Delivery Statistics</h2>
        <p className="text-sm text-gray-500 mb-4">
          {isAdmin
            ? 'Overall statistics across all webhooks. Use filters to narrow down.'
            : 'Statistics for your webhooks: how many event notifications were sent and which event types.'}
        </p>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 mb-6">
          <div>
            <label className="block text-xs font-medium text-gray-600">From date</label>
            <input
              type="datetime-local"
              value={whFrom}
              onChange={(e) => setWhFrom(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600">To date</label>
            <input
              type="datetime-local"
              value={whTo}
              onChange={(e) => setWhTo(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600">Event type</label>
            <select
              value={whEventType}
              onChange={(e) => setWhEventType(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
            >
              <option value="">All</option>
              {EVENT_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-gray-600">Webhook</label>
            <select
              value={whEndpointId}
              onChange={(e) => setWhEndpointId(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
            >
              <option value="">All</option>
              {(webhooksList ?? []).map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name}
                </option>
              ))}
            </select>
          </div>
          {isAdmin && (
            <div>
              <label className="block text-xs font-medium text-gray-600">Owner</label>
              <select
                value={whOwnerId}
                onChange={(e) => setWhOwnerId(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
              >
                <option value="">All users</option>
                {(usersList ?? []).map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>
          )}
          <div>
            <label className="block text-xs font-medium text-gray-600">Delivery status</label>
            <select
              value={whSuccess}
              onChange={(e) => setWhSuccess(e.target.value as 'all' | 'ok' | 'fail')}
              className="mt-1 block w-full border border-gray-300 rounded-md py-1.5 px-2 text-sm"
            >
              <option value="all">All attempts</option>
              <option value="ok">Successful only</option>
              <option value="fail">Errors only</option>
            </select>
          </div>
        </div>

        {whLoading ? (
          <p className="text-sm text-gray-500">Loading...</p>
        ) : whStats ? (
          <>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-6">
              <StatCard label="Total attempts" value={whStats.total_deliveries} />
              <StatCard label="Successful" value={whStats.successful_deliveries} />
              <StatCard label="Errors" value={whStats.failed_deliveries} />
              <StatCard label="Unique events (success)" value={whStats.unique_events_delivered} />
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">By webhook</h3>
                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200 text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left font-medium text-gray-600">Webhook</th>
                        {isAdmin && <th className="px-3 py-2 text-left font-medium text-gray-600">Owner</th>}
                        <th className="px-3 py-2 text-right font-medium text-gray-600">Total</th>
                        <th className="px-3 py-2 text-right font-medium text-gray-600">OK</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {whStats.by_webhook.length === 0 ? (
                        <tr>
                          <td colSpan={isAdmin ? 4 : 3} className="px-3 py-4 text-gray-500 text-center">
                            No data
                          </td>
                        </tr>
                      ) : (
                        whStats.by_webhook.map((row) => (
                          <tr key={row.endpoint_id}>
                            <td className="px-3 py-2 text-gray-900">{row.webhook_name}</td>
                            {isAdmin && (
                              <td className="px-3 py-2 text-gray-600">{row.owner_name ?? '—'}</td>
                            )}
                            <td className="px-3 py-2 text-right">{row.delivery_count}</td>
                            <td className="px-3 py-2 text-right text-green-700">{row.success_count}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
              <div>
                <h3 className="text-sm font-semibold text-gray-900 mb-2">By event type</h3>
                <div className="border rounded-md overflow-hidden">
                  <table className="min-w-full divide-y divide-gray-200 text-sm">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-3 py-2 text-left font-medium text-gray-600">Type</th>
                        <th className="px-3 py-2 text-right font-medium text-gray-600">Deliveries</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {whStats.by_event_type.length === 0 ? (
                        <tr>
                          <td colSpan={2} className="px-3 py-4 text-gray-500 text-center">
                            No data
                          </td>
                        </tr>
                      ) : (
                        whStats.by_event_type.map((row) => (
                          <tr key={row.event_type}>
                            <td className="px-3 py-2">
                              <span className="inline-flex px-2 py-0.5 rounded text-xs bg-gray-100 text-gray-800">
                                {row.event_type}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-right">{row.count}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </>
        ) : null}
      </div>

      {/* Quick Actions */}
      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Quick Actions</h2>
        <div className="flex flex-wrap gap-4">
          {isAdmin && (
            <>
              <Link
                to="/scenarios/new"
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
              >
                Create Scenario
              </Link>
              <Link
                to="/generation"
                className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
              >
                Generate Traffic
              </Link>
            </>
          )}
          <Link
            to="/events"
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            View Events
          </Link>
          <Link
            to="/webhooks"
            className="inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
          >
            Webhooks
          </Link>
        </div>
      </div>

      {/* Recent Sessions */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-5 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Recent Sessions</h2>
        </div>
        <div className="divide-y divide-gray-200">
          {isLoading ? (
            <div className="px-6 py-8 text-center text-gray-500">Loading...</div>
          ) : sessions && sessions.length > 0 ? (
            sessions.map((session) => (
              <div key={session.id} className="px-6 py-4 hover:bg-gray-50">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-900">
                      Session {session.id.slice(0, 8)}
                    </p>
                    <p className="text-sm text-gray-500">
                      {String(session.user_profile?.name ?? 'Unknown')} &bull;{' '}
                      {session.total_events} events
                    </p>
                  </div>
                  <div className="flex items-center space-x-4">
                    <StatusBadge status={session.status} />
                    {session.result && (
                      <span className="text-sm text-gray-500">{session.result}</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          ) : (
            <div className="px-6 py-8 text-center">
              <p className="text-gray-500">
                No sessions yet. Create a scenario and generate traffic to get started.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
