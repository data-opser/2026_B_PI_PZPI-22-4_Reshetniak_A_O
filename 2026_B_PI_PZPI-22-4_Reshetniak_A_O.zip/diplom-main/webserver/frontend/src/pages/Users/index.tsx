import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { usersApi } from '../../api/users'
import { useAuth } from '../../contexts/AuthContext'

export default function UsersPage() {
  const qc = useQueryClient()
  const { user: currentUser } = useAuth()
  const [name, setName] = useState('')
  const [password, setPassword] = useState('')
  const [role, setRole] = useState('user')
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  // Change password state
  const [pwUserId, setPwUserId] = useState<string | null>(null)
  const [pwUserName, setPwUserName] = useState('')
  const [newPassword, setNewPassword] = useState('')

  const { data: users, isLoading } = useQuery({
    queryKey: ['users', 'list'],
    queryFn: usersApi.list,
  })

  const createMutation = useMutation({
    mutationFn: () => usersApi.create({ name: name.trim(), password, role }),
    onSuccess: (data) => {
      setSuccess(`User "${data.name}" created successfully`)
      setName('')
      setPassword('')
      setRole('user')
      setError(null)
      qc.invalidateQueries({ queryKey: ['users', 'list'] })
    },
    onError: (e: Error) => {
      setError(e.message)
      setSuccess(null)
    },
  })

  const deleteMutation = useMutation({
    mutationFn: (userId: string) => usersApi.delete(userId),
    onSuccess: () => {
      setSuccess('User deleted')
      setError(null)
      qc.invalidateQueries({ queryKey: ['users', 'list'] })
    },
    onError: (e: Error) => {
      setError(e.message)
      setSuccess(null)
    },
  })

  const setActiveMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: string; isActive: boolean }) =>
      usersApi.setActive(userId, isActive),
    onSuccess: (data) => {
      setSuccess(`User "${data.name}" ${data.is_active ? 'activated' : 'deactivated'}`)
      setError(null)
      qc.invalidateQueries({ queryKey: ['users', 'list'] })
    },
    onError: (e: Error) => {
      setError(e.message)
      setSuccess(null)
    },
  })

  const handleToggleActive = (userId: string, userName: string, currentlyActive: boolean) => {
    if (
      confirm(
        currentlyActive
          ? `Deactivate user "${userName}"? They will not be able to log in.`
          : `Activate user "${userName}"? They will be able to log in again.`,
      )
    ) {
      setActiveMutation.mutate({ userId, isActive: !currentlyActive })
    }
  }

  const changePasswordMutation = useMutation({
    mutationFn: () => usersApi.changePassword(pwUserId!, newPassword),
    onSuccess: () => {
      setSuccess(`Password changed for "${pwUserName}"`)
      setError(null)
      setPwUserId(null)
      setPwUserName('')
      setNewPassword('')
    },
    onError: (e: Error) => {
      setError(e.message)
      setSuccess(null)
    },
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!name.trim()) {
      setError('Name is required')
      return
    }
    if (password.length < 4) {
      setError('Password must be at least 4 characters')
      return
    }
    createMutation.mutate()
  }

  const handleDelete = (userId: string, userName: string) => {
    if (confirm(`Delete user "${userName}"? This cannot be undone.`)) {
      deleteMutation.mutate(userId)
    }
  }

  const handleChangePasswordSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (newPassword.length < 4) {
      setError('Password must be at least 4 characters')
      return
    }
    changePasswordMutation.mutate()
  }

  return (
    <div className="px-4 sm:px-0">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Users</h1>
        <p className="mt-2 text-sm text-gray-600">
          Manage user accounts. Only administrators can create new users.
        </p>
      </div>

      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Add user</h2>

        {error && (
          <div className="mb-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded p-3">{error}</div>
        )}
        {success && (
          <div className="mb-4 text-sm text-green-700 bg-green-50 border border-green-200 rounded p-3">{success}</div>
        )}

        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 sm:grid-cols-3 max-w-3xl">
            <div>
              <label className="block text-sm font-medium text-gray-700">Username</label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
                placeholder="john"
                required
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
                placeholder="min 4 characters"
                required
                minLength={4}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
              >
                <option value="user">user</option>
                <option value="admin">admin</option>
              </select>
            </div>
          </div>
          <button
            type="submit"
            disabled={createMutation.isPending}
            className="mt-4 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 disabled:opacity-50"
          >
            {createMutation.isPending ? 'Creating...' : 'Create user'}
          </button>
        </form>
      </div>

      {/* Change password modal */}
      {pwUserId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
          <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-sm">
            <h3 className="text-lg font-medium text-gray-900 mb-4">
              Change password for &quot;{pwUserName}&quot;
            </h3>
            <form onSubmit={handleChangePasswordSubmit}>
              <input
                type="password"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                placeholder="New password (min 4 chars)"
                className="block w-full border border-gray-300 rounded-md py-2 px-3 text-sm mb-4"
                required
                minLength={4}
                autoFocus
              />
              <div className="flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => { setPwUserId(null); setNewPassword('') }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={changePasswordMutation.isPending}
                  className="px-4 py-2 text-sm font-medium text-white bg-indigo-600 rounded-md hover:bg-indigo-700 disabled:opacity-50"
                >
                  {changePasswordMutation.isPending ? 'Saving...' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">All users</h2>
        </div>
        {isLoading ? (
          <div className="py-12 text-center text-gray-500">Loading...</div>
        ) : users && users.length > 0 ? (
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Role</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {users.map((u) => (
                <tr key={u.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{u.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      u.role === 'admin' ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-800'
                    }`}>
                      {u.role}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                      u.is_active ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                    }`}>
                      {u.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm space-x-2">
                    <button
                      onClick={() => { setPwUserId(u.id); setPwUserName(u.name); setNewPassword('') }}
                      className="text-indigo-600 hover:text-indigo-900 font-medium"
                    >
                      Change password
                    </button>
                    {u.id !== currentUser?.id && (
                      <button
                        onClick={() => handleToggleActive(u.id, u.name, u.is_active)}
                        disabled={setActiveMutation.isPending}
                        className={`font-medium ${
                          u.is_active
                            ? 'text-amber-600 hover:text-amber-900'
                            : 'text-green-600 hover:text-green-900'
                        }`}
                      >
                        {u.is_active ? 'Deactivate' : 'Activate'}
                      </button>
                    )}
                    {u.id !== currentUser?.id && (
                      <button
                        onClick={() => handleDelete(u.id, u.name)}
                        disabled={deleteMutation.isPending}
                        className="text-red-600 hover:text-red-900 font-medium"
                      >
                        Delete
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div className="py-12 text-center text-gray-500">No users found.</div>
        )}
      </div>
    </div>
  )
}
