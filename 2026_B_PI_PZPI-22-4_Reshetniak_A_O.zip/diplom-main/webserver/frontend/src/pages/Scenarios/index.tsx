import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { scenariosApi } from '../../api/scenarios'
import StatusBadge from '../../components/StatusBadge'
import Pagination from '../../components/Pagination'
import { useAuth } from '../../contexts/AuthContext'

const PAGE_SIZE = 20

export default function ScenariosPage() {
  const [page, setPage] = useState(1)
  const qc = useQueryClient()
  const { isAdmin } = useAuth()

  const { data: pageData, isLoading } = useQuery({
    queryKey: ['scenarios', page],
    queryFn: () => scenariosApi.list(page, PAGE_SIZE),
  })
  const scenarios = pageData?.items

  const deleteMutation = useMutation({
    mutationFn: (id: string) => scenariosApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['scenarios'] }),
  })

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Delete scenario "${name}"?`)) {
      deleteMutation.mutate(id)
    }
  }

  return (
    <div className="px-4 sm:px-0">
      <div className="sm:flex sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Scenarios</h1>
          <p className="mt-2 text-sm text-gray-700">
            Define agent behavior with natural language prompts
          </p>
        </div>
        {isAdmin && (
        <div className="mt-4 sm:mt-0">
          <Link
            to="/scenarios/new"
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            <svg className="-ml-1 mr-2 h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
            </svg>
            New Scenario
          </Link>
        </div>
        )}
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {isLoading ? (
          <div className="text-center py-12 text-gray-500">Loading...</div>
        ) : scenarios && scenarios.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {scenarios.map((scenario) => (
              <li key={scenario.id}>
                <div className="block hover:bg-gray-50">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <Link to={`/scenarios/${scenario.id}`} className="flex-1 min-w-0">
                        <p className="text-lg font-medium text-indigo-600 truncate">
                          {scenario.name}
                        </p>
                        {scenario.description && (
                          <p className="mt-1 text-sm text-gray-500">
                            {scenario.description.length > 150
                              ? `${scenario.description.slice(0, 150)}...`
                              : scenario.description}
                          </p>
                        )}
                      </Link>
                      <div className="ml-4 flex-shrink-0 flex items-center space-x-4">
                        <StatusBadge status={scenario.is_active ? 'active' : 'inactive'} />
                        {isAdmin && (
                          <>
                            <button
                              onClick={() => handleDelete(scenario.id, scenario.name)}
                              className="text-red-500 hover:text-red-700 text-sm"
                            >
                              Delete
                            </button>
                            <Link
                              to={`/scenarios/${scenario.id}`}
                              className="text-gray-400 hover:text-gray-600"
                            >
                              <svg className="h-5 w-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                              </svg>
                            </Link>
                          </>
                        )}
                        {!isAdmin && (
                          <Link
                            to={`/scenarios/${scenario.id}`}
                            className="text-sm text-indigo-600 hover:text-indigo-800"
                          >
                            View
                          </Link>
                        )}
                      </div>
                    </div>
                    <div className="mt-2 flex items-center text-sm text-gray-500">
                      <span>Start URL: {scenario.target_urls.start}</span>
                      <span className="mx-2">&bull;</span>
                      <span>Created {new Date(scenario.created_at).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-12">
            <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <h3 className="mt-2 text-sm font-medium text-gray-900">No scenarios</h3>
            <p className="mt-1 text-sm text-gray-500">
              {isAdmin ? 'Get started by creating a new scenario.' : 'No scenarios yet.'}
            </p>
            {isAdmin && (
            <div className="mt-6">
              <Link
                to="/scenarios/new"
                className="inline-flex items-center px-4 py-2 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700"
              >
                New Scenario
              </Link>
            </div>
            )}
          </div>
        )}
      </div>

      <Pagination
        page={page}
        limit={PAGE_SIZE}
        total={pageData?.total ?? 0}
        onChange={setPage}
      />
    </div>
  )
}
