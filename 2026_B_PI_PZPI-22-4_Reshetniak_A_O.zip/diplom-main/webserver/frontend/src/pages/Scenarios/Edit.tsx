import { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { scenariosApi } from '../../api/scenarios'
import StatusBadge from '../../components/StatusBadge'
import { useAuth } from '../../contexts/AuthContext'
import type { ScenarioCreate, ScenarioUpdate } from '../../types'

const DEFAULT_FUNNEL_CONFIG = JSON.stringify(
  { max_actions: 25, max_time_seconds: 300, min_action_delay: 1,
    max_action_delay: 5, patience_max: 0.5, patience_min: 0.5,
    purchase_intent_max: 0.5, purchase_intent_min: 0.5},
  null,
  2,
)

const DEFAULT_DEVICE_POOL = JSON.stringify(
  ['desktop', 'mobile'],
  null,
  2,
)

export default function ScenarioEdit() {
  const { id } = useParams<{ id: string }>()
  const isNew = !id
  const navigate = useNavigate()
  const qc = useQueryClient()
  const { isAdmin } = useAuth()
  const readOnly = !isNew && !isAdmin

  const [name, setName] = useState('')
  const [description, setDescription] = useState('')
  const [personaPrompt, setPersonaPrompt] = useState('')
  const [startUrl, setStartUrl] = useState('')
  const [funnelConfigStr, setFunnelConfigStr] = useState(DEFAULT_FUNNEL_CONFIG)
  const [devicePoolStr, setDevicePoolStr] = useState(DEFAULT_DEVICE_POOL)
  const [isActive, setIsActive] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const { data: scenario } = useQuery({
    queryKey: ['scenarios', id],
    queryFn: () => scenariosApi.get(id!),
    enabled: !isNew,
  })

  useEffect(() => {
    if (scenario) {
      setName(scenario.name)
      setDescription(scenario.description ?? '')
      setPersonaPrompt(scenario.persona_prompt)
      setStartUrl(scenario.target_urls.start)
      setFunnelConfigStr(JSON.stringify(scenario.funnel_config, null, 2))
      setDevicePoolStr(JSON.stringify(scenario.device_pool, null, 2))
      setIsActive(scenario.is_active)
    }
  }, [scenario])

  const createMutation = useMutation({
    mutationFn: (data: ScenarioCreate) => scenariosApi.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['scenarios'] })
      navigate('/scenarios')
    },
    onError: (e: Error) => setError(e.message),
  })

  const updateMutation = useMutation({
    mutationFn: (data: ScenarioUpdate) => scenariosApi.update(id!, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['scenarios'] })
      qc.invalidateQueries({ queryKey: ['scenarios', id] })
    },
    onError: (e: Error) => setError(e.message),
  })

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)

    let funnelConfig: Record<string, unknown>
    let devicePool: string[]

    try {
      funnelConfig = JSON.parse(funnelConfigStr) as Record<string, unknown>
    } catch {
      setError('Funnel config must be valid JSON')
      return
    }

    try {
      devicePool = JSON.parse(devicePoolStr) as string[]
    } catch {
      setError('Device pool must be valid JSON array')
      return
    }

    if (isNew) {
      createMutation.mutate({
        name,
        description: description || undefined,
        persona_prompt: personaPrompt,
        target_urls: { start: startUrl },
        funnel_config: funnelConfig,
        device_pool: devicePool,
      })
    } else {
      updateMutation.mutate({
        name,
        description: description || undefined,
        persona_prompt: personaPrompt,
        target_urls: { start: startUrl },
        funnel_config: funnelConfig,
        device_pool: devicePool,
        is_active: isActive,
      })
    }
  }

  const isPending = createMutation.isPending || updateMutation.isPending

  if (readOnly) {
    if (!scenario) {
      return (
        <div className="px-4 sm:px-0">
          <div className="text-center py-12 text-gray-500">Loading...</div>
        </div>
      )
    }
    return (
      <div className="px-4 sm:px-0">
        <div className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold text-gray-900">{scenario.name}</h1>
          <div className="flex items-center gap-4">
            <StatusBadge status={scenario.is_active ? 'active' : 'inactive'} />
            <button
              type="button"
              onClick={() => navigate('/scenarios')}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Back to list
            </button>
          </div>
        </div>
        <div className="bg-white shadow rounded-lg p-6 space-y-6">
          {scenario.description && (
            <div>
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <p className="mt-1 text-sm text-gray-900 whitespace-pre-wrap">{scenario.description}</p>
            </div>
          )}
          <div>
            <label className="block text-sm font-medium text-gray-700">Persona Prompt</label>
            <p className="mt-1 text-sm text-gray-900 whitespace-pre-wrap font-mono bg-gray-50 p-3 rounded">{scenario.persona_prompt}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Start URL</label>
            <p className="mt-1 text-sm text-gray-900">{scenario.target_urls.start}</p>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Funnel Config</label>
            <pre className="mt-1 text-sm text-gray-900 font-mono bg-gray-50 p-3 rounded overflow-auto max-h-48">
              {JSON.stringify(scenario.funnel_config, null, 2)}
            </pre>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Device Pool</label>
            <p className="mt-1 text-sm text-gray-900">{scenario.device_pool.join(', ')}</p>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="px-4 sm:px-0">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">
          {isNew ? 'New Scenario' : 'Edit Scenario'}
        </h1>
      </div>

      <div className="bg-white shadow rounded-lg p-6">
        {error && (
          <div className="mb-6 bg-red-50 border border-red-200 rounded-md p-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700">Name *</label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Persona Prompt *
            </label>
            <p className="text-xs text-gray-500 mt-1">
              Describe the agent persona and behavior in natural language.
            </p>
            <textarea
              rows={6}
              required
              value={personaPrompt}
              onChange={(e) => setPersonaPrompt(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono"
              placeholder="You are an impatient shopper looking for a deal..."
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Start URL *</label>
            <input
              type="url"
              required
              value={startUrl}
              onChange={(e) => setStartUrl(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              placeholder="http://localhost:3000/landing"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Funnel Config (JSON)
            </label>
            <textarea
              rows={6}
              value={funnelConfigStr}
              onChange={(e) => setFunnelConfigStr(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">
              Device Pool (JSON array)
            </label>
            <textarea
              rows={3}
              value={devicePoolStr}
              onChange={(e) => setDevicePoolStr(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono"
            />
          </div>

          {!isNew && (
            <div className="flex items-center">
              <input
                type="checkbox"
                id="is_active"
                checked={isActive}
                onChange={(e) => setIsActive(e.target.checked)}
                className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300 rounded"
              />
              <label htmlFor="is_active" className="ml-2 block text-sm text-gray-900">
                Active
              </label>
            </div>
          )}

          <div className="flex justify-end space-x-3">
            <button
              type="button"
              onClick={() => navigate('/scenarios')}
              className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isPending}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
            >
              {isPending ? 'Saving...' : isNew ? 'Create Scenario' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
