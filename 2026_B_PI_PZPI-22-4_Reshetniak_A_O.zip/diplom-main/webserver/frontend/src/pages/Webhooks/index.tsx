import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { webhooksApi } from '../../api/webhooks'
import { scenariosApi } from '../../api/scenarios'
import StatusBadge from '../../components/StatusBadge'
import { useAuth } from '../../contexts/AuthContext'
import type { Webhook, WebhookCreate, WebhookUpdate } from '../../types'

const EVENT_TYPE_OPTIONS = ['page_view', 'click', 'form_submit', 'form_field_focus', 'add_to_cart', 'checkout_initiated', 'purchase_completed', 'purchase_success']

export default function WebhooksPage() {
  const qc = useQueryClient()
  const { isAdmin } = useAuth()
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [name, setName] = useState('')
  const [url, setUrl] = useState('')
  const [secret, setSecret] = useState('')
  const [eventFilter, setEventFilter] = useState<string[]>([])
  const [scenarioFilter, setScenarioFilter] = useState<string[]>([])
  const [isActive, setIsActive] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [testResults, setTestResults] = useState<Record<string, { success: boolean; status_code: number | null; error_message: string | null }>>({})

  const { data: webhooks, isLoading } = useQuery({
    queryKey: ['webhooks'],
    queryFn: webhooksApi.list,
  })

  const { data: scenariosPage, isLoading: scenariosLoading } = useQuery({
    queryKey: ['scenarios', 'list', 1, 100],
    queryFn: () => scenariosApi.list(1, 100),
  })
  const scenarios = scenariosPage?.items ?? []

  const createMutation = useMutation({
    mutationFn: (data: WebhookCreate) => webhooksApi.create(data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['webhooks'] })
      setShowForm(false)
      resetForm()
    },
    onError: (e: Error) => setError(e.message),
  })

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: WebhookUpdate }) => webhooksApi.update(id, data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['webhooks'] })
      setShowForm(false)
      setEditingId(null)
      resetForm()
    },
    onError: (e: Error) => setError(e.message),
  })

  const toggleActiveMutation = useMutation({
    mutationFn: ({ id, isActive }: { id: string; isActive: boolean }) =>
      webhooksApi.update(id, { is_active: isActive }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['webhooks'] }),
  })

  const deleteMutation = useMutation({
    mutationFn: (id: string) => webhooksApi.delete(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['webhooks'] }),
  })

  const testMutation = useMutation({
    mutationFn: (id: string) => webhooksApi.test(id),
    onSuccess: (result, id) => {
      setTestResults((prev) => ({ ...prev, [id]: result }))
    },
  })

  const resetForm = () => {
    setName('')
    setUrl('')
    setSecret('')
    setEventFilter([])
    setScenarioFilter([])
    setIsActive(true)
    setError(null)
  }

  const startEdit = (w: Webhook) => {
    setEditingId(w.id)
    setName(w.name)
    setUrl(w.url)
    setSecret(w.secret ?? '')
    setEventFilter(w.event_filter ?? [])
    setScenarioFilter(w.scenario_filter ?? [])
    setIsActive(w.is_active)
    setError(null)
    setShowForm(true)
    window.scrollTo({ top: 0, behavior: 'smooth' })
  }

  const closeForm = () => {
    setShowForm(false)
    setEditingId(null)
    resetForm()
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setError(null)
    if (editingId) {
      updateMutation.mutate({
        id: editingId,
        data: {
          name,
          url,
          secret: secret || null,
          event_filter: eventFilter,
          scenario_filter: scenarioFilter,
          is_active: isActive,
        },
      })
    } else {
      createMutation.mutate({
        name,
        url,
        secret: secret || undefined,
        event_filter: eventFilter,
        scenario_filter: scenarioFilter.length > 0 ? scenarioFilter : undefined,
      })
    }
  }

  const toggleEventType = (type: string) => {
    setEventFilter((prev) =>
      prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type],
    )
  }

  const toggleScenario = (id: string) => {
    setScenarioFilter((prev) =>
      prev.includes(id) ? prev.filter((s) => s !== id) : [...prev, id],
    )
  }

  return (
    <div className="px-4 sm:px-0">
      <div className="sm:flex sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Webhooks</h1>
          <p className="mt-2 text-sm text-gray-700">Receive real-time event notifications</p>
        </div>
        <button
          onClick={() => { if (showForm) { closeForm() } else { resetForm(); setEditingId(null); setShowForm(true) } }}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
        >
          {showForm ? 'Cancel' : 'Add Webhook'}
        </button>
      </div>

      {/* Create Form */}
      {showForm && (
        <div className="bg-white shadow rounded-lg p-6 mb-8">
          <h2 className="text-lg font-medium text-gray-900 mb-4">
            {editingId ? 'Edit Webhook' : 'New Webhook'}
          </h2>

          {error && (
            <div className="mb-4 bg-red-50 border border-red-200 rounded-md p-4">
              <p className="text-sm text-red-700">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label className="block text-sm font-medium text-gray-700">Name *</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">URL *</label>
                <input
                  type="url"
                  required
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
                  placeholder="https://example.com/webhook"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">
                Secret (optional, for HMAC signing)
              </label>
              <input
                type="text"
                value={secret}
                onChange={(e) => setSecret(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Event Filter (empty = all events)
              </label>
              <div className="flex flex-wrap gap-2">
                {EVENT_TYPE_OPTIONS.map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => toggleEventType(type)}
                    className={`px-3 py-1 rounded-full text-sm font-medium border transition-colors ${
                      eventFilter.includes(type)
                        ? 'bg-indigo-600 text-white border-indigo-600'
                        : 'bg-white text-gray-700 border-gray-300 hover:border-indigo-400'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Scenarios (empty = all scenarios)
              </label>
              {scenariosLoading ? (
                <p className="text-sm text-gray-500">Loading scenarios...</p>
              ) : scenarios.length === 0 ? (
                <p className="text-sm text-gray-500">
                  {isAdmin
                    ? <>No scenarios yet. <Link to="/scenarios/new" className="text-indigo-600 hover:underline">Create a scenario</Link> first, then you can restrict the webhook to specific scenarios.</>
                    : 'No scenarios yet. You can leave the filter empty to receive all events.'}
                </p>
              ) : (
                <div className="flex flex-wrap gap-2">
                  {scenarios.map((s) => (
                    <button
                      key={s.id}
                      type="button"
                      onClick={() => toggleScenario(s.id)}
                      className={`px-3 py-1 rounded-full text-sm font-medium border transition-colors ${
                        scenarioFilter.includes(s.id)
                          ? 'bg-indigo-600 text-white border-indigo-600'
                          : 'bg-white text-gray-700 border-gray-300 hover:border-indigo-400'
                      }`}
                    >
                      {s.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {editingId && (
              <div>
                <label className="inline-flex items-center gap-2 text-sm font-medium text-gray-700">
                  <input
                    type="checkbox"
                    checked={isActive}
                    onChange={(e) => setIsActive(e.target.checked)}
                    className="h-4 w-4 text-indigo-600 border-gray-300 rounded focus:ring-indigo-500"
                  />
                  Active — events are dispatched to this webhook
                </label>
              </div>
            )}

            <div className="flex justify-end gap-3">
              <button
                type="button"
                onClick={closeForm}
                className="px-4 py-2 border border-gray-300 bg-white rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={createMutation.isPending || updateMutation.isPending}
                className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
              >
                {editingId
                  ? updateMutation.isPending ? 'Saving...' : 'Save Changes'
                  : createMutation.isPending ? 'Creating...' : 'Create Webhook'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Webhooks List */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {isLoading ? (
          <div className="text-center py-12 text-gray-500">Loading...</div>
        ) : webhooks && webhooks.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {webhooks.map((webhook) => (
              <li key={webhook.id} className="px-6 py-4">
                <div className="flex items-center justify-between">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <p className="text-sm font-medium text-gray-900">{webhook.name}</p>
                      {isAdmin && webhook.owner_name && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-600">
                          Owner: {webhook.owner_name}
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-500 truncate">{webhook.url}</p>
                    {webhook.event_filter.length > 0 && (
                      <div className="mt-1 flex flex-wrap gap-1">
                        {webhook.event_filter.map((t) => (
                          <span key={t} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-gray-100 text-gray-700">
                            {t}
                          </span>
                        ))}
                      </div>
                    )}
                    <div className="mt-1 text-xs text-gray-500">
                      {!webhook.scenario_filter || webhook.scenario_filter.length === 0
                        ? 'Scenarios: all'
                        : scenarios.length > 0
                          ? `Scenarios: ${webhook.scenario_filter.map((id) => scenarios.find((s) => s.id === id)?.name ?? id).join(', ')}`
                          : `Scenarios: ${webhook.scenario_filter.length} selected`}
                    </div>
                  </div>
                  <div className="ml-4 flex items-center space-x-3">
                    <StatusBadge status={webhook.is_active ? 'active' : 'inactive'} />
                    <button
                      onClick={() =>
                        toggleActiveMutation.mutate({ id: webhook.id, isActive: !webhook.is_active })
                      }
                      disabled={toggleActiveMutation.isPending}
                      className={`text-sm ${
                        webhook.is_active
                          ? 'text-amber-600 hover:text-amber-800'
                          : 'text-green-600 hover:text-green-800'
                      }`}
                    >
                      {webhook.is_active ? 'Deactivate' : 'Activate'}
                    </button>
                    <button
                      onClick={() => startEdit(webhook)}
                      className="text-sm text-indigo-600 hover:text-indigo-800"
                    >
                      Edit
                    </button>
                    <button
                      onClick={() => testMutation.mutate(webhook.id)}
                      disabled={testMutation.isPending}
                      className="text-sm text-indigo-600 hover:text-indigo-800"
                    >
                      Test
                    </button>
                    <button
                      onClick={() => {
                        if (confirm(`Delete webhook "${webhook.name}"?`)) {
                          deleteMutation.mutate(webhook.id)
                        }
                      }}
                      className="text-sm text-red-600 hover:text-red-800"
                    >
                      Delete
                    </button>
                  </div>
                </div>

                {testResults[webhook.id] && (
                  <div className={`mt-2 p-2 rounded text-xs ${testResults[webhook.id].success ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'}`}>
                    {testResults[webhook.id].success
                      ? `Success (HTTP ${testResults[webhook.id].status_code})`
                      : `Failed: ${testResults[webhook.id].error_message}`}
                  </div>
                )}
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-center py-12">
            <h3 className="text-sm font-medium text-gray-900">No webhooks</h3>
            <p className="mt-1 text-sm text-gray-500">Add a webhook to receive event notifications.</p>
          </div>
        )}
      </div>
    </div>
  )
}
