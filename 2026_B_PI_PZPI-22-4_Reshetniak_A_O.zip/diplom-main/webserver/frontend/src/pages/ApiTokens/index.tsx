import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { apiTokensApi } from '../../api/apiTokens'
import { usersApi } from '../../api/users'
import { useAuth } from '../../contexts/AuthContext'

export default function ApiTokensPage() {
  const qc = useQueryClient()
  const { isAdmin } = useAuth()
  const [name, setName] = useState('')
  const [expiresAt, setExpiresAt] = useState('')
  const [forUserId, setForUserId] = useState('')
  const [newToken, setNewToken] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  const { data: tokens, isLoading } = useQuery({
    queryKey: ['api-tokens'],
    queryFn: apiTokensApi.list,
  })

  const { data: usersList } = useQuery({
    queryKey: ['users', 'list'],
    queryFn: usersApi.list,
    enabled: isAdmin,
  })

  const createMutation = useMutation({
    mutationFn: () =>
      apiTokensApi.create({
        name: name.trim() || undefined,
        expires_at: expiresAt ? new Date(expiresAt).toISOString() : undefined,
        user_id: isAdmin && forUserId ? forUserId : undefined,
      }),
    onSuccess: (data) => {
      setNewToken(data.token)
      setName('')
      setExpiresAt('')
      setForUserId('')
      setError(null)
      qc.invalidateQueries({ queryKey: ['api-tokens'] })
    },
    onError: (e: Error) => setError(e.message),
  })

  const revokeMutation = useMutation({
    mutationFn: (id: string) => apiTokensApi.revoke(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['api-tokens'] }),
  })

  return (
    <div className="px-4 sm:px-0">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">API tokens</h1>
        <p className="mt-2 text-sm text-gray-600">
          Use <code className="bg-gray-100 px-1 rounded">Authorization: Bearer &lt;token&gt;</code> instead of a session JWT.
          The token inherits your user&apos;s role (admin / user) for all endpoints.
        </p>
      </div>

      {newToken && (
        <div className="mb-8 bg-amber-50 border border-amber-200 rounded-lg p-4">
          <p className="text-sm font-medium text-amber-900">Save this token now — it won&apos;t be shown again.</p>
          <div className="mt-2 flex gap-2 items-center flex-wrap">
            <code className="text-xs break-all bg-white border rounded px-2 py-1 flex-1 min-w-0">{newToken}</code>
            <button
              type="button"
              onClick={() => {
                void navigator.clipboard.writeText(newToken)
              }}
              className="px-3 py-1 text-sm bg-amber-600 text-white rounded hover:bg-amber-700"
            >
              Copy
            </button>
            <button
              type="button"
              onClick={() => setNewToken(null)}
              className="text-sm text-amber-800 hover:underline"
            >
              Dismiss
            </button>
          </div>
        </div>
      )}

      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Create token</h2>
        {error && (
          <div className="mb-4 text-sm text-red-700 bg-red-50 border border-red-200 rounded p-3">{error}</div>
        )}
        <div className="grid gap-4 sm:grid-cols-2 max-w-2xl">
          <div>
            <label className="block text-sm font-medium text-gray-700">Label (optional)</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
              placeholder="e.g. CI, mobile app"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Expires (optional)</label>
            <input
              type="datetime-local"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
            />
          </div>
          {isAdmin && usersList && usersList.length > 0 && (
            <div className="sm:col-span-2">
              <label className="block text-sm font-medium text-gray-700">Owner (admin)</label>
              <select
                value={forUserId}
                onChange={(e) => setForUserId(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md py-2 px-3 text-sm"
              >
                <option value="">Yourself (current user)</option>
                {usersList.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>
        <button
          type="button"
          disabled={createMutation.isPending}
          onClick={() => createMutation.mutate()}
          className="mt-4 px-4 py-2 bg-indigo-600 text-white text-sm font-medium rounded-md hover:bg-indigo-700 disabled:opacity-50"
        >
          {createMutation.isPending ? 'Creating…' : 'Create token'}
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Active tokens</h2>
        </div>
        {isLoading ? (
          <div className="py-12 text-center text-gray-500">Loading…</div>
        ) : tokens && tokens.length > 0 ? (
          <ul className="divide-y divide-gray-200">
            {tokens.map((t) => (
              <li key={t.id} className="px-6 py-4 flex flex-wrap items-center justify-between gap-4">
                <div className="min-w-0">
                  <p className="text-sm font-medium text-gray-900">{t.name || '—'}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    id: {t.id.slice(0, 8)}… · created {new Date(t.created_at).toLocaleString()}
                    {t.expires_at && ` · expires ${new Date(t.expires_at).toLocaleString()}`}
                  </p>
                  {isAdmin && t.owner_name && (
                    <p className="text-xs text-indigo-600 mt-1">Owner: {t.owner_name}</p>
                  )}
                </div>
                <button
                  type="button"
                  onClick={() => {
                    if (confirm('Revoke this token? Clients using it will get 401.')) {
                      revokeMutation.mutate(t.id)
                    }
                  }}
                  className="text-sm text-red-600 hover:text-red-800"
                >
                  Revoke
                </button>
              </li>
            ))}
          </ul>
        ) : (
          <div className="py-12 text-center text-gray-500">No tokens yet.</div>
        )}
      </div>
    </div>
  )
}
