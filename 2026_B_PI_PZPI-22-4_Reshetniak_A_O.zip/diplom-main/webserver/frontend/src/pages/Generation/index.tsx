import { useState } from 'react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'
import { scenariosApi } from '../../api/scenarios'
import { generationApi } from '../../api/generation'
import { sessionsApi } from '../../api/sessions'
import StatusBadge from '../../components/StatusBadge'
import type { Session } from '../../types'

function SessionRow({ session }: { session: Session }) {
  const duration =
    session.started_at && session.finished_at
      ? ((new Date(session.finished_at).getTime() - new Date(session.started_at).getTime()) / 1000)
      : null

  const avgPerEvent =
    duration && session.total_events > 0
      ? (duration / session.total_events).toFixed(1)
      : null

  return (
    <tr className="text-xs">
      <td className="px-3 py-1.5 font-mono text-gray-700">{session.id.slice(0, 8)}</td>
      <td className="px-3 py-1.5">
        <StatusBadge status={session.status} />
      </td>
      <td className="px-3 py-1.5 text-gray-700">{String(session.user_profile?.name ?? '—')}</td>
      <td className="px-3 py-1.5 text-right text-gray-700">{session.total_events}</td>
      <td className="px-3 py-1.5 text-right text-gray-700">{session.total_actions}</td>
      <td className="px-3 py-1.5 text-right text-gray-500">
        {avgPerEvent ? `${avgPerEvent}s` : '—'}
      </td>
      <td className="px-3 py-1.5 text-gray-500">
        {duration != null ? `${Math.round(duration)}s` : session.status === 'running' ? 'running...' : '—'}
      </td>
      <td className="px-3 py-1.5 text-gray-500 truncate max-w-[150px]">
        {session.result ?? session.error_message ?? '—'}
      </td>
    </tr>
  )
}

function JobSessions({ jobId, isRunning }: { jobId: string; isRunning: boolean }) {
  const { data, isLoading } = useQuery({
    queryKey: ['sessions', 'job', jobId],
    queryFn: () => sessionsApi.listByJob(jobId),
    refetchInterval: isRunning ? 5_000 : false,
  })
  const sessions = data?.items ?? []

  if (isLoading) return <div className="px-3 py-4 text-xs text-gray-500">Loading sessions...</div>
  if (sessions.length === 0) return <div className="px-3 py-4 text-xs text-gray-500">No sessions yet</div>

  return (
    <div className="overflow-x-auto">
      <table className="min-w-full divide-y divide-gray-100 text-xs">
        <thead className="bg-gray-50">
          <tr>
            <th className="px-3 py-1.5 text-left font-medium text-gray-500">Session</th>
            <th className="px-3 py-1.5 text-left font-medium text-gray-500">Status</th>
            <th className="px-3 py-1.5 text-left font-medium text-gray-500">Profile</th>
            <th className="px-3 py-1.5 text-right font-medium text-gray-500">Events</th>
            <th className="px-3 py-1.5 text-right font-medium text-gray-500">Actions</th>
            <th className="px-3 py-1.5 text-right font-medium text-gray-500">Avg/event</th>
            <th className="px-3 py-1.5 text-left font-medium text-gray-500">Duration</th>
            <th className="px-3 py-1.5 text-left font-medium text-gray-500">Result</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-50">
          {sessions.map((s) => (
            <SessionRow key={s.id} session={s} />
          ))}
        </tbody>
      </table>
    </div>
  )
}

export default function GenerationPage() {
  const qc = useQueryClient()
  const [expandedJobs, setExpandedJobs] = useState<Set<string>>(new Set())
  const [scenarioId, setScenarioId] = useState('')
  const [numSessions, setNumSessions] = useState(1)
  const [scheduleCron, setScheduleCron] = useState('')
  const [error, setError] = useState<string | null>(null)
  const [successJobId, setSuccessJobId] = useState<string | null>(null)

  const { data: scenariosPage } = useQuery({
    queryKey: ['scenarios', 'active'],
    queryFn: () => scenariosApi.list(1, 100),
  })
  const scenarios = scenariosPage?.items

  const { data: jobsPage, isLoading: jobsLoading } = useQuery({
    queryKey: ['jobs'],
    queryFn: () => generationApi.listJobs(1, 20),
    refetchInterval: 5_000,
  })
  const jobs = jobsPage?.items

  const generateMutation = useMutation({
    mutationFn: () =>
      generationApi.generate({
        scenario_id: scenarioId,
        num_sessions: numSessions,
        schedule_cron: scheduleCron.trim() || undefined,
      }),
    onSuccess: (job) => {
      setSuccessJobId(job.id)
      setError(null)
      qc.invalidateQueries({ queryKey: ['jobs'] })
    },
    onError: (e: Error) => {
      setError(e.message)
      setSuccessJobId(null)
    },
  })

  const cancelMutation = useMutation({
    mutationFn: (id: string) => generationApi.cancelJob(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['jobs'] }),
  })

  const toggleExpand = (id: string) =>
    setExpandedJobs((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })

  const activeScenarios = scenarios?.filter((s) => s.is_active) ?? []

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (!scenarioId) {
      setError('Please select a scenario')
      return
    }
    setError(null)
    generateMutation.mutate()
  }

  const progressPercent = (job: { completed_sessions: number; failed_sessions: number; total_sessions: number }) => {
    const done = job.completed_sessions + job.failed_sessions
    return job.total_sessions > 0 ? Math.round((done / job.total_sessions) * 100) : 0
  }

  return (
    <div className="px-4 sm:px-0">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Traffic Generation</h1>

      {/* Launch Form */}
      <div className="bg-white shadow rounded-lg p-6 mb-8">
        <h2 className="text-lg font-medium text-gray-900 mb-4">Launch Generation Job</h2>

        {error && (
          <div className="mb-4 bg-red-50 border border-red-200 rounded-md p-4">
            <p className="text-sm text-red-700">{error}</p>
          </div>
        )}

        {successJobId && (
          <div className="mb-4 bg-green-50 border border-green-200 rounded-md p-4">
            <p className="text-sm text-green-700">Job <code>{successJobId.slice(0, 8)}</code> created successfully.</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Scenario *</label>
            {activeScenarios.length === 0 ? (
              <p className="mt-1 text-sm text-gray-500">
                No active scenarios. <a href="/scenarios/new" className="text-indigo-600 hover:underline">Create one first.</a>
              </p>
            ) : (
              <select
                required
                value={scenarioId}
                onChange={(e) => setScenarioId(e.target.value)}
                className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
              >
                <option value="">Select a scenario...</option>
                {activeScenarios.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Number of Sessions *</label>
            <input
              type="number"
              required
              min={1}
              max={10000}
              value={numSessions}
              onChange={(e) => setNumSessions(Number(e.target.value))}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700">Schedule (cron)</label>
            <input
              type="text"
              placeholder="Leave empty to run now. Example: 0 9 * * * = daily at 09:00"
              value={scheduleCron}
              onChange={(e) => setScheduleCron(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm font-mono"
            />
            <p className="mt-1 text-xs text-gray-500">
              Format: minute hour day month weekday. Job will start at the first matching time (scheduler checks every minute).
            </p>
          </div>

          <div className="flex justify-end">
            <button
              type="submit"
              disabled={generateMutation.isPending || activeScenarios.length === 0}
              className="px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50"
            >
              {generateMutation.isPending ? 'Launching...' : 'Launch Job'}
            </button>
          </div>
        </form>
      </div>

      {/* Jobs List */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-6 py-5 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">Recent Jobs</h2>
        </div>

        {jobsLoading ? (
          <div className="px-6 py-8 text-center text-gray-500">Loading...</div>
        ) : jobs && jobs.length > 0 ? (
          <div className="divide-y divide-gray-200">
            {jobs.map((job) => {
              const expanded = expandedJobs.has(job.id)
              const isRunning = job.status === 'running' || job.status === 'pending'
              return (
                <div key={job.id}>
                  <div className="px-6 py-4">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center">
                        <button
                          onClick={() => toggleExpand(job.id)}
                          className="mr-2 text-gray-400 hover:text-gray-600 text-xs w-4"
                          title={expanded ? 'Collapse' : 'Expand sessions'}
                        >
                          {expanded ? '\u25BC' : '\u25B6'}
                        </button>
                        <button
                          onClick={() => toggleExpand(job.id)}
                          className="text-sm font-medium text-gray-900 hover:text-indigo-600"
                        >
                          Job {job.id.slice(0, 8)}
                        </button>
                        {job.scenario_name && (
                          <span className="ml-2 text-sm text-gray-600">
                            — {job.scenario_name}
                          </span>
                        )}
                        <span className="ml-3 text-sm text-gray-500">
                          {job.completed_sessions}/{job.total_sessions} sessions
                          {job.failed_sessions > 0 && (
                            <span className="text-red-500 ml-1">({job.failed_sessions} failed)</span>
                          )}
                        </span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <StatusBadge status={job.status} />
                        {isRunning && (
                          <button
                            onClick={() => cancelMutation.mutate(job.id)}
                            disabled={cancelMutation.isPending}
                            className="text-sm text-red-600 hover:text-red-800"
                            title={job.status === 'pending' ? 'Cancel scheduled job' : 'Cancel running job'}
                          >
                            {job.status === 'pending' ? 'Delete schedule' : 'Cancel'}
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Progress bar */}
                    {(job.status === 'running' || job.status === 'completed') && (
                      <div className="w-full bg-gray-200 rounded-full h-1.5">
                        <div
                          className="bg-indigo-600 h-1.5 rounded-full transition-all"
                          style={{ width: `${progressPercent(job)}%` }}
                        />
                      </div>
                    )}

                    <div className="mt-1 text-xs text-gray-400">
                      Created {new Date(job.created_at).toLocaleString()}
                      {job.schedule_cron && job.status === 'pending' && (
                        <span className="ml-2 text-amber-600">scheduled: {job.schedule_cron}</span>
                      )}
                    </div>
                  </div>

                  {/* Expanded sessions panel */}
                  {expanded && (
                    <div className="bg-gray-50 border-t border-b border-gray-100 px-6 py-2">
                      <JobSessions jobId={job.id} isRunning={isRunning} />
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        ) : (
          <div className="px-6 py-8 text-center text-gray-500">
            No jobs yet. Launch your first generation job above.
          </div>
        )}
      </div>
    </div>
  )
}
