import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { eventsApi } from '../../api/events'

const EVENT_TYPES = [
  'page_view',
  'click',
  'form_submit',
  'form_field_focus',
  'add_to_cart',
  'checkout_initiated',
  'purchase_completed',
  'purchase_success',
]

export default function EventsPage() {
  const [eventType, setEventType] = useState('')
  const [sessionId, setSessionId] = useState('')
  const [visitorId, setVisitorId] = useState('')
  const [limit, setLimit] = useState(100)

  const { data: eventsPage, isLoading, refetch } = useQuery({
    queryKey: ['events', { eventType, sessionId, visitorId, limit }],
    queryFn: () =>
      eventsApi.list({
        event_type: eventType || undefined,
        session_id: sessionId || undefined,
        visitor_id: visitorId || undefined,
        limit,
      }),
  })
  const events = eventsPage?.items

  const handleExportCSV = () => {
    const params = new URLSearchParams()
    if (eventType) params.set('event_type', eventType)
    if (sessionId) params.set('session_id', sessionId)
    if (visitorId) params.set('visitor_id', visitorId)
    params.set('limit', String(limit))
    params.set('format', 'csv')
    const token = localStorage.getItem('stg_access_token')
    if (token) params.set('token', token)
    window.open(`/api/v1/events?${params}`, '_blank')
  }

  return (
    <div className="px-4 sm:px-0">
      <div className="sm:flex sm:items-center sm:justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Events Explorer</h1>
          <p className="mt-2 text-sm text-gray-700">Browse and filter collected events</p>
        </div>
        <button
          onClick={handleExportCSV}
          className="mt-4 sm:mt-0 inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
        >
          Export CSV
        </button>
      </div>

      {/* Filters */}
      <div className="bg-white shadow rounded-lg p-4 mb-6">
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Event Type</label>
            <select
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              <option value="">All types</option>
              {EVENT_TYPES.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Session ID</label>
            <input
              type="text"
              value={sessionId}
              onChange={(e) => setSessionId(e.target.value)}
              placeholder="Session ID..."
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Visitor ID</label>
            <input
              type="text"
              value={visitorId}
              onChange={(e) => setVisitorId(e.target.value)}
              placeholder="Visitor ID..."
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Limit</label>
            <select
              value={limit}
              onChange={(e) => setLimit(Number(e.target.value))}
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 sm:text-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500"
            >
              {[50, 100, 500, 1000].map((n) => (
                <option key={n} value={n}>{n}</option>
              ))}
            </select>
          </div>
        </div>
        <div className="mt-3 flex justify-end">
          <button
            onClick={() => refetch()}
            className="px-3 py-1.5 border border-transparent rounded-md text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700"
          >
            Refresh
          </button>
        </div>
      </div>

      {/* Events Table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        {isLoading ? (
          <div className="text-center py-12 text-gray-500">Loading...</div>
        ) : events && events.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Timestamp</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Visitor</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Session</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Page URL</th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Device</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {events.map((event) => (
                  <tr key={event.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-gray-500">
                      {new Date(event.collector_tstamp).toLocaleString()}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-indigo-100 text-indigo-800">
                        {event.event_type}
                      </span>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-gray-500 font-mono">
                      <button
                        title={`Click to filter by ${event.visitor_id}`}
                        onClick={() => setVisitorId(event.visitor_id)}
                        className="hover:text-indigo-600 hover:underline cursor-pointer"
                      >
                        {event.visitor_id.slice(0, 8)}
                      </button>
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-gray-500 font-mono">
                      {event.session_id ? (
                        <button
                          title={`Click to filter by ${event.session_id}`}
                          onClick={() => setSessionId(event.session_id!)}
                          className="hover:text-indigo-600 hover:underline cursor-pointer"
                        >
                          {event.session_id.slice(0, 8)}
                        </button>
                      ) : '—'}
                    </td>
                    <td className="px-4 py-3 text-xs text-gray-500 max-w-xs truncate">
                      {event.page_url}
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-xs text-gray-500">
                      {event.device_type ?? '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="text-center py-12 text-gray-500">
            No events found. Generate some traffic first.
          </div>
        )}
      </div>

      {events && (
        <p className="mt-3 text-sm text-gray-500 text-right">{events.length} events</p>
      )}
    </div>
  )
}
