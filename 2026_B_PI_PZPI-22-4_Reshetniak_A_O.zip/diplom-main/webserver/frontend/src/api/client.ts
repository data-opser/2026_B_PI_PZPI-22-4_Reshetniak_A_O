import { getToken, clearToken } from '../auth'

const BASE_URL = '/api/v1'

class ApiError extends Error {
  constructor(public status: number, message: string) {
    super(message)
    this.name = 'ApiError'
  }
}

async function parseErrorMessage(res: Response): Promise<string> {
  const text = await res.text().catch(() => '')
  if (!text) return res.statusText
  try {
    const data = JSON.parse(text)
    if (typeof data?.detail === 'string') return data.detail
    if (Array.isArray(data?.detail)) {
      return data.detail.map((d: { msg?: string }) => d?.msg || '').filter(Boolean).join(', ') || text
    }
    return text
  } catch {
    return text
  }
}

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options?.headers as Record<string, string>),
  }
  const token = getToken()
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    ...options,
    headers,
  })

  // For the login endpoint, surface the server's error message instead of
  // redirecting — otherwise the user never sees why login failed.
  const isLoginCall = path === '/auth/login'

  if (res.status === 401) {
    const message = await parseErrorMessage(res)
    if (!isLoginCall) {
      clearToken()
      window.location.href = '/login'
    }
    throw new ApiError(401, message)
  }

  if (res.status === 403) {
    const message = await parseErrorMessage(res)
    if (!isLoginCall) {
      window.location.href = '/'
    }
    throw new ApiError(403, message)
  }

  if (!res.ok) {
    const message = await parseErrorMessage(res)
    throw new ApiError(res.status, message)
  }

  if (res.status === 204) return undefined as T
  return res.json()
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'POST', body: body ? JSON.stringify(body) : undefined }),
  put: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PUT', body: body ? JSON.stringify(body) : undefined }),
  patch: <T>(path: string, body?: unknown) =>
    request<T>(path, { method: 'PATCH', body: body ? JSON.stringify(body) : undefined }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),
}
