import { api } from './client'
import type { GenerationJob, GenerationRequest, JobStatus } from '../types'

export interface JobsPage {
  items: GenerationJob[]
  total: number
  page: number
}

export const generationApi = {
  generate: (data: GenerationRequest) =>
    api.post<GenerationJob>('/generate', data),

  listJobs: (page = 1, limit = 20) =>
    api.get<JobsPage>(`/jobs?page=${page}&limit=${limit}`),

  // GET /jobs/{id} returns JobStatus (with progress details)
  getJobStatus: (id: string) => api.get<JobStatus>(`/jobs/${id}`),

  cancelJob: (id: string) => api.post<GenerationJob>(`/jobs/${id}/cancel`),
}
