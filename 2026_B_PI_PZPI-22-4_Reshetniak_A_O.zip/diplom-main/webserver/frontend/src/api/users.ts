import { api } from './client'

export interface UserListItem {
  id: string
  name: string
  role: string
  is_active: boolean
}

export interface UserCreateRequest {
  name: string
  password: string
  role: string
}

export const usersApi = {
  list: () => api.get<UserListItem[]>('/users'),
  create: (data: UserCreateRequest) => api.post<UserListItem>('/users', data),
  changePassword: (userId: string, password: string) =>
    api.patch<{ detail: string }>(`/users/${userId}/password`, { password }),
  setActive: (userId: string, isActive: boolean) =>
    api.patch<UserListItem>(`/users/${userId}/active`, { is_active: isActive }),
  delete: (userId: string) => api.delete<void>(`/users/${userId}`),
}
