import { api } from './client'
import type { DashboardStats, FunnelStats, ThroughputStats, WebhookDeliveryStats } from '../types'

export type WebhookDeliveryFilters = {
  owner_user_id?: string
  endpoint_id?: string
  event_type?: string
  from?: string
  to?: string
  success_only?: boolean
}

function buildQuery(f: WebhookDeliveryFilters): string {
  const p = new URLSearchParams()
  if (f.owner_user_id) p.set('owner_user_id', f.owner_user_id)
  if (f.endpoint_id) p.set('endpoint_id', f.endpoint_id)
  if (f.event_type) p.set('event_type', f.event_type)
  if (f.from) p.set('from', f.from)
  if (f.to) p.set('to', f.to)
  if (f.success_only === true) p.set('success_only', 'true')
  if (f.success_only === false) p.set('success_only', 'false')
  const q = p.toString()
  return q ? `?${q}` : ''
}

export const statsApi = {
  dashboard: () => api.get<DashboardStats>('/stats/dashboard'),
  funnel: () => api.get<FunnelStats>('/stats/funnel'),
  throughput: () => api.get<ThroughputStats>('/stats/throughput'),
  webhookDeliveries: (filters: WebhookDeliveryFilters = {}) =>
    api.get<WebhookDeliveryStats>(`/stats/webhook-deliveries${buildQuery(filters)}`),
}
