import { api } from './client'

export interface ApiToken {
  id: string
  user_id: string
  owner_name?: string | null
  name: string | null
  expires_at: string | null
  created_at: string
}

export interface ApiTokenCreated extends ApiToken {
  token: string
}

export interface ApiTokenCreateBody {
  name?: string
  expires_at?: string | null
  user_id?: string
}

export const apiTokensApi = {
  list: () => api.get<ApiToken[]>('/api-tokens'),
  create: (body: ApiTokenCreateBody) => api.post<ApiTokenCreated>('/api-tokens', body),
  revoke: (id: string) => api.delete<void>(`/api-tokens/${id}`),
}
