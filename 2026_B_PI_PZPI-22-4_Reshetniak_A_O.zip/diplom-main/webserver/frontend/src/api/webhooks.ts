import { api } from './client'
import type { Webhook, WebhookCreate, WebhookUpdate, WebhookLog } from '../types'

export const webhooksApi = {
  list: () => api.get<Webhook[]>('/webhooks'),

  create: (data: WebhookCreate) => api.post<Webhook>('/webhooks', data),

  update: (id: string, data: WebhookUpdate) => api.put<Webhook>(`/webhooks/${id}`, data),

  delete: (id: string) => api.delete<void>(`/webhooks/${id}`),

  test: (id: string) => api.post<{ success: boolean; status_code: number | null; error_message: string | null }>(`/webhooks/${id}/test`),

  getLogs: (id: string) => api.get<WebhookLog[]>(`/webhooks/${id}/logs`),
}
