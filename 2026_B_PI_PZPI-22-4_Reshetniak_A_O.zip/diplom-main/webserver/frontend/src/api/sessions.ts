import { api } from './client'
import type { Session } from '../types'

export interface SessionsPage {
  items: Session[]
  total: number
  page: number
}

export const sessionsApi = {
  list: (page = 1, limit = 20) =>
    api.get<SessionsPage>(`/sessions?page=${page}&limit=${limit}`),

  listByJob: (jobId: string, limit = 100) =>
    api.get<SessionsPage>(`/sessions?job_id=${jobId}&limit=${limit}`),

  get: (id: string) => api.get<Session>(`/sessions/${id}`),
}
