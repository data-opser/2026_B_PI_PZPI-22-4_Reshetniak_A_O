import { api } from './client'

export interface LoginResponse {
  access_token: string
  token_type: string
}

export interface CurrentUser {
  id: string
  name: string
  role: string
  is_active: boolean
  created_at: string
}

export const authApi = {
  login: (name: string, password: string) =>
    api.post<LoginResponse>('/auth/login', { name, password }),
  me: () => api.get<CurrentUser>('/auth/me'),
}
