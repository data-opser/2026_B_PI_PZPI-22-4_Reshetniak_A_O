import { api } from './client'
import type { Scenario, ScenarioCreate, ScenarioUpdate } from '../types'

export interface ScenariosPage {
  items: Scenario[]
  total: number
  page: number
}

export const scenariosApi = {
  list: (page = 1, limit = 20) =>
    api.get<ScenariosPage>(`/scenarios?page=${page}&limit=${limit}`),

  get: (id: string) => api.get<Scenario>(`/scenarios/${id}`),

  create: (data: ScenarioCreate) => api.post<Scenario>('/scenarios', data),

  update: (id: string, data: ScenarioUpdate) =>
    api.put<Scenario>(`/scenarios/${id}`, data),

  delete: (id: string) => api.delete<void>(`/scenarios/${id}?hard=true`),
}
