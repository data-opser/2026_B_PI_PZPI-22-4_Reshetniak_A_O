import { api } from './client'
import type { Event } from '../types'

export interface EventFilters {
  event_type?: string
  session_id?: string
  visitor_id?: string
  limit?: number
}

export interface EventsPage {
  items: Event[]
  next_cursor: string | null
  limit: number
}

export const eventsApi = {
  list: (filters: EventFilters = {}) => {
    const params = new URLSearchParams()
    if (filters.event_type) params.set('event_type', filters.event_type)
    if (filters.session_id) params.set('session_id', filters.session_id)
    if (filters.visitor_id) params.set('visitor_id', filters.visitor_id)
    params.set('limit', String(filters.limit ?? 100))
    return api.get<EventsPage>(`/events?${params}`)
  },
}
