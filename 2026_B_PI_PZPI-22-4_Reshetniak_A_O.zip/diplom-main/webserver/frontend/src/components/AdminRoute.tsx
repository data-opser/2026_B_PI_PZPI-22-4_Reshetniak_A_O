import { useEffect, useState } from 'react'
import { Navigate, Outlet } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

export default function AdminRoute() {
  const { user, isLoading, isAdmin } = useAuth()
  const [redirect, setRedirect] = useState(false)

  useEffect(() => {
    if (!isLoading && user && !isAdmin) {
      const t = setTimeout(() => setRedirect(true), 2000)
      return () => clearTimeout(t)
    }
  }, [isLoading, user, isAdmin])

  if (isLoading || !user) return null
  if (!isAdmin) {
    if (redirect) return <Navigate to="/" replace />
    return (
      <div className="flex flex-col items-center justify-center min-h-[40vh] px-4">
        <p className="text-lg font-medium text-gray-900">Access Denied</p>
        <p className="mt-1 text-sm text-gray-500">This page is available to administrators only. Redirecting to home...</p>
      </div>
    )
  }
  return <Outlet />
}
