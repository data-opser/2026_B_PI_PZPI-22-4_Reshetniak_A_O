import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { clearToken } from '../auth'
import { useAuth } from '../contexts/AuthContext'

const allNavItems = [
  { to: '/', label: 'Dashboard', end: true as const, roles: ['admin', 'user'] },
  { to: '/scenarios', label: 'Scenarios', end: false as const, roles: ['admin', 'user'] },
  { to: '/generation', label: 'Generation', end: false as const, roles: ['admin'] },
  { to: '/events', label: 'Events', end: false as const, roles: ['admin', 'user'] },
  { to: '/webhooks', label: 'Webhooks', end: false as const, roles: ['admin', 'user'] },
  { to: '/api-tokens', label: 'API tokens', end: false as const, roles: ['admin', 'user'] },
  { to: '/users', label: 'Users', end: false as const, roles: ['admin'] },
]

export default function Layout() {
  const navigate = useNavigate()
  const { user, isLoading } = useAuth()
  const navItems = user
    ? allNavItems.filter((item) => item.roles.includes(user.role))
    : []

  return (
    <div className="bg-gray-50 min-h-screen">
      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <span className="text-xl font-bold text-indigo-600">STG</span>
              </div>
              {!isLoading && (
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
                {navItems.map(({ to, label, end }) => (
                  <NavLink
                    key={to}
                    to={to}
                    end={end}
                    className={({ isActive }) =>
                      isActive
                        ? 'border-indigo-500 text-gray-900 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium'
                        : 'border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700 inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium'
                    }
                  >
                    {label}
                  </NavLink>
                ))}
              </div>
              )}
            </div>
            <div className="flex items-center gap-4">
              <a
                href="/docs"
                target="_blank"
                rel="noreferrer"
                className="text-gray-500 hover:text-gray-700 text-sm font-medium"
              >
                API Docs
              </a>
              <button
                type="button"
                onClick={() => {
                  clearToken()
                  navigate('/login')
                }}
                className="text-gray-500 hover:text-gray-700 text-sm font-medium"
              >
                Log out
              </button>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <Outlet />
      </main>

      <div id="toast-container" className="fixed top-4 right-4 z-50" />
    </div>
  )
}
