export interface Scenario {
  id: string
  name: string
  description: string | null
  persona_prompt: string
  target_urls: { start: string; [key: string]: string }
  funnel_config: {
    max_actions?: number
    max_time_seconds?: number
    min_action_delay?: number
    max_action_delay?: number
    [key: string]: unknown
  }
  device_pool: string[]
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface ScenarioCreate {
  name: string
  description?: string
  persona_prompt: string
  target_urls: { start: string; [key: string]: string }
  funnel_config?: Record<string, unknown>
  device_pool?: string[]
}

export interface ScenarioUpdate {
  name?: string
  description?: string
  persona_prompt?: string
  target_urls?: { start: string; [key: string]: string }
  funnel_config?: Record<string, unknown>
  device_pool?: string[]
  is_active?: boolean
}

export interface GenerationJob {
  id: string
  scenario_id: string
  scenario_name: string | null
  total_sessions: number
  completed_sessions: number
  failed_sessions: number
  status: 'pending' | 'running' | 'completed' | 'failed' | 'cancelled'
  config_override: Record<string, unknown> | null
  schedule_cron: string | null
  created_at: string
  started_at: string | null
  finished_at: string | null
}

export interface JobStatus {
  id: string
  status: string
  total: number
  completed: number
  failed: number
  running: number
  percent_complete: number
}

export interface GenerationRequest {
  scenario_id: string
  num_sessions: number
  config_override?: Record<string, unknown>
  schedule_cron?: string
}

export interface Session {
  id: string
  job_id: string
  scenario_id: string
  status: 'pending' | 'running' | 'completed' | 'failed' | 'timeout'
  user_profile: {
    name?: string
    email?: string
    device?: string
    [key: string]: unknown
  }
  result: string | null
  total_actions: number
  total_events: number
  error_message: string | null
  started_at: string | null
  finished_at: string | null
  created_at: string
}

export interface Event {
  id: string
  event_type: string
  visitor_id: string
  session_id: string | null
  page_url: string
  page_title: string | null
  page_referrer: string | null
  event_data: Record<string, unknown>
  device_type: string | null
  browser_family: string | null
  os_family: string | null
  app_id: string
  collector_tstamp: string
}

export interface Webhook {
  id: string
  user_id: string
  owner_name?: string | null
  name: string
  url: string
  secret: string | null
  headers: Record<string, string>
  event_filter: string[]
  scenario_filter: string[]
  is_active: boolean
  created_at: string
  updated_at: string
}

export interface WebhookCreate {
  name: string
  url: string
  secret?: string
  headers?: Record<string, string>
  event_filter?: string[]
  scenario_filter?: string[]
}

export interface WebhookUpdate {
  name?: string
  url?: string
  secret?: string | null
  headers?: Record<string, string>
  event_filter?: string[]
  scenario_filter?: string[]
  is_active?: boolean
}

export interface WebhookLog {
  id: string
  endpoint_id: string
  event_id: string
  attempt: number
  status_code: number | null
  success: boolean
  error_message: string | null
  duration_ms: number | null
  sent_at: string
}

export interface DashboardStats {
  active_jobs: number
  sessions_today: number
  events_today: number
  webhook_success_rate: number
}

export interface FunnelStats {
  total_sessions: number
  completed_sessions: number
  failed_sessions: number
  conversion_rate: number
  avg_events_per_session: number
  exit_reasons: Record<string, number>
}

export interface ThroughputStats {
  sessions_per_hour: number
  events_per_hour: number
  avg_session_duration_seconds: number
}

export interface WebhookDeliveryByWebhook {
  endpoint_id: string
  webhook_name: string
  owner_name?: string | null
  delivery_count: number
  success_count: number
}

export interface WebhookDeliveryByEventType {
  event_type: string
  count: number
}

export interface WebhookDeliveryStats {
  total_deliveries: number
  successful_deliveries: number
  failed_deliveries: number
  unique_events_delivered: number
  by_webhook: WebhookDeliveryByWebhook[]
  by_event_type: WebhookDeliveryByEventType[]
}
