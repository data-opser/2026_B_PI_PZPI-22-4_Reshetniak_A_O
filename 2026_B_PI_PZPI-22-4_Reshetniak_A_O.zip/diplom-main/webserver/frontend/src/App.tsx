import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import Layout from './components/Layout'
import ProtectedRoute from './components/ProtectedRoute'
import AdminRoute from './components/AdminRoute'
import { AuthProvider } from './contexts/AuthContext'
import LoginPage from './pages/Login'
import Dashboard from './pages/Dashboard'
import ScenariosPage from './pages/Scenarios'
import ScenarioEdit from './pages/Scenarios/Edit'
import GenerationPage from './pages/Generation'
import EventsPage from './pages/Events'
import WebhooksPage from './pages/Webhooks'
import ApiTokensPage from './pages/ApiTokens'
import UsersPage from './pages/Users'

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<LoginPage />} />
        <Route element={<ProtectedRoute />}>
          <Route element={<AuthProvider />}>
            <Route path="/" element={<Layout />}>
              <Route index element={<Dashboard />} />
              <Route path="scenarios">
                <Route index element={<ScenariosPage />} />
                <Route path="new" element={<AdminRoute />}>
                  <Route index element={<ScenarioEdit />} />
                </Route>
                <Route path=":id" element={<ScenarioEdit />} />
              </Route>
              <Route path="generation" element={<AdminRoute />}>
                <Route index element={<GenerationPage />} />
              </Route>
              <Route path="events" element={<EventsPage />} />
              <Route path="webhooks" element={<WebhooksPage />} />
              <Route path="api-tokens" element={<ApiTokensPage />} />
              <Route path="users" element={<AdminRoute />}>
                <Route index element={<UsersPage />} />
              </Route>
              <Route path="*" element={<Navigate to="/" replace />} />
            </Route>
          </Route>
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
